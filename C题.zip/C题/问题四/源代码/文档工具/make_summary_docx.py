# -*- coding: utf-8 -*-
"""生成简明对话/工作内容总结 Word（朴素排版）。"""
import os
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

OUTDIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')

doc = Document()
st = doc.styles['Normal']
st.font.name = 'Arial'
st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')


def title(t):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(t); r.bold = True; r.font.size = Pt(15); r.font.name = 'Arial'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')


def h(t):
    p = doc.add_paragraph(); r = p.add_run(t); r.bold = True; r.font.size = Pt(12)
    r.font.name = 'Arial'; r._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    p.paragraph_format.space_before = Pt(6); p.paragraph_format.space_after = Pt(2)


def p(t):
    par = doc.add_paragraph(); par.paragraph_format.space_after = Pt(2)
    r = par.add_run(t); r.font.size = Pt(11); r.font.name = 'Arial'
    r._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')


title('2026国赛C题 问题四 工作内容总结')
p('（说明：本文为对话与处理过程的简明记录，便于后续调用，数值以结果文件为准。）')

h('一、任务目标')
p('在附件4实时波动电价下，重新计算问题2（输出 result4-2.xlsx）和问题3（输出 result4-3.xlsx），并按问题一至三的同等深度交付源代码、结果表、论文表格、可视化、敏感性/稳健性分析和报告。')

h('二、用户明确的要求')
p('1. 不认可“当日实际电价已知”的口径，必须先对附件4电价做数据清洗再计算；')
p('2. 数据隔离、独立建模，不联网查论坛或非官方解答；')
p('3. 先深入探讨问题2/3，再重新设计问题4，制定步骤后按顺序直接开工；')
p('4. 敏感性、稳健性分析放在最后做；')
p('5. 交付材料的完整度对齐前三问。')

h('三、数据探查与电价清洗')
p('附件4为365×144（10分钟一段、每天144段），无缺失、负值和离群点；全年均价0.7662，与附件1均价相同，逐时段均值曲线与附件1相关系数为1。电价分解为三因子：典型日内形状×日价格水平因子×日内高频毛刺。日水平因子呈强周周期（lag7自相关0.964），毛刺无自相关、不可预测。清洗方法为截尾均值估计日水平、乘以光滑典型形状，剔除毛刺。')

h('四、核心建模决策')
p('1. 双价格框架：决策价=只用历史信息的清洗/预测电价，结算价=附件4原始实际电价（不篡改）。电价误差只导致套利次优、不导致物理缺电，与光伏误差触发5倍紧急购电不同。')
p('2. 电价预测主口径 clean_weekly：同星期(lag7、14)日水平因子均值×典型光滑形状；6/12/18点用当日已实现段收缩更新，严格因果、无前视偏差。日前MAPE 10.11%。')
p('3. 优化内核沿用问题2/3的凸线性规划（HiGHS全局最优）：4-2为单日确定性LP；4-3为光伏+电价双滚动MPC（0点计划、6/12/18窗口调整、实际核验结算）。')
p('4. 两个经数据验证后改判的点：光伏预报沿用与问题3一致的legacy口径（可精确复现问题3），严格口径仅作对照；电价预测不直接搬上周带毛刺曲线（其MAPE虽最低但决策成本反而更高）。')

h('五、主要结果（输出区间2025.2.1–12.31，共334天）')
p('问题4-2：fixed复现问题2为1226.22万元；完美预见下界1285.07万元；按典型曲线决策1297.55万元；主结果（清洗预测决策）1297.36万元；无储能基准1702.69万元。储能套利年省约405.33万元，电价预测价值0.19万元，电价完美信息价值EVPI 12.30万元；紧急购电恒为0。')
p('问题4-3：不调整1724.42万元；光伏滚动+典型电价1671.50万元；主结果（光伏+电价双滚动）1671.31万元（紧急76.06万kWh、325.32万元）；完美预见1285.07万元。光伏滚动更新价值53.11万元，电价日前预测价值0.19万元，电价日内更新价值0（整体水平缩放不改变峰谷排序），全信息EVPI 386.24万元。')
p('总体结论：光伏不确定的代价远大于电价不确定；电价做到“周水平+典型形状”的光滑预测即可，不必追求逐时段精确，更不能把随机毛刺当信号。')

h('六、敏感性与稳健性（最后开展）')
p('1. 预测方法：直接搬上周曲线MAPE最低(7.21%)但成本最高，主口径成本最低——MAPE最低不等于决策最优；')
p('2. 清洗截尾比例0.05–0.20结果几乎不变，稳健；')
p('3. 电价波动幅度α从0增至2，EVPI由0增至42.33万元且快于线性增长，α=0正确退化为问题2；')
p('4. 硬件龙卷风：充放效率、储能容量最敏感，功率5000kW以上趋饱和；')
p('5. 光伏legacy与严格口径对照：两口径下“滚动更新显著降本”的定性结论一致。')

h('七、独立校验')
p('verify_q4.py 共22项检查全部通过：母线平衡残差约1e-13、SOC递推残差约1e-12、SOC全程在[1200,10800]、年末回到1200；结果xlsx与求解缓存一致；fixed复现问题2（相对误差1.5e-7）、4-3固定电价口径物理量逐kWh复现问题3、4-2与4-3的perfect全年费用完全相等（1285.07万元）。')

h('八、交付物清单（均在“问题四”目录）')
p('1. result4-2.xlsx、result4-3.xlsx（结果表，334天，已回读校验）；')
p('2. 文档资料：问题4_建模分析报告.docx/md、论文表格数据_Q4.docx/md（22张表）、问题4_独立校验结果.txt；')
p('3. 可视化：13张PNG（电价清洗预测4张、结果5张、敏感性4张）；')
p('4. 源代码：求解模型10个脚本（q4_common、price_model、lpcore、solve_q4_2/4_3、build_result4_2/4_3、make_tables_q4、sensitivity_q4、verify_q4）、可视化3个、文档工具（含本脚本与md_to_docx），已打包为问题四_源代码.zip；')
p('5. 汇总数据：q4_2_summary.json、q4_3_summary.json、sensitivity_q4.json及npz求解缓存。')

h('九、复现顺序')
p('price_model → solve_q4_2 → build_result4_2 → solve_q4_3 → build_result4_3 → make_tables_q4 → 三个visualize脚本 → sensitivity_q4 → verify_q4；md文档用 源代码/文档工具/md_to_docx.py 转Word。')

out = os.path.join(OUTDIR, '问题四_对话工作总结.docx')
doc.save(out)
print('saved', out)
