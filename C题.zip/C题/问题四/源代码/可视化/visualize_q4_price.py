# -*- coding: utf-8 -*-
"""问题4 · 附件4 电价数据清洗、结构分解与预测精度可视化。"""
import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '求解模型'))
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

from q4_common import OUTDIR, PUB_IDX
from price_model import get_forecast, build_forecast

FIG = os.path.join(OUTDIR, '可视化'); os.makedirs(FIG, exist_ok=True)
C_RAW, C_CLEAN, C_TYP, C_PRED, C_ACT = '#E15759', '#4E79A7', '#59A14F', '#F0A202', '#8C8C8C'
TN = np.arange(144) / 6.0 + 1 / 6.0       # 自然序段结束时刻 0:10..24:00

fc = get_forecast()
typ, pm = fc['typ'], fc['price_m']; level, clean, pnat = fc['level'], fc['clean'], fc['pred_nat']


def fig_decompose():
    """典型曲线 + 两日原始/清洗对比，展示毛刺与清洗。"""
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))
    ax = axes[0]
    ax.plot(TN, typ, color=C_TYP, lw=2.2, label='典型日内曲线(附件1,=365天逐时段均值)')
    for d, c in [(60, '#9BBBF4'), (200, '#E1B98F')]:
        ax.plot(TN, pm[d], color=c, lw=1, alpha=0.8, label='第%d天实际电价' % (d + 1))
    ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 3)); ax.set_xlabel('时刻(h)')
    ax.set_ylabel('电价(元/kWh)'); ax.set_title('日内价格形状：典型曲线与两天实时电价'); ax.grid(alpha=0.2); ax.legend()
    ax = axes[1]
    d = 120
    ax.plot(TN, pm[d], color=C_RAW, lw=1.4, alpha=0.8, label='原始实时电价(含高频毛刺)')
    ax.plot(TN, clean[d], color=C_CLEAN, lw=2.2, label='清洗曲线=日水平因子×典型形状')
    ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 3)); ax.set_xlabel('时刻(h)')
    ax.set_ylabel('电价(元/kWh)'); ax.set_title('数据清洗：剔除日内高频毛刺(示例日 d=%d)' % (d + 1)); ax.grid(alpha=0.2); ax.legend()
    fig.tight_layout(); p = os.path.join(FIG, '问题4_电价结构分解与清洗.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_level():
    """日水平因子全年序列 + 滞后自相关。"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 4.8))
    ax1.plot(np.arange(365), level, color=C_CLEAN, lw=1.3)
    ax1.axhline(1, color=C_ACT, ls='--', lw=1)
    ax1.set_xlim(0, 365); ax1.set_xlabel('一年中的第d天'); ax1.set_ylabel('日价格水平因子')
    ax1.set_title('日价格水平因子全年序列（围绕1波动，强周周期性）'); ax1.grid(alpha=0.2)
    lags = np.arange(1, 15)
    ac = [np.corrcoef(level[:-k], level[k:])[0, 1] for k in lags]
    ax2.bar(lags, ac, color=[C_PRED if k == 7 else '#B7CCE0' for k in lags])
    for k, v in zip(lags, ac):
        ax2.text(k, v + 0.02, '%.2f' % v, ha='center', fontsize=7)
    ax2.set_xticks(lags); ax2.set_ylim(-0.2, 1.05); ax2.set_xlabel('滞后天数')
    ax2.set_ylabel('自相关系数'); ax2.set_title('日水平因子自相关：lag7=%.2f 呈周周期' % ac[6]); ax2.grid(alpha=0.2, axis='y')
    fig.tight_layout(); p = os.path.join(FIG, '问题4_日水平因子与周周期.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_accuracy():
    """不同日前方法 MAPE + 日内更新增益。"""
    # 重新算多方法精度
    res = {}
    for method in ('clean_weekly', 'weekly', 'level'):
        lv, cl, pn, pl = build_forecast(pm, typ, method=method)
        a = pn[0, 31:]; act = pm[31:]
        res[method] = 100 * (np.abs(act - a) / act).mean()
    res['typical'] = 100 * (np.abs(pm[31:] - typ[None, :]) / pm[31:]).mean()
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 4.8))
    names = ['typical', 'level', 'clean_weekly', 'weekly']; lab = ['典型曲线', '前7天水平', '同星期水平×形状(主)', '同星期曲线']
    vals = [res[n] for n in names]
    bars = ax1.bar(range(4), vals, color=['#B7CCE0', '#9BBBF4', C_CLEAN, C_PRED])
    for i, v in enumerate(vals):
        ax1.text(i, v + 0.2, '%.2f%%' % v, ha='center', fontsize=10)
    ax1.set_xticks(range(4)); ax1.set_xticklabels(lab); ax1.set_ylabel('日前预测 MAPE')
    ax1.set_title('日前电价预测方法精度对比（334天）'); ax1.grid(alpha=0.2, axis='y')
    # 日内更新增益
    da, u36, u72, u108 = [], [], [], []
    for i0, store in zip(PUB_IDX[1:], (u36, u72, u108)):
        pass
    def mape_win(j, i0):
        fut = slice(i0 + 1, 144)
        return 100 * (np.abs(pm[31:, fut] - pnat[j, 31:, fut]) / pm[31:, fut]).mean()
    labels = ['6点窗', '12点窗', '18点窗']; x = np.arange(3); w = 0.36
    before = [mape_win(0, i0) for i0 in PUB_IDX[1:]]
    after = [mape_win(j, i0) for j, i0 in zip((1, 2, 3), PUB_IDX[1:])]
    ax2.bar(x - w / 2, before, w, color='#B7CCE0', label='更新前(日前预测)')
    ax2.bar(x + w / 2, after, w, color=C_CLEAN, label='日内更新后')
    for i in range(3):
        ax2.text(i - w / 2, before[i] + 0.1, '%.2f' % before[i], ha='center', fontsize=8)
        ax2.text(i + w / 2, after[i] + 0.1, '%.2f' % after[i], ha='center', fontsize=8)
    ax2.set_xticks(x); ax2.set_xticklabels(labels); ax2.set_ylabel('未来窗 MAPE')
    ax2.set_title('日内 6/12/18 点更新对未来窗预测精度的提升'); ax2.legend(); ax2.grid(alpha=0.2, axis='y')
    fig.tight_layout(); p = os.path.join(FIG, '问题4_电价预测精度.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_oneday(d=120):
    """单日：实际 vs 日前预测 vs 三次日内更新。"""
    fig, ax = plt.subplots(figsize=(13, 5))
    ax.plot(TN, pm[d], color=C_RAW, lw=2, label='实际电价(事后结算价)', zorder=3)
    ax.plot(TN, pnat[0, d], color=C_TYP, lw=1.8, ls='--', label='0点日前预测')
    for j, m, c in zip((1, 2, 3), (6, 12, 18), ['#9BBBF4', '#F0A202', '#7E57C2']):
        seg = pnat[j, d].copy()
        seg[:PUB_IDX[j] + 1] = np.nan
        ax.plot(TN, seg, lw=1.6, color=c, label='%d点更新后对剩余段预测' % m)
        ax.axvline(m, color='#999', ls=':', lw=1)
    ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 2)); ax.set_xlabel('时刻(h)'); ax.set_ylabel('电价(元/kWh)')
    ax.set_title('第%d天 实时电价与多时点预测（虚线为决策时刻）' % (d + 1)); ax.grid(alpha=0.2); ax.legend(ncol=2)
    fig.tight_layout(); p = os.path.join(FIG, '问题4_单日电价多时点预测.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


if __name__ == '__main__':
    fig_decompose(); fig_level(); fig_accuracy(); fig_oneday()
    print('电价侧图表完成 ->', FIG)
