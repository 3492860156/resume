# -*- coding: utf-8 -*-
"""问题4 · 敏感性/稳健性可视化（读 sensitivity_q4.json）。"""
import os
import sys
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '求解模型'))
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
from q4_common import OUTDIR
FIG = os.path.join(OUTDIR, '可视化')
R = json.load(open(os.path.join(OUTDIR, '数据', 'sensitivity_q4.json'), encoding='utf-8'))
C_M, C_R, C_G, C_O = '#4E79A7', '#E15759', '#59A14F', '#F0A202'


def fig_method():
    s1 = R['S1_method']; keys = ['典型曲线', 'level', 'clean_weekly', 'weekly']
    lab = ['典型曲线', '前7天水平', '同星期水平×形状\n(主口径)', '同星期曲线']
    mape = [s1[k]['mape'] for k in keys]; cost = [s1[k]['settle_wan'] for k in keys]
    fig, ax1 = plt.subplots(figsize=(11, 5.2))
    x = np.arange(4); w = 0.5
    bars = ax1.bar(x, cost, w, color=['#B7CCE0', '#9BBBF4', C_M, C_O], label='全年实际结算成本(万元)')
    for i, v in enumerate(cost):
        ax1.text(i, v + 0.05, '%.2f' % v, ha='center', fontsize=10)
    ax1.set_xticks(x); ax1.set_xticklabels(lab); ax1.set_ylabel('结算成本(万元)', color=C_M)
    ax1.set_ylim(1296.5, 1298.6); ax1.grid(alpha=0.2, axis='y')
    ax2 = ax1.twinx()
    ax2.plot(x, mape, 'o-', color=C_R, lw=2, ms=9, label='日前预测MAPE(%)')
    for i, v in enumerate(mape):
        ax2.text(i, v + 0.3, '%.2f%%' % v, ha='center', fontsize=9, color=C_R)
    ax2.set_ylabel('MAPE(%)', color=C_R); ax2.set_ylim(0, 20)
    ax1.set_title('电价预测方法敏感性：MAPE最低≠决策最优（同星期曲线虽MAPE7.2%却成本最高）')
    h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=10)
    fig.tight_layout(); p = os.path.join(FIG, '问题4_敏感性_预测方法.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_trim_alpha():
    fig, (a, b) = plt.subplots(1, 2, figsize=(15, 5))
    s2 = R['S2_trim']; tr = [0.05, 0.10, 0.15, 0.20]
    mp = [s2[str(t)]['mape'] for t in tr]; co = [s2[str(t)]['settle_wan'] for t in tr]
    a.plot(tr, mp, 'o-', color=C_M, lw=2, label='MAPE(%)')
    a.set_xlabel('截尾比例 trim'); a.set_ylabel('MAPE(%)', color=C_M); a.grid(alpha=0.2)
    a2 = a.twinx(); a2.plot(tr, co, 's--', color=C_R, lw=2, label='结算成本(万元)')
    a2.set_ylabel('结算成本(万元)', color=C_R); a2.set_ylim(1297.0, 1297.7)
    a.set_title('清洗截尾比例稳健性（结果几乎不变）')
    h1, l1 = a.get_legend_handles_labels(); h2, l2 = a2.get_legend_handles_labels()
    a.legend(h1 + h2, l1 + l2, loc='center right', fontsize=9)
    s3 = R['S3_alpha']; al = [0.0, 0.5, 1.0, 1.5, 2.0]
    nv = [s3[str(x)]['naive'] for x in al]; fo = [s3[str(x)]['forecast'] for x in al]
    pe = [s3[str(x)]['perfect'] for x in al]; ev = [s3[str(x)]['evpi'] for x in al]
    b.plot(al, nv, 'o-', color='#B7CCE0', lw=2, label='忽略波动')
    b.plot(al, fo, 's-', color=C_M, lw=2, label='清洗预测(主)')
    b.plot(al, pe, '^-', color=C_G, lw=2, label='完美预见')
    b.fill_between(al, pe, fo, color=C_R, alpha=0.12)
    for xi, x in enumerate(al):
        b.text(x, fo[xi] + 6, 'EVPI%.1f' % ev[xi], ha='center', fontsize=8, color=C_R)
    b.set_xlabel('电价波动幅度系数 α'); b.set_ylabel('全年成本(万元)'); b.grid(alpha=0.2)
    b.set_title('电价波动幅度：不确定性代价(EVPI)随波动加速扩大'); b.legend(fontsize=9)
    fig.tight_layout(); p = os.path.join(FIG, '问题4_敏感性_清洗与波动幅度.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_tornado():
    tor = R['S4_hardware']['tornado']; base = R['S4_hardware']['baseline']['settle_wan']
    # 每参数取两档中绝对偏移更大者标范围
    params = ['充放效率η', '储能容量上限', '最大充放功率']
    lo, hi = [], []
    for pm in params:
        ds = [t['delta'] for t in tor if t['param'] == pm]
        lo.append(min(ds)); hi.append(max(ds))
    fig, ax = plt.subplots(figsize=(11, 4.8))
    y = np.arange(len(params))[::-1]
    for yi, l, h, pm in zip(y, lo, hi, params):
        ax.barh(yi, l, color=C_G if l < 0 else C_R, height=0.5)
        ax.barh(yi, h, color=C_R if h > 0 else C_G, height=0.5)
        ax.text(l - 1.5, yi, '%+.1f' % l, va='center', ha='right', fontsize=10)
        ax.text(h + 1.5, yi, '%+.1f' % h, va='center', ha='left', fontsize=10)
    ax.axvline(0, color='k', lw=1)
    ax.set_yticks(y); ax.set_yticklabels(params); ax.set_xlabel('相对基线(%.1f万元)的全年成本变化(万元)' % base)
    ax.set_xlim(-60, 60); ax.grid(alpha=0.2, axis='x')
    ax.set_title('硬件参数龙卷风图（4-2主口径）：充放效率与储能容量最敏感，功率5000kW以上趋饱和')
    fig.tight_layout(); p = os.path.join(FIG, '问题4_敏感性_硬件龙卷风.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_align():
    s5 = R['S5_forecast_align']; ks = list(s5.keys())
    modes = ['no_adjust', 'full']; lab = ['仅0点计划', '光伏滚动(主)']
    fig, (a, b) = plt.subplots(1, 2, figsize=(14, 5))
    x = np.arange(2); w = 0.36
    for i, (k, c) in enumerate(zip(ks, [C_M, C_O])):
        tot = [s5[k][m]['total_wan'] for m in modes]
        a.bar(x + (i - 0.5) * w, tot, w, color=c, label=k)
        for xi, v in zip(x, tot):
            a.text(xi + (i - 0.5) * w, v + 8, '%.1f' % v, ha='center', fontsize=9)
    a.set_xticks(x); a.set_xticklabels(lab); a.set_ylabel('4-3全年总费用(万元)'); a.grid(alpha=0.2, axis='y')
    a.set_title('光伏预报展开口径对照：两口径下滚动更新均显著降本'); a.legend(fontsize=9)
    for i, (k, c) in enumerate(zip(ks, [C_M, C_O])):
        em = [s5[k][m]['em_wan_kwh'] for m in modes]
        b.bar(x + (i - 0.5) * w, em, w, color=c, label=k)
        for xi, v in zip(x, em):
            b.text(xi + (i - 0.5) * w, v + 1, '%.1f' % v, ha='center', fontsize=9)
    b.set_xticks(x); b.set_xticklabels(lab); b.set_ylabel('全年紧急购电量(万kWh)'); b.grid(alpha=0.2, axis='y')
    b.set_title('口径对照：滚动更新均降低紧急购电，结论对10分钟错位稳健'); b.legend(fontsize=9)
    fig.tight_layout(); p = os.path.join(FIG, '问题4_敏感性_光伏口径.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


if __name__ == '__main__':
    fig_method(); fig_trim_alpha(); fig_tornado(); fig_align()
    print('敏感性图表完成 ->', FIG)
