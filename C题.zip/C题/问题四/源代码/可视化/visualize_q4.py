# -*- coding: utf-8 -*-
"""问题4 · 策略结果可视化：情景对比 / 四指定日(4-2,4-3) / 价值瀑布 / 月度统计。"""
import os
import sys
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '求解模型'))
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

from q4_common import FOCUS, OUTDIR, load_all, day_vector, H
FIG = os.path.join(OUTDIR, '可视化'); os.makedirs(FIG, exist_ok=True)
C_PLAN, C_FINAL, C_EM, C_PV, C_LOAD, C_SOC, C_PRICE = \
    '#B7CCE0', '#4E79A7', '#E15759', '#F1B47A', '#8C8C8C', '#59A14F', '#9C5BA3'
T = (np.arange(144) + 1) / 6.0

inp = load_all(); load_m, pv_m = inp['load_m'], inp['pv_m']
dates = [str(x) for x in inp['dates']]
z2 = np.load(os.path.join(FIG, '..', '源代码', '求解模型', 'q4_2_results.npz'))
z3 = np.load(os.path.join(FIG, '..', '源代码', '求解模型', 'q4_3_results.npz'))
s2 = json.load(open(os.path.join(OUTDIR, '数据', 'q4_2_summary.json'), encoding='utf-8'))
s3 = json.load(open(os.path.join(OUTDIR, '数据', 'q4_3_summary.json'), encoding='utf-8'))


def fig_scenarios():
    fig, (a, b) = plt.subplots(1, 2, figsize=(15, 5))
    names = ['fixed', 'naive_fixed', 'forecast', 'perfect']
    lab = ['固定电价\n(复现问题2)', '典型曲线决策\n实际价结算', '清洗预测决策\n(4-2主结果)', '完美预见\n(波动下界)']
    vals = [s2[k]['settle_cost'] / 1e4 for k in names]
    cols = ['#B7CCE0', '#F1B47A', C_FINAL, C_SOC]
    a.bar(range(4), vals, color=cols)
    for i, v in enumerate(vals):
        a.text(i, v + 8, '%.1f万' % v, ha='center', fontsize=10, fontweight='bold')
    a.set_xticks(range(4)); a.set_xticklabels(lab); a.set_ylabel('全年实际结算费(万元)')
    a.set_ylim(1100, 1400); a.set_title('问题4-2 不同电价信息情景全年成本'); a.grid(alpha=0.2, axis='y')
    # 4-3 模式
    names3 = ['no_adjust', 'naive_pv', 'pv_only', 'full', 'perfect']
    lab3 = ['不调整', '光伏更新\n典型电价', '光伏更新\n电价预测', '双滚动\n(主结果)', '完美预见']
    v3 = [s3[k]['total'] / 1e4 for k in names3]
    b.bar(range(5), v3, color=['#D9D9D9', '#F1B47A', '#9BBBF4', C_FINAL, C_SOC])
    for i, v in enumerate(v3):
        b.text(i, v + 12, '%.1f' % v, ha='center', fontsize=10, fontweight='bold')
    b.set_xticks(range(5)); b.set_xticklabels(lab3); b.set_ylabel('全年总费用(万元)')
    b.set_ylim(1100, 1850); b.set_title('问题4-3 不同滚动决策模式全年成本'); b.grid(alpha=0.2, axis='y')
    fig.tight_layout(); p = os.path.join(FIG, '问题4_情景与模式成本对比.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_waterfall():
    """4-3 价值瀑布：no_adjust -> 光伏更新 -> 电价预测 -> full -> perfect。"""
    v0 = s3['no_adjust']['total'] / 1e4
    v_pv = s3['pv_only']['total'] / 1e4
    v_full = s3['full']['total'] / 1e4
    v_per = s3['perfect']['total'] / 1e4
    steps = [('不调整', v0, 'base'), ('光伏滚动\n更新', v0 - v_pv, 'down'),
             ('电价日前\n预测', v_pv - v_full, 'down'), ('双滚动\n主结果', v_full, 'base'),
             ('消除全部\n不确定性', v_full - v_per, 'down'), ('完美预见', v_per, 'base')]
    fig, ax = plt.subplots(figsize=(13, 5.2))
    cum = 0
    for i, (name, val, kind) in enumerate(steps):
        if kind == 'base':
            ax.bar(i, val, color=C_FINAL if '主结果' in name else (C_SOC if '完美' in name else '#B7CCE0'))
            ax.text(i, val + 15, '%.1f' % val, ha='center', fontsize=10, fontweight='bold')
            cum = val
        else:
            ax.bar(i, val, bottom=cum - val, color='#9BD3A6')
            ax.text(i, cum + 8, '-%.2f' % val, ha='center', fontsize=10, color='#2F6B37')
            cum -= val
    ax.set_xticks(range(6)); ax.set_xticklabels([s[0] for s in steps])
    ax.set_ylabel('全年总费用(万元)'); ax.set_ylim(1100, 1800)
    ax.set_title('问题4-3 信息更新的价值瀑布（光伏更新省%.1f万、电价预测省%.2f万、全信息差%.1f万）'
                 % (s3['pv_update_value'] / 1e4, s3['price_dayahead_value'] / 1e4, s3['EVPI'] / 1e4))
    ax.grid(alpha=0.2, axis='y'); fig.tight_layout()
    p = os.path.join(FIG, '问题4_信息更新价值瀑布.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def _focus_panel(ax, d, mode):
    L = day_vector(load_m, d) * H; PV = day_vector(pv_m, d) * H
    pa = z2['actual_price_lp'][d]
    ax.bar(T, L, width=0.14, color=C_LOAD, alpha=0.32, label='负载')
    ax.bar(T, PV, width=0.14, color=C_PV, alpha=0.55, label='光伏')
    if mode == 'q2':
        X = z2['forecast_X'][d]
        ax.bar(T, X, width=0.08, color=C_FINAL, label='计划购电量')
        S = z2['forecast_S'][d]; cost = z2['forecast_cost_set'][d]; em = None
        title = '%s｜4-2 购电%.0fkWh/%.0f元' % (dates[d], X.sum(), cost)
    else:
        Xp, Xf, E = z3['Xp'][d], z3['Xf'][d], z3['Eact'][d]
        ax.bar(T, Xp, width=0.14, color=C_PLAN, label='计划购电量')
        ax.bar(T, Xf, width=0.07, color=C_FINAL, label='最终购电量')
        ax.bar(T, np.where(E > 1e-6, E, 0), width=0.07, color=C_EM, label='紧急购电')
        S = z3['Sf'][d]; cost = z3['cost_tot'][d]
        for x in (6, 12, 18):
            ax.axvline(x, color='#999', ls=':', lw=1)
        title = '%s｜4-3 总费%.0f元(紧急%.0f)' % (dates[d], cost, z3['cost_em'][d])
    ax.set_ylim(0, 1500); ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 3))
    ax.set_title(title, fontsize=10.5); ax.grid(alpha=0.2)
    ax2 = ax.twinx(); ax2.plot(T, pa, color=C_PRICE, lw=1.5, alpha=0.85, label='实际电价')
    ax2.set_ylim(0, 2.0); ax2.set_ylabel('电价(元/kWh)', fontsize=8, color=C_PRICE); ax2.tick_params(labelsize=8, labelcolor=C_PRICE)
    ax3 = ax.twinx(); ax3.spines['right'].set_position(('outward', 38))
    ax3.plot(T, S[:144], color=C_SOC, lw=1.6, label='储电量'); ax3.set_ylim(0, 12000); ax3.set_ylabel('SOC(kWh)', fontsize=8, color=C_SOC); ax3.tick_params(labelsize=8, labelcolor=C_SOC)


def fig_focus(mode):
    fig, axes = plt.subplots(2, 2, figsize=(16, 9))
    for ax, f in zip(axes.ravel(), FOCUS):
        _focus_panel(ax, dates.index(f), mode)
    h, l = axes[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=5, fontsize=10, frameon=False)
    ttl = '问题4-2 四指定日购电策略（波动电价预测决策/实际结算）' if mode == 'q2' else \
          '问题4-3 四指定日计划/最终购电、紧急购电（紫=实际电价 绿=SOC，虚线为调整时刻）'
    fig.suptitle(ttl, fontsize=13, y=0.99); fig.tight_layout(rect=[0, 0.04, 1, 0.97])
    p = os.path.join(FIG, '问题4_%s_四指定日策略.png' % mode)
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


def fig_monthly():
    months = list(range(2, 13)); x = np.arange(11); w = 0.26
    def monthly_cost(cost_arr):
        return [sum(cost_arr[d] for d in range(31, 365) if int(dates[d][5:7]) == m) / 1e4 for m in months]
    q2f = monthly_cost(z2['forecast_cost_set']); q2p = monthly_cost(z2['perfect_cost_set'])
    q3t = monthly_cost(z3['cost_tot'])
    fig, ax = plt.subplots(figsize=(13, 5.2))
    ax.bar(x - w, q2p, w, color='#9BD3A6', label='4-2完美预见')
    ax.bar(x, q2f, w, color=C_FINAL, label='4-2预测决策')
    ax.bar(x + w, q3t, w, color=C_EM, alpha=0.8, label='4-3双滚动(含紧急)')
    ax.set_xticks(x); ax.set_xticklabels(['%d月' % m for m in months]); ax.set_ylabel('月度费用(万元)')
    ax.set_title('问题4 全年月度费用对比（2025.2–12）'); ax.grid(alpha=0.2, axis='y'); ax.legend()
    fig.tight_layout(); p = os.path.join(FIG, '问题4_全年月度统计.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig); print('saved', p)


if __name__ == '__main__':
    fig_scenarios(); fig_waterfall(); fig_focus('q2'); fig_focus('q3'); fig_monthly()
    print('结果侧图表完成 ->', FIG)
