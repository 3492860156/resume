# -*- coding: utf-8 -*-
"""
问题4-2（波动电价下重算问题2）全年求解
=====================================================================
问题2 是“0点一次性制定当日确定性计划、负载/光伏全信息已知、紧急购电为5倍安全阀”。
波动电价下，0点无法确知当日实际电价，故设三种价格情景（各自独立跨天递推 SOC）：
  · forecast 主结果：用【日前预测电价】优化物理计划(X,C,D)，用【附件4实际电价】结算；
  · perfect  下界对照：用实际电价优化（完美预见，理论最低成本）；
  · fixed    基准对照：用附件1固定电价优化并结算（复现问题2，用于回归校验）。
负载/光伏均用附件2实际值（全信息，与问题2一致）⇒ 三情景紧急购电 e≡0。
输出 q4_2_results.npz（三情景逐日 X/C/D/S + 实际电价）与汇总 JSON。
"""
import os
import json
import numpy as np

from q4_common import (H, N, DAYS, S_INIT, S_MIN, S_MAX, ETA, E_MAX, OUTDIR, SRCDIR,
                       load_all, day_vector, fixed_price_lp)
from price_model import get_forecast
from lpcore import solve_deterministic, check_residual

OUT_NPZ = os.path.join(SRCDIR, 'q4_2_results.npz')
OUT_JSON = os.path.join(OUTDIR, '数据', 'q4_2_summary.json')
OUT_FROM = 31     # 输出 2.1 起（1月预热）


def run_scenario(load_m, pv_m, price_dec_m, price_set_m, s0=S_INIT, label=''):
    """price_dec_m/price_set_m: (365,144) 自然列序的决策价/结算价。逐日 LP、跨天递推。"""
    X = np.zeros((DAYS, N)); C = np.zeros_like(X); D = np.zeros_like(X)
    U = np.zeros_like(X); E = np.zeros_like(X); S = np.zeros((DAYS, N + 1))
    cost_dec = np.zeros(DAYS); cost_set = np.zeros(DAYS)
    s_init = s0
    mb = mr = 0.0; sim_cd = 0
    for d in range(DAYS):
        L = day_vector(load_m, d) * H
        PV = day_vector(pv_m, d) * H
        pd_ = day_vector(price_dec_m, d)
        ps_ = day_vector(price_set_m, d)
        x, c, dd, u, e, ss = solve_deterministic(L, PV, pd_, s_init)
        b, r, scd, smin, smax = check_residual(L, x, c, dd, u, e, ss)
        mb, mr, sim_cd = max(mb, b), max(mr, r), sim_cd + scd
        assert smin >= S_MIN - 1e-6 and smax <= S_MAX + 1e-6
        assert e.sum() < 1e-6, '全信息下不应紧急购电'
        X[d], C[d], D[d], U[d], E[d], S[d] = x, c, dd, u, e, ss
        cost_dec[d] = float((pd_ * x).sum())
        cost_set[d] = float((ps_ * x).sum())
        s_init = float(ss[N])
    print('[%s] 母线残差%.1e 递推残差%.1e 同时充放段%d 年末SOC=%.1f'
          % (label, mb, mr, sim_cd, s_init))
    return dict(X=X, C=C, D=D, U=U, E=E, S=S, cost_dec=cost_dec, cost_set=cost_set)


def main():
    inp = load_all()
    typ, load_m, pv_m, price_m = inp['typ_price'], inp['load_m'], inp['pv_m'], inp['price_m']
    fc = get_forecast()
    pred_lp = fc['pred_lp'][0]                       # (365,144) LP序日前预测
    # 预测电价转回自然列序，便于统一 day_vector
    pred_nat0 = fc['pred_nat'][0]                    # 自然列序

    fixed_lp = fixed_price_lp(typ)
    typ_rep = np.repeat(typ[None, :], DAYS, 0)
    scenarios = {
        'forecast': (pred_nat0, price_m),    # 周周期预测决策, 实际价结算（主结果）
        'perfect': (price_m, price_m),       # 完美预见, 实际价结算（波动世界下界）
        'naive_fixed': (typ_rep, price_m),   # 当作固定典型曲线决策, 实际价结算（忽略波动）
        'fixed': (typ_rep, typ_rep),         # 假想电价真的固定（复现问题2，回归校验）
    }
    out = dict(actual_price_lp=np.stack([day_vector(price_m, d) for d in range(DAYS)]))
    summary = {}
    for name, (dec, setl) in scenarios.items():
        r = run_scenario(load_m, pv_m, dec, setl, label=name)
        for k, v in r.items():
            out[f'{name}_{k}'] = v
        sl = slice(OUT_FROM, DAYS)
        buy = float(r['X'][sl].sum())
        cset = float(r['cost_set'][sl].sum())
        cdec = float(r['cost_dec'][sl].sum())
        summary[name] = dict(buy_kwh=buy, settle_cost=cset, decision_cost=cdec,
                             chg=float(r['C'][sl].sum()), dis=float(r['D'][sl].sum()))
    # 无储能基准（实际电价）：净缺口直购
    base = 0.0
    for d in range(OUT_FROM, DAYS):
        L = day_vector(load_m, d) * H; P = day_vector(pv_m, d) * H
        pa = day_vector(price_m, d)
        base += float((pa * np.maximum(L - P, 0)).sum())
    summary['no_storage_actual'] = dict(settle_cost=base)
    # 价值量（均在“实际波动价结算”的同一世界内比较）
    summary['EVPI_price'] = summary['forecast']['settle_cost'] - summary['perfect']['settle_cost']
    summary['forecast_value'] = summary['naive_fixed']['settle_cost'] - summary['forecast']['settle_cost']
    summary['ignore_vol_cost'] = summary['naive_fixed']['settle_cost'] - summary['perfect']['settle_cost']
    np.savez(OUT_NPZ, **out)
    json.dump(summary, open(OUT_JSON, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    print('\n===== 问题4-2 输出区间 2.1-12.31（334天）=====')
    for name in ('fixed', 'perfect', 'naive_fixed', 'forecast'):
        s = summary[name]
        print('%-12s 购电量 %.0f kWh | 结算费 %.2f 元 (%.2f 万元)'
              % (name, s['buy_kwh'], s['settle_cost'], s['settle_cost'] / 1e4))
    print('无储能基准(实际价) %.2f 元 (%.2f 万元)' % (base, base / 1e4))
    print('电价预测价值(naive->forecast) = %.2f 元 (%.2f 万元)'
          % (summary['forecast_value'], summary['forecast_value'] / 1e4))
    print('电价完美信息价值 EVPI(forecast->perfect) = %.2f 元 (%.2f 万元)'
          % (summary['EVPI_price'], summary['EVPI_price'] / 1e4))
    print('\n已存:', OUT_NPZ)


if __name__ == '__main__':
    main()
