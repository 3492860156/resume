# -*- coding: utf-8 -*-
"""
问题4 · 连续线性规划(LP)内核（与问题2/3同一凸 LP，HiGHS 全局最优）
=====================================================================
变量（单日确定性）：x购电|c充电(电网侧)|d放电(电池侧)|u光伏直供|e紧急购电 各144，
                  S 储电状态 145；共 865 维。
  母线平衡：x + u + η·d + e - c = L
  储能递推：S_{i+1} = S_i + η·c - d
  界：0≤c,d≤E_MAX；0≤u≤PV；S_MIN≤S≤S_MAX；x,e≥0；S[0]=s_init。
  目标：min Σ price·(x + k_e·e)。
窗口调整 LP（问题4-3 的 6/12/18 点滚动）：见 solve_adjust，含 up/dn 凸分段。
"""
import numpy as np
from scipy.optimize import linprog

from q4_common import (H, ETA, E_MAX, S_MIN, S_MAX, N, EMULT, DN_RATE, UP_RATE)


def solve_deterministic(L, PV, price, s_init, emult=EMULT):
    """单日确定性 LP。L/PV 已为 kWh(144)，price(144) 为【决策价】。"""
    nv = 5 * N + (N + 1)
    off = {'x': 0, 'c': N, 'd': 2 * N, 'u': 3 * N, 'e': 4 * N, 'S': 5 * N}
    vid = lambda i, k: off[k] + i
    obj = np.zeros(nv)
    obj[off['x']:off['x'] + N] = price
    obj[off['e']:off['e'] + N] = emult * price
    A = np.zeros((2 * N, nv)); b = np.zeros(2 * N)
    for i in range(N):
        A[i, vid(i, 'x')] = 1; A[i, vid(i, 'u')] = 1
        A[i, vid(i, 'd')] = ETA; A[i, vid(i, 'e')] = 1
        A[i, vid(i, 'c')] = -1; b[i] = L[i]
        A[N + i, vid(i + 1, 'S')] = 1; A[N + i, vid(i, 'S')] = -1
        A[N + i, vid(i, 'c')] = -ETA; A[N + i, vid(i, 'd')] = 1
    bounds = [(0.0, None)] * nv
    for i in range(N):
        bounds[vid(i, 'c')] = (0, E_MAX); bounds[vid(i, 'd')] = (0, E_MAX)
        bounds[vid(i, 'u')] = (0, PV[i])
    for i in range(N + 1):
        bounds[vid(i, 'S')] = (S_MIN, S_MAX)
    bounds[vid(0, 'S')] = (s_init, s_init)
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('确定性LP失败: %s' % res.message)
    g = lambda k: res.x[off[k]:off[k] + N]
    X, C, D, U, E = g('x'), g('c'), g('d'), g('u'), g('e')
    S = res.x[off['S']:off['S'] + N + 1]
    return X, C, D, U, E, S


def solve_adjust(L, PV, price, s_start, Qp, i0,
                 dn_rate=DN_RATE, up_rate=UP_RATE, emult=EMULT):
    """窗口[i0,144)滚动调整 LP（变量 xa|ca|da|ua|ea|up|dn + Sa）。
    偏差等式 xa - up + dn = Qp；增量目标 Σ P(1.5·up -0.5·dn +5·e)。"""
    n = N - i0
    Lw, PVw, Pw, Qw = L[i0:], PV[i0:], price[i0:], Qp[i0:]
    nv = 7 * n + (n + 1)
    off = {'x': 0, 'c': n, 'd': 2 * n, 'u': 3 * n, 'e': 4 * n,
           'up': 5 * n, 'dn': 6 * n, 'S': 7 * n}
    vid = lambda i, k: off[k] + i
    obj = np.zeros(nv)
    obj[off['dn']:off['dn'] + n] = -dn_rate * Pw
    obj[off['up']:off['up'] + n] = up_rate * Pw
    obj[off['e']:off['e'] + n] = emult * Pw
    A = np.zeros((3 * n, nv)); b = np.zeros(3 * n)
    for i in range(n):
        A[i, vid(i, 'x')] = 1; A[i, vid(i, 'u')] = 1
        A[i, vid(i, 'd')] = ETA; A[i, vid(i, 'e')] = 1
        A[i, vid(i, 'c')] = -1; b[i] = Lw[i]
        A[n + i, vid(i + 1, 'S')] = 1; A[n + i, vid(i, 'S')] = -1
        A[n + i, vid(i, 'c')] = -ETA; A[n + i, vid(i, 'd')] = 1
        A[2 * n + i, vid(i, 'x')] = 1
        A[2 * n + i, vid(i, 'up')] = -1
        A[2 * n + i, vid(i, 'dn')] = 1; b[2 * n + i] = Qw[i]
    bounds = [(0.0, None)] * nv
    for i in range(n):
        bounds[vid(i, 'c')] = (0, E_MAX); bounds[vid(i, 'd')] = (0, E_MAX)
        bounds[vid(i, 'u')] = (0, PVw[i])
    for i in range(n + 1):
        bounds[vid(i, 'S')] = (S_MIN, S_MAX)
    bounds[vid(0, 'S')] = (s_start, s_start)
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('调整LP(i0=%d)失败: %s' % (i0, res.message))
    g = lambda k: res.x[off[k]:off[k] + n]
    return g('x'), g('c'), g('d'), g('u'), g('e'), g('up'), g('dn'), \
        res.x[off['S']:off['S'] + n + 1]


def check_residual(L, X, C, D, U, E, S):
    """回代残差体检，返回 (母线最大残差, 递推最大残差, 同时充放段数, SOC最小/最大)。"""
    bal = X + U + ETA * D + E - C - L
    rec = S[1:] - S[:-1] - ETA * C + D
    sim_cd = int(((C > 1e-6) & (D > 1e-6)).sum())
    return float(np.abs(bal).max()), float(np.abs(rec).max()), sim_cd, \
        float(S.min()), float(S.max())
