# -*- coding: utf-8 -*-
"""
问题4-3（波动电价下重算问题3）—— 光伏 + 电价 双滚动 MPC
=====================================================================
信息结构（与问题3对称地引入电价不确定性）：
  · 光伏：0/6/12/18 点四次预报(附件3)用于计划/调整决策，附件2实际光伏仅事后核验；
  · 电价：0 点用日前预测(周周期)，6/12/18 点用“当日已实现段”更新剩余段预测用于决策，
          附件4实际电价仅用于最终货币结算。
决策：阶段1 0点计划LP；阶段2 6/12/18窗口调整LP(up/dn 凸分段)；阶段3 实际核验+实际价结算。
模式（独立全年SOC链，用于回答“是否需要引入其他时刻调整/电价更新”）：
  no_adjust  仅0点计划，不调整；
  pv_only    光伏滚动更新，电价全天用日前预测；
  full       光伏+电价双滚动更新（主结果，写入 result4-3.xlsx）；
  perfect    实际光伏+实际电价的确定性最优（全信息下界）。
"""
import os
import json
import numpy as np

from q4_common import (H, ETA, N, DAYS, S_INIT, S_MIN, S_MAX, EMULT, DN_RATE, UP_RATE,
                       PUB_IDX, OUTDIR, SRCDIR, load_all, day_vector, fixed_price_lp)
from price_model import get_forecast
from lpcore import solve_deterministic, solve_adjust

OUT_NPZ = os.path.join(SRCDIR, 'q4_3_results.npz')
OUT_JSON = os.path.join(OUTDIR, '数据', 'q4_3_summary.json')
OUT_FROM = 31


def simulate_day(L, PVact, fc_day, pdec, pset, s_init,
                 stages=(36, 72, 108), pv_update=True, price_update=True):
    """pdec:(4,144)四决策点决策电价；pset:(144)实际结算价；fc_day:(4,144)光伏预报(电量)。"""
    # ---- 阶段1：0点计划（0点光伏预报 + 日前电价预测）----
    Xp, Cp, Dp, Up, Ep, Sp = solve_deterministic(L, fc_day[0], pdec[0], s_init)
    Xf, Cf, Df = Xp.copy(), Cp.copy(), Dp.copy()
    # ---- 阶段2：滚动调整 ----
    for j, i0 in zip((1, 2, 3), (36, 72, 108)):
        if i0 not in stages:
            continue
        pv = fc_day[j] if pv_update else fc_day[0]
        pr = pdec[j] if price_update else pdec[0]
        s_i0 = s_init + float((ETA * Cf[:i0] - Df[:i0]).sum())
        xa, ca, da, ua, ea, upv, dnv, Sa = solve_adjust(L, pv, pr, s_i0, Xp, i0)
        Xf[i0:], Cf[i0:], Df[i0:] = xa, ca, da
    # ---- 阶段3：实际光伏核验 ----
    gap = L + Cf - Xf - ETA * Df
    Uact = np.minimum(PVact, np.maximum(gap, 0.0))
    Eact = np.maximum(gap - PVact, 0.0)
    Sf = np.empty(N + 1); Sf[0] = s_init
    Sf[1:] = s_init + np.cumsum(ETA * Cf - Df)
    # ---- 实际电价结算 ----
    dn_f = np.maximum(Xp - Xf, 0.0); up_f = np.maximum(Xf - Xp, 0.0)
    cost_plan = float((pset * Xp).sum())
    cost_adj = float((-DN_RATE * pset * dn_f + UP_RATE * pset * up_f).sum())
    cost_em = float((EMULT * pset * Eact).sum())
    cost_buy = cost_plan + cost_adj
    return dict(Xp=Xp, Cp=Cp, Dp=Dp, Xf=Xf, Cf=Cf, Df=Df, Sf=Sf, Uact=Uact, Eact=Eact,
                plan_buy=float(Xp.sum()), final_buy=float(Xf.sum()),
                up=float(up_f.sum()), dn=float(dn_f.sum()), em_buy=float(Eact.sum()),
                cost_plan=cost_plan, cost_adj=cost_adj, cost_buy=cost_buy,
                cost_em=cost_em, cost_tot=cost_buy + cost_em,
                s0=float(s_init), s24=float(Sf[N]))


def perfect_day(L, PVact, pset, s_init):
    """全信息确定性最优（实际光伏+实际价），无紧急。"""
    X, C, D, U, E, S = solve_deterministic(L, PVact, pset, s_init)
    return dict(Xp=X, Xf=X, Cf=C, Df=D, Sf=S, Eact=np.zeros(N),
                plan_buy=float(X.sum()), final_buy=float(X.sum()), up=0.0, dn=0.0,
                em_buy=0.0, cost_plan=float((pset * X).sum()), cost_adj=0.0,
                cost_buy=float((pset * X).sum()), cost_em=0.0,
                cost_tot=float((pset * X).sum()), s0=float(s_init), s24=float(S[N]))


def run_year(inp, pred_lp, mode='full', verbose=False, settle_m=None):
    load_m, pv_m, fc_m, price_m = inp['load_m'], inp['pv_m'], inp['fc_m'], inp['price_m']
    settle_m = price_m if settle_m is None else settle_m   # 结算价（默认附件4实际价）
    recs = []; s_init = S_INIT
    for d in range(DAYS):
        L = day_vector(load_m, d) * H
        PVact = day_vector(pv_m, d) * H
        fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
        if mode == 'naive_pv':   # 光伏滚动，但电价决策全天用固定典型曲线（不做电价预测）
            fp = fixed_price_lp(inp['typ_price'])
            pdec = np.repeat(fp[None, :], 4, axis=0)
        else:
            pdec = np.stack([pred_lp[j, d] for j in range(4)])
        pset = day_vector(settle_m, d)
        if mode == 'no_adjust':
            r = simulate_day(L, PVact, fc_day, pdec, pset, s_init, stages=())
        elif mode == 'pv_only':
            r = simulate_day(L, PVact, fc_day, pdec, pset, s_init, price_update=False)
        elif mode in ('full', 'naive_pv'):
            r = simulate_day(L, PVact, fc_day, pdec, pset, s_init)
        elif mode == 'perfect':
            r = perfect_day(L, PVact, pset, s_init)
        else:
            raise ValueError(mode)
        assert r['Sf'].min() >= S_MIN - 1e-5 and r['Sf'].max() <= S_MAX + 1e-5
        r['d'] = d; r['date'] = str(inp['dates'][d])
        recs.append(r); s_init = r['s24']
    out = recs[OUT_FROM:]
    summ = dict(mode=mode,
                total=float(sum(r['cost_tot'] for r in out)),
                buy=float(sum(r['final_buy'] for r in out)),
                plan_buy=float(sum(r['plan_buy'] for r in out)),
                em_kwh=float(sum(r['em_buy'] for r in out)),
                em_cost=float(sum(r['cost_em'] for r in out)),
                adj=float(sum(r['cost_adj'] for r in out)))
    if verbose:
        print('%-10s 总费 %.2f 万元 | 购电 %.0f kWh | 紧急 %.0f kWh/%.2f 万元 | 调整费 %.2f 万元'
              % (mode, summ['total'] / 1e4, summ['buy'], summ['em_kwh'],
                 summ['em_cost'] / 1e4, summ['adj'] / 1e4))
    return recs, summ


def main():
    inp = load_all()
    fc = get_forecast(); pred_lp = fc['pred_lp']
    all_summ = {}
    full_recs = None
    for mode in ('no_adjust', 'naive_pv', 'pv_only', 'full', 'perfect'):
        recs, summ = run_year(inp, pred_lp, mode, verbose=True)
        all_summ[mode] = summ
        if mode == 'full':
            full_recs = recs
    # 价值分解
    all_summ['pv_update_value'] = all_summ['no_adjust']['total'] - all_summ['pv_only']['total']
    all_summ['price_dayahead_value'] = all_summ['naive_pv']['total'] - all_summ['pv_only']['total']
    all_summ['price_intraday_value'] = all_summ['pv_only']['total'] - all_summ['full']['total']
    all_summ['total_adjust_value'] = all_summ['no_adjust']['total'] - all_summ['full']['total']
    all_summ['EVPI'] = all_summ['full']['total'] - all_summ['perfect']['total']
    json.dump(all_summ, open(OUT_JSON, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)

    # 缓存 full 主结果逐日数组
    def stack(key):
        return np.stack([r[key] for r in full_recs])
    np.savez(OUT_NPZ,
             Xp=stack('Xp'), Xf=stack('Xf'), Cf=stack('Cf'), Df=stack('Df'),
             Sf=stack('Sf'), Eact=stack('Eact'),
             cost_tot=np.array([r['cost_tot'] for r in full_recs]),
             cost_plan=np.array([r['cost_plan'] for r in full_recs]),
             cost_adj=np.array([r['cost_adj'] for r in full_recs]),
             cost_em=np.array([r['cost_em'] for r in full_recs]))
    print('\n光伏滚动更新价值 %.2f 万元 | 电价日前预测价值 %.2f 万元 | 电价日内更新价值 %.2f 万元'
          % (all_summ['pv_update_value'] / 1e4, all_summ['price_dayahead_value'] / 1e4,
             all_summ['price_intraday_value'] / 1e4))
    print('全信息 EVPI %.2f 万元' % (all_summ['EVPI'] / 1e4))
    print('已存', OUT_NPZ)


if __name__ == '__main__':
    main()
