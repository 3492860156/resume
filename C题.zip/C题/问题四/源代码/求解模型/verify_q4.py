# -*- coding: utf-8 -*-
"""
问题4 · 独立可行性与一致性校验（不经过求解路径，从结果 xlsx / npz / 前问结果回读核对）
A. result4-2/4-3.xlsx 与求解缓存 npz 逐日一致（购电量、费用、充放电、SOC、紧急）
B. 物理可行性独立重算：母线平衡、SOC 递推与上下界、无同时充放、年末 SOC
C. 跨问回归：4-2 fixed≈问题2；4-3 naive_pv 物理量≈问题3；4-2/4-3 perfect 一致
"""
import os
import json
import glob
import numpy as np
import openpyxl

from q4_common import (H, ETA, N, DAYS, S_MIN, S_MAX, OUTDIR, SRCDIR, FOCUS,
                       load_all, day_vector, BLOCK_K, fixed_price_lp)
from lpcore import solve_deterministic

R42 = os.path.join(OUTDIR, 'result4-2.xlsx')
R43 = os.path.join(OUTDIR, 'result4-3.xlsx')
FROM = 31
ok = True


def chk(cond, msg):
    global ok
    print(('  [PASS] ' if cond else '  [FAIL] ') + msg)
    ok = ok and cond


def read_sheet_col(path, sheet, n_days, val_col_sum=146, fee_col=147):
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet]; rows = []
    for r in range(2, 2 + n_days):
        seg = [ws.cell(r, 2 + k).value for k in range(N)]
        rows.append((np.array(seg, float), ws.cell(r, val_col_sum).value,
                     ws.cell(r, fee_col).value if fee_col else None))
    return rows


def main():
    inp = load_all(); load_m, pv_m = inp['load_m'], inp['pv_m']
    z2 = np.load(os.path.join(SRCDIR, 'q4_2_results.npz'))
    z3 = np.load(os.path.join(SRCDIR, 'q4_3_results.npz'))
    dd = list(range(FROM, DAYS)); nd = len(dd)

    print('=== A. xlsx 与 npz 一致性 ===')
    # 4-2 计划购电量 = forecast_X，费用 = forecast_cost_set
    rows = read_sheet_col(R42, '计划购电量', nd)
    err_x = max(abs(rows[m][0] - z2['forecast_X'][d]).max() for m, d in enumerate(dd))
    err_f = max(abs(rows[m][1] - z2['forecast_X'][d].sum()) for m, d in enumerate(dd))
    err_c = max(abs(rows[m][2] - z2['forecast_cost_set'][d]) for m, d in enumerate(dd))
    chk(err_x < 1e-3, 'result4-2 计划购电量144段 = npz (写盘round4位, maxErr=%.2e)' % err_x)
    chk(err_f < 0.01, 'result4-2 合计列 = 段和(144段舍入累积, maxErr=%.2e)' % err_f)
    chk(err_c < 0.01, 'result4-2 费用列 = npz结算费 (maxErr=%.2e)' % err_c)
    # 4-3 计划=Xp、调整=Xf
    rp = read_sheet_col(R43, '计划购电量', nd); rf = read_sheet_col(R43, '调整购电量', nd)
    e1 = max(abs(rp[m][0] - z3['Xp'][d]).max() for m, d in enumerate(dd))
    e2 = max(abs(rf[m][0] - z3['Xf'][d]).max() for m, d in enumerate(dd))
    e3 = max(abs(rf[m][2] - z3['cost_tot'][d]) for m, d in enumerate(dd))
    chk(e1 < 1e-3 and e2 < 1e-3, 'result4-3 计划/调整144段 = npz (maxErr %.2e/%.2e)' % (e1, e2))
    chk(e3 < 0.01, 'result4-3 调整表费用列 = npz总费用 (maxErr=%.2e)' % e3)

    print('=== B. 物理可行性（独立重算，主结果）===')
    # B1 4-2 forecast：母线 X+U+ηD-C=L（e=0）；SOC递推；界
    maxbal, maxrec, cd, smin, smax = 0, 0, 0, 1e9, -1e9
    for d in dd:
        L = day_vector(load_m, d) * H
        X, C, D, U, E, S = (z2['forecast_X'][d], z2['forecast_C'][d], z2['forecast_D'][d],
                            z2['forecast_U'][d], z2['forecast_E'][d], z2['forecast_S'][d])
        maxbal = max(maxbal, abs(X + U + ETA * D + E - C - L).max())
        maxrec = max(maxrec, abs(S[1:] - S[:-1] - ETA * C + D).max())
        cd += int(((C > 1e-6) & (D > 1e-6)).sum())
        smin, smax = min(smin, S.min()), max(smax, S.max())
    chk(maxbal < 1e-7, '4-2 母线功率平衡 max残差=%.2e' % maxbal)
    chk(maxrec < 1e-7, '4-2 SOC递推 max残差=%.2e' % maxrec)
    chk(cd == 0, '4-2 无同时充放段（=%d）' % cd)
    chk(smin >= S_MIN - 1e-6 and smax <= S_MAX + 1e-6, '4-2 SOC∈[%.1f,%.1f]⊂[1200,10800]' % (smin, smax))
    chk(abs(z2['forecast_S'][-1, -1] - 1200) < 1e-4, '4-2 年末SOC=1200 (=%.2f)' % z2['forecast_S'][-1, -1])
    chk(z2['forecast_E'][FROM:].sum() < 1e-6, '4-2 全信息下紧急购电≡0 (=%.2e)' % z2['forecast_E'][FROM:].sum())
    # B2 4-3 full：实际核验 Eact=max(gap-PV,0)；SOC递推；界
    maxrec3, cd3, smin3, smax3 = 0, 0, 1e9, -1e9; em_nonneg = True; bad_cd = []
    for d in dd:
        L = day_vector(load_m, d) * H; PV = day_vector(pv_m, d) * H
        Xf, Cf, Df, Sf, E = z3['Xf'][d], z3['Cf'][d], z3['Df'][d], z3['Sf'][d], z3['Eact'][d]
        gap = L + Cf - Xf - ETA * Df
        Eexpect = np.maximum(gap - PV, 0)
        maxrec3 = max(maxrec3, abs(E - Eexpect).max(), abs(Sf[1:] - Sf[:-1] - ETA * Cf + Df).max())
        both = np.where((Cf > 1e-6) & (Df > 1e-6))[0]
        cd3 += len(both)
        for i in both:  # 合法的“计划购电刚性+再优化”叠加要求净放电 ηD-C≥0
            if ETA * Df[i] - Cf[i] < -1e-6:
                bad_cd.append((d, i, Cf[i], Df[i]))
        smin3, smax3 = min(smin3, Sf.min()), max(smax3, Sf.max())
        em_nonneg &= (E >= -1e-9).all()
    chk(maxrec3 < 1e-7, '4-3 紧急购电核验式与SOC递推 max残差=%.2e' % maxrec3)
    chk(len(bad_cd) == 0 and cd3 <= 3, '4-3 同时充放仅%d段(全年48096段)且均为净放电的边界合法解' % cd3)
    chk(smin3 >= S_MIN - 1e-6 and smax3 <= S_MAX + 1e-6, '4-3 SOC∈[%.1f,%.1f]⊂[1200,10800]' % (smin3, smax3))
    chk(em_nonneg, '4-3 紧急购电非负')

    print('=== C. 跨问回归 / 内部一致性 ===')
    # C1 4-2 fixed ≈ 问题2
    q2 = json.load(open(glob.glob(os.path.join(OUTDIR, '..', '问题二', '数据', 'q2_fresh_results.json'))[0], encoding='utf-8'))
    o = q2['daily'][FROM:]
    q2_buy = sum(r['buy'] for r in o); q2_cost = sum(r['cost_plan'] for r in o)
    f_buy = z2['fixed_X'][FROM:].sum(); f_cost = z2['fixed_cost_set'][FROM:].sum()
    chk(abs(f_buy - q2_buy) / q2_buy < 1e-6, '4-2 fixed购电量 %.1f ≈ 问题2 %.1f (相对%.1e)'
        % (f_buy, q2_buy, abs(f_buy - q2_buy) / q2_buy))
    chk(abs(f_cost - q2_cost) / q2_cost < 1e-6, '4-2 fixed费用 %.2f ≈ 问题2 %.2f (相对%.1e)'
        % (f_cost, q2_cost, abs(f_cost - q2_cost) / q2_cost))
    # C2 4-3 naive_pv 物理量 ≈ 问题3（固定电价形状决策，物理应一致，货币随电价变）
    q3 = json.load(open(glob.glob(os.path.join(OUTDIR, '..', '问题三', '数据', 'q3_full_results.json'))[0], encoding='utf-8'))
    o3 = q3['daily'][FROM:]
    q3_em = sum(r['em_buy'] for r in o3); q3_buy = sum(r['final_buy'] for r in o3)
    s3 = json.load(open(os.path.join(OUTDIR, '数据', 'q4_3_summary.json'), encoding='utf-8'))
    chk(abs(s3['naive_pv']['em_kwh'] - q3_em) < 1, '4-3 naive_pv紧急电量 %.1f ≈ 问题3 %.1f kWh'
        % (s3['naive_pv']['em_kwh'], q3_em))
    chk(abs(s3['naive_pv']['buy'] - q3_buy) / q3_buy < 1e-5, '4-3 naive_pv最终购电 ≈ 问题3 (相对%.1e)'
        % (abs(s3['naive_pv']['buy'] - q3_buy) / q3_buy))
    # C3 4-2 perfect 与 4-3 perfect 全年费用一致（同一全信息确定性最优）
    p2 = z2['perfect_cost_set'][FROM:].sum(); p3 = s3['perfect']['total']
    chk(abs(p2 - p3) < 1, '4-2/4-3 perfect 全年费用一致 (%.2f vs %.2f)' % (p2, p3))
    # C4 指定日：固定典型电价(naive口径)0点计划应与问题3严格一致；
    #    full 主口径因跨午夜段采用次日预测水平，允许 <1% 的合理偏差
    dstr = [str(x) for x in inp['dates']]
    typ_lp = fixed_price_lp(inp['typ_price'])
    for f in FOCUS:
        d = dstr.index(f); q3f = next(r for r in o3 if r['date'] == f)
        L = day_vector(inp['load_m'], d) * H; fc0 = inp['fc_m'][0, d] * H
        Xn, *_ = solve_deterministic(L, fc0, typ_lp, float(z3['Sf'][d, 0]))
        chk(abs(Xn.sum() - q3f['plan_buy']) < 1,
            '%s 固定电价口径0点计划 %.2f ≈ 问题3 %.2f（物理链路一致）' % (f, Xn.sum(), q3f['plan_buy']))
        rel = abs(z3['Xp'][d].sum() - q3f['plan_buy']) / q3f['plan_buy']
        chk(rel < 0.01,
            '%s full预测口径计划与问题3相对差 %.3f%%（跨午夜段用次日水平，<1%%）' % (f, 100 * rel))

    print('\n================ 总体：%s ================' % ('全部通过 ✅' if ok else '存在未通过项 ❌'))
    return ok


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
