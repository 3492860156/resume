# -*- coding: utf-8 -*-
"""
2026 国赛 C 题 · 问题 4 —— 公共数据 / 时间口径 / 物理常量模块
=====================================================================
职责：
  1) 读取 附件1(典型日固定电价)、附件2(全年负载/实际光伏)、附件3(光伏预报)、
     附件4(全年实时波动电价)；
  2) 统一【严格时间口径】（问题四自身严格自洽）：
       自然段 t=0..143 对应自然区间 [10t,10(t+1)) 分钟；附件2/4 的第 c 个数据列
       (列头为结束时刻 10(c+1)) 即自然段 c。
       LP 序(day_vector 序) i=0..143：
            i=0..142  -> 当日自然段 i+1（区间 [10(i+1),10(i+2))）
            i=143     -> 次日自然段 0（跨午夜 [次日0:00,0:10)）
       于是 LP 段 i 的“绝对自然小时”(自当日0点) H_i = (i+1)//6 (i<143)，i=143->24。
       写模板时 LP 段 i 直接对应模板第 2+i 列（模板列 0:10-0:20 即自然段1），无需逆变换。
  3) 附件3 光伏预报展开到 LP 序（默认严格口径 H_i=(i+1)//6；legacy=True 可复现问题三
     的 i//6 口径，用于对照、证明结论对 1 段(10min) 错位稳健）。

单位：附件功率 kW × H(=1/6h) -> 电量 kWh；电价 元/kWh × 电量 -> 元。
"""
import os
import numpy as np
import pandas as pd

# ----------------------------- 路径 -----------------------------
ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')
ATT3 = os.path.join(ROOT, '附件', '附件3.xlsx')
ATT4 = os.path.join(ROOT, '附件', '附件4.xlsx')
TPL42 = os.path.join(ROOT, '附件', '附件5', 'result4-2.xlsx')
TPL43 = os.path.join(ROOT, '附件', '附件5', 'result4-3.xlsx')
OUTDIR = os.path.join(ROOT, '问题四')
SRCDIR = os.path.join(OUTDIR, '源代码', '求解模型')
CLEAN_DIR = os.path.join(OUTDIR, '源代码', '数据清洗')
FIGDIR = os.path.join(OUTDIR, '可视化')
DOCDIR = os.path.join(OUTDIR, '文档资料')
for _d in (SRCDIR, CLEAN_DIR, FIGDIR, DOCDIR):
    os.makedirs(_d, exist_ok=True)

# ----------------------------- 物理常量（附录1） -----------------------------
H = 1.0 / 6.0        # 10 分钟 = 1/6 小时
ETA = 0.9            # 充/放电效率
P_MAX = 5000.0       # 最大充放电功率 kW
E_MAX = P_MAX * H    # 单段最大充/放电量 = 833.3333 kWh
S_MIN, S_MAX = 1200.0, 10800.0
S_INIT = 6000.0      # 2025-01-01 0:00 储电量
N = 144
DAYS = 365
EMULT = 5.0          # 紧急购电倍数
DN_RATE, UP_RATE = 0.5, 1.5     # 下调违约 0.5P、上调溢价 1.5P
PUB_HOURS = [0, 6, 12, 18]
PUB_IDX = [h * 6 for h in PUB_HOURS]   # 0/36/72/108（LP 序下 6/12/18 点决策起点）

FOCUS = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
BLOCK_NAMES = ['0:00-4:00', '4:00-8:00', '8:00-12:00', '12:00-16:00',
               '16:00-20:00', '20:00-24:00']
BLOCK_K = [(list(range(0, 23)), 143), (list(range(23, 47)), None),
           (list(range(47, 71)), None), (list(range(71, 95)), None),
           (list(range(95, 119)), None), (list(range(119, 143)), None)]
T1_SPECS = [('10:00-10:10', 59), ('12:00-12:10', 71), ('14:00-14:10', 83),
            ('16:00-16:10', 95), ('18:00-18:10', 107), ('20:00-20:10', 119)]


# ----------------------------- 时间口径工具 -----------------------------
def day_vector(mat, d):
    """自然列序矩阵(365,144) -> 第 d 天的 LP 序向量(144,)。
    v[0..142]=mat[d,1..143]（当日自然段1..143）；v[143]=次日自然段0（年末退回本列）。"""
    v = np.empty(N)
    v[:N - 1] = mat[d, 1:N]
    v[N - 1] = mat[d + 1, 0] if d + 1 < DAYS else mat[d, N - 1]
    return v


def lp_abs_hour(i):
    """LP 段 i 的绝对自然小时（自当日0点）；i=143 为次日0点=24。"""
    return (i + 1) // 6 if i < N - 1 else 24


def natural_order(v):
    """LP 序 -> 自然序 [0:00,24:00)：把 v[143](次日0:10段) 提到最前。最后一维=144。"""
    return np.concatenate([v[..., [143]], v[..., :143]], axis=-1)


# ----------------------------- 数据读取 -----------------------------
_inputs = None
def load_all(legacy_forecast=True):
    """返回 dict:
       typ_price (144,) 附件1典型日电价(自然列序 0:10..24:00)；
       load_m,pv_m (365,144) 附件2 实际负载/光伏功率(自然列序)；
       fc_m (4,365,144) 附件3 光伏预报功率【LP 序】；
       price_m (365,144) 附件4 实时电价(自然列序)；dates (365,)。
    主口径 legacy_forecast=True：沿用问题3的预报展开(段i↔小时 i//6)。
       数据检验：该口径下“预报-实际”偏差最小、且能精确复现问题3全部结果，
       说明附件3预报与附件2实际即按此约定对齐；为保证“重算问题3”只改变电价
       这一个变量、结果可直接比较，主结果采用之。legacy=False 的严格口径仅作
       敏感性对照。"""
    global _inputs
    if _inputs is not None and _inputs.get('legacy') == legacy_forecast:
        return _inputs
    att1 = pd.read_excel(ATT1)
    typ_price = att1['电价'].to_numpy(float)          # 自然列序 144
    assert len(typ_price) == N

    load_df = pd.read_excel(ATT2, sheet_name='小区负载')
    pv_df = pd.read_excel(ATT2, sheet_name='光伏发电实际功率')
    load_m = load_df.iloc[:, 1:].to_numpy(float)
    pv_m = pv_df.iloc[:, 1:].to_numpy(float)
    assert load_m.shape == (DAYS, N) and pv_m.shape == (DAYS, N)
    dates = pd.to_datetime(load_df.iloc[:, 0]).dt.date.to_numpy()

    price_m = pd.read_excel(ATT4).iloc[:, 1:].to_numpy(float)   # 附件4 自然列序
    assert price_m.shape == (DAYS, N)
    assert not np.isnan(price_m).any() and (price_m > 0).all()  # 数据质量：无缺失/非负

    fc_m = build_forecast_matrix(legacy=legacy_forecast)        # (4,365,144) LP 序
    _inputs = dict(typ_price=typ_price, load_m=load_m, pv_m=pv_m,
                   fc_m=fc_m, price_m=price_m, dates=dates, legacy=legacy_forecast)
    return _inputs


def build_forecast_matrix(legacy=False):
    """解析附件3 -> fc_m shape=(4,365,144)，段维为【LP 序】(与 day_vector 同序)。
    发布小时 m，预报列 idx=H_i-m（预报第 idx+1 小时 = 绝对小时 [m+idx,m+idx+1)）。
    严格口径 H_i=(i+1)//6；legacy 口径 H_i=i//6（复现问题三，仅对照用）。
    越界(历史段/超24h)置0（夜间无光伏）。"""
    a3 = pd.read_excel(ATT3)
    a3['日期'] = a3['日期'].ffill()
    fc_cols = [f'预报{i}小时' for i in range(1, 25)]
    a3['d'] = pd.to_datetime(a3['日期']).dt.dayofyear - 1
    fc_nat = np.zeros((4, DAYS, N))           # 先在自然段轴填充
    for j, m in enumerate(PUB_HOURS):
        sub = a3[a3['预报时刻'] == f'{m}:00']
        for _, r in sub.iterrows():
            d = int(r['d'])
            fv = r[fc_cols].to_numpy(float)
            for t in range(N):               # 自然段 t 的绝对小时 = t//6
                H = t // 6
                idx = H - m
                if 0 <= idx <= 23:
                    fc_nat[j, d, t] = fv[idx]
    if legacy:
        # 问题三口径：直接把自然段轴当作 LP 轴（等价 H_i=i//6）
        return fc_nat
    # 严格口径：自然段轴 -> LP 序（LP 段 i = 自然段 i+1，i=143=次日自然段0）
    fc_lp = np.zeros((4, DAYS, N))
    for d in range(DAYS):
        for j in range(4):
            fc_lp[j, d, :N - 1] = fc_nat[j, d, 1:N]
            fc_lp[j, d, N - 1] = fc_nat[j, d + 1, 0] if d + 1 < DAYS else 0.0
    return fc_lp


def fixed_price_lp(typ_price):
    """附件1 典型电价(自然列序) -> LP 序固定电价向量(全年相同, 复现问题2/3)。"""
    return np.concatenate([typ_price[1:], typ_price[:1]])


if __name__ == '__main__':
    inp = load_all()            # 默认 legacy（同问题3）
    print('typ_price', inp['typ_price'].shape, 'load/pv', inp['load_m'].shape,
          'fc', inp['fc_m'].shape, 'price', inp['price_m'].shape)
    fc = inp['fc_m'][0, 0]
    # legacy 口径（同问题3）：8:00-9:00 预报落在 LP 段 48..53
    print('1/1 0点发布 LP段48..53(legacy, 应全为预报9小时3409.09):', np.round(fc[48:54], 2))
    inp2 = load_all(legacy_forecast=False)
    print('严格口径 LP段47..52:', np.round(inp2['fc_m'][0, 0, 47:53], 2))
