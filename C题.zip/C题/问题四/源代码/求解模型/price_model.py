# -*- coding: utf-8 -*-
"""
问题4 · 附件4 实时电价的【数据清洗 + 因果预测】模型
=====================================================================
数据探查结论（独立计算、数据隔离）：
  附件4(天d,段t) = 典型日内曲线 typ[t](=附件1, 365天逐时段均值与它完全重合)
                   × 日价格水平因子(强周周期, lag7 自相关0.964)
                   × 日内高频毛刺(占乘性方差约39%, 相邻段p99跳变0.37)
主预测口径（数据清洗 + 决策成本双重准则选定）：clean_weekly
  探查证实 附件4 = 典型日内形状 typ × 日水平因子(强周周期) × 日内随机毛刺；
  储能 LP 的最优物理决策只对价格的“时段相对排序”敏感、对整体水平缩放不敏感，
  而日内毛刺不可预测且会误导排序。故主口径剔除毛刺、只外推可预测分量：
  日前(0:00) 预测 = 同星期(lag7,14)日水平因子均值 × 典型形状 typ（光滑曲线）；
  d<14 用可得同星期日，d<7 冷启动用已实现日水平均值，1/1 用 typ。
日内更新(6/12/18)：用当日已实现段比值收缩估计当日水平，未来段=更新水平×typ；
  已实现段取实际值。（weekly=直接搬上周曲线、level=前7天水平，仅敏感性对照。）
严格因果：任一预测只用该决策时刻之前已实现的数据，绝不用当日未来段（无前视偏差）。
原始电价 P 完整保留用于真实结算；清洗/预测只服务决策。
"""
import os
import numpy as np

from q4_common import (N, DAYS, PUB_IDX, load_all, day_vector, SRCDIR)

CACHE = os.path.join(SRCDIR, 'price_forecast.npz')
WEEKLY_LAGS = (7, 14)        # 同星期历史日


def trimmed_mean(x, trim=0.10):
    """截尾均值：去两端各 trim 比例后平均（抗毛刺）。"""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return np.nan
    xs = np.sort(x)
    k = int(np.floor(trim * xs.size))
    seg = xs[k:xs.size - k] if xs.size - 2 * k > 0 else xs
    return float(seg.mean())


def clean_level(price_m, typ, trim=0.10):
    """清洗：日水平因子 a_d=截尾均值(P/typ)，清洗曲线=a_d·typ（自然列序）。"""
    level = np.empty(DAYS)
    for d in range(DAYS):
        level[d] = trimmed_mean(price_m[d] / typ, trim)
    clean = level[:, None] * typ[None, :]
    return level, clean


def dayahead_curve(price_m, level, typ, d, method='clean_weekly', lags=WEEKLY_LAGS):
    """第 d 天日前(0点)预测曲线（自然列序），严格只用 d 之前数据。
    返回 (预测曲线144, 日前日水平a0)。"""
    if method == 'clean_weekly':
        idxs = [d - k for k in lags if d - k >= 0]
        if idxs:
            a0 = float(level[idxs].mean())
        elif d > 0:
            a0 = float(level[:d].mean())
        else:
            a0 = 1.0
        return a0 * typ, a0
    if method == 'weekly':      # 直接搬同星期日同时段曲线（含其日内形状，对照用）
        idxs = [d - k for k in lags if d - k >= 0]
        if idxs:
            return price_m[idxs].mean(axis=0), trimmed_mean(price_m[idxs].mean(0) / typ)
        a0 = float(level[:d].mean()) if d > 0 else 1.0
        return a0 * typ, a0
    if method == 'level':       # 前7天水平因子×typ
        a0 = float(level[max(0, d - 7):d].mean()) if d > 0 else 1.0
        return a0 * typ, a0
    raise ValueError(method)


def build_forecast(price_m, typ, method='clean_weekly', lags=WEEKLY_LAGS, trim=0.10):
    """生成 4 决策点预测。返回 level,clean,pred_nat(4,365,144 自然序),pred_lp(LP序)。"""
    level, clean = clean_level(price_m, typ, trim)
    pred_nat = np.zeros((4, DAYS, N))
    for d in range(DAYS):
        da, a0 = dayahead_curve(price_m, level, typ, d, method, lags)
        for j, i0 in enumerate(PUB_IDX):          # 0/36/72/108
            if j == 0:
                pred_nat[j, d] = da
                continue
            realized = slice(0, i0 + 1)            # 当日已实现自然段
            r = trimmed_mean(price_m[d, realized] / typ[realized], trim) / a0
            w = (i0 + 1) / N                       # 已实现占比收缩
            a_j = a0 * (w * r + (1 - w))           # 更新后当日水平
            pred = a_j * typ
            pred[realized] = price_m[d, realized]
            pred_nat[j, d] = pred
    pred_lp = np.zeros_like(pred_nat)
    for j in range(4):
        for d in range(DAYS):
            pred_lp[j, d] = day_vector(pred_nat[j], d)
    return level, clean, pred_nat, pred_lp


def accuracy(price_m, pred_nat, out_from=31):
    """预测精度（输出区间 d>=31）。"""
    res = {}
    actual = price_m[out_from:]
    p0 = pred_nat[0, out_from:]
    res['dayahead'] = dict(MAE=float(np.abs(actual - p0).mean()),
                           MAPE=float(100 * (np.abs(actual - p0) / actual).mean()))
    for j, i0 in zip((1, 2, 3), PUB_IDX[1:]):
        fut = slice(i0 + 1, N)
        a, p = price_m[out_from:, fut], pred_nat[j, out_from:, fut]
        p0f = pred_nat[0, out_from:, fut]
        res[f'update_{i0}'] = dict(MAE=float(np.abs(a - p).mean()),
                                   MAPE=float(100 * (np.abs(a - p) / a).mean()))
        res[f'dayahead_{i0}'] = dict(MAE=float(np.abs(a - p0f).mean()),
                                     MAPE=float(100 * (np.abs(a - p0f) / a).mean()))
    return res


def get_forecast(method='clean_weekly', force=False, cache=True):
    """主入口（带缓存，方法变了请 force）。"""
    if cache and (not force) and os.path.exists(CACHE):
        z = np.load(CACHE)
        out = {k: z[k] for k in z.files}
        out['acc'] = accuracy(out['price_m'], out['pred_nat'])
        return out
    inp = load_all()
    typ, price_m = inp['typ_price'], inp['price_m']
    level, clean, pred_nat, pred_lp = build_forecast(price_m, typ, method=method)
    acc = accuracy(price_m, pred_nat)
    out = dict(level=level, clean=clean, pred_nat=pred_nat, pred_lp=pred_lp,
               typ=typ, price_m=price_m)
    if cache:
        np.savez(CACHE, **out)
    out['acc'] = acc
    return out


if __name__ == '__main__':
    fc = get_forecast(force=True)
    print('=== 主口径(clean_weekly 同星期水平×典型形状) 电价预测精度（2.1-12.31）===')
    for k, v in fc['acc'].items():
        print('  %-12s MAE=%.4f  MAPE=%.2f%%' % (k, v['MAE'], v['MAPE']))
    lv = fc['level']
    print('日水平因子 mean=%.4f std=%.4f [%.3f,%.3f]' % (lv.mean(), lv.std(), lv.min(), lv.max()))
    print('缓存 ->', CACHE)
