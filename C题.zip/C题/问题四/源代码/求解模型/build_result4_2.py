# -*- coding: utf-8 -*-
"""
填充 result4-2.xlsx（波动电价下重算问题2，主结果=forecast 情景）
严格复刻问题2写盘口径：计划购电量334行(144段+合计+实际结算费)、充放电量334×6行、
紧急购电量334天日期行（全信息 e≡0，无紧急段）；写后回读校验。
"""
import os
import datetime as dt
import numpy as np
import openpyxl

from q4_common import (N, DAYS, TPL42, OUTDIR, FOCUS, BLOCK_NAMES, BLOCK_K,
                       T1_SPECS, load_all)
from solve_q4_2 import OUT_NPZ, OUT_FROM

OUT_XLSX = os.path.join(OUTDIR, 'result4-2.xlsx')


def main():
    z = np.load(OUT_NPZ)
    X, C, D, S = z['forecast_X'], z['forecast_C'], z['forecast_D'], z['forecast_S']
    cost_set = z['forecast_cost_set']
    inp = load_all(); dates = inp['dates']

    # 组装 365 天记录（含 s0/s24 口径，复刻问题2）
    recs = []
    for d in range(DAYS):
        s0 = 6000.0 if d == 0 else float(S[d - 1][N - 1])
        recs.append(dict(date=str(dates[d]), X=X[d], C=C[d], D=D[d], S=S[d],
                         s0=s0, s24=float(S[d][N - 1]), cost=float(cost_set[d])))
    out = recs[OUT_FROM:]
    assert len(out) == 334

    wb = openpyxl.load_workbook(TPL42)
    # 1) 计划购电量
    ws1 = wb['计划购电量']
    for m, r in enumerate(out):
        row = 2 + m
        tpl = ws1.cell(row, 1).value
        assert str(tpl.date()) == r['date'], (row, tpl, r['date'])
        for k in range(N):
            ws1.cell(row, 2 + k, round(float(r['X'][k]), 4))
        ws1.cell(row, 146, round(sum(round(float(r['X'][k]), 4) for k in range(N)), 4))
        ws1.cell(row, 147, round(r['cost'], 2))
    # 2) 充放电量
    ws2 = wb['充放电量']
    if ws2.max_row >= 2:
        ws2.delete_rows(2, ws2.max_row - 1)
    prev_recs = [recs[OUT_FROM - 1]] + out[:-1]
    for m, r in enumerate(out):
        r0 = 2 + 6 * m
        dval = dt.datetime.strptime(r['date'], '%Y-%m-%d')
        prev = prev_recs[m]
        for bi in range(6):
            rr = r0 + bi
            ks, extra = BLOCK_K[bi]
            chg = float(r['C'][ks].sum()); dis = float(r['D'][ks].sum())
            if bi == 0:
                ws2.cell(rr, 1, dval).number_format = 'mm-dd-yy'
                ws2.cell(rr, 5, dt.time(0, 0)); ws2.cell(rr, 6, round(r['s0'], 4))
                chg += float(prev['C'][extra]); dis += float(prev['D'][extra])
            elif bi == 1:
                ws2.cell(rr, 5, '24:00'); ws2.cell(rr, 6, round(r['s24'], 4))
            ws2.cell(rr, 2, BLOCK_NAMES[bi])
            ws2.cell(rr, 3, round(chg, 4)); ws2.cell(rr, 4, round(dis, 4))
    # 3) 紧急购电量（全信息 e≡0，仅日期行）
    ws3 = wb['紧急购电量']
    if ws3.max_row >= 2:
        ws3.delete_rows(2, ws3.max_row - 1)
    for m, r in enumerate(out):
        r0 = 2 + 3 * m
        dval = dt.datetime.strptime(r['date'], '%Y-%m-%d')
        ws3.cell(r0, 1, dval).number_format = 'mm-dd-yy'

    try:
        wb.save(OUT_XLSX)
    except PermissionError:
        OUT_XLSX_LOCAL = OUT_XLSX.replace('.xlsx', '_副本.xlsx')
        wb.save(OUT_XLSX_LOCAL); OUT_XLSX_LOCAL = None
    print('已保存', OUT_XLSX)

    # ---- 回读校验 ----
    chk = openpyxl.load_workbook(OUT_XLSX, data_only=True)
    c1, c2, c3 = chk['计划购电量'], chk['充放电量'], chk['紧急购电量']
    assert c1.max_row == 335 and c2.max_row == 2005, c1.max_row
    d1 = [c1.cell(r, 1).value.date() for r in range(2, 336)]
    assert d1[0] == dt.date(2025, 2, 1) and d1[-1] == dt.date(2025, 12, 31) and len(d1) == 334
    for r in range(2, 336):
        v = [c1.cell(r, 2 + k).value for k in range(N)]
        assert abs(sum(v) - c1.cell(r, 146).value) < 0.01
    n2 = sum(1 for r in range(2, c2.max_row + 1) if c2.cell(r, 1).value is not None)
    assert n2 == 334
    em = [c3.cell(r, c).value for r in range(2, c3.max_row + 1) for c in (2, 3)
          if c3.cell(r, c).value not in (None, '')]
    assert em == []
    for ws in (c1, c2, c3):
        for row in ws.iter_rows(values_only=True):
            assert '⁝' not in row
    print('回读校验通过：计划购电量334天/充放电2004行/紧急购电全空/无省略符')


if __name__ == '__main__':
    main()
