# -*- coding: utf-8 -*-
"""
填充 result4-3.xlsx（波动电价下重算问题3，主结果=full 光伏+电价双滚动）
四张表：计划购电量(Xp)、调整购电量(Xf最终)、充放电量(Cf/Df最终,6块)、
紧急购电量(Eact 连续段合并)。口径复刻问题3 build_result3，写后回读校验。
"""
import os
import datetime as dt
import numpy as np
import openpyxl

from q4_common import (N, DAYS, TPL43, OUTDIR, BLOCK_NAMES, BLOCK_K, load_all)
from solve_q4_3 import OUT_NPZ, OUT_FROM

OUT_XLSX = os.path.join(OUTDIR, 'result4-3.xlsx')


def seg_time_label(a, b):
    """连续紧急段[a..b] -> 'HH:MM-HH:MM'（LP段i区间[(i+1)*10,(i+2)*10)）。"""
    s, e = (a + 1) * 10, (b + 2) * 10

    def f(m):
        tag = '+1' if m >= 1440 else ''
        m %= 1440
        return '%d:%02d%s' % (m // 60, m % 60, tag)
    return f(s) + '-' + f(e)


def merge_emergency(E, thr=1e-6):
    out, i = [], 0
    while i < N:
        if E[i] > thr:
            a = i
            while i + 1 < N and E[i + 1] > thr:
                i += 1
            out.append((seg_time_label(a, i), float(E[a:i + 1].sum())))
        i += 1
    return out


def main():
    z = np.load(OUT_NPZ)
    Xp, Xf, Cf, Df, Sf, Eact = z['Xp'], z['Xf'], z['Cf'], z['Df'], z['Sf'], z['Eact']
    cost_plan, cost_tot = z['cost_plan'], z['cost_tot']
    inp = load_all(); dates = inp['dates']
    dd = list(range(OUT_FROM, DAYS))
    assert len(dd) == 334

    wb = openpyxl.load_workbook(TPL43)
    # 1) 计划购电量 / 2) 调整购电量
    for sheet, X, cost in [('计划购电量', Xp, cost_plan), ('调整购电量', Xf, cost_tot)]:
        ws = wb[sheet]
        for m, d in enumerate(dd):
            row = 2 + m
            tpl = ws.cell(row, 1).value
            assert str(tpl.date()) == str(dates[d]), (row, tpl, dates[d])
            for k in range(N):
                ws.cell(row, 2 + k, round(float(X[d, k]), 4))
            ws.cell(row, 146, round(sum(round(float(X[d, k]), 4) for k in range(N)), 4))
            ws.cell(row, 147, round(float(cost[d]), 2))
    # 3) 充放电量（最终 Cf/Df，块0借前一日末段）
    ws2 = wb['充放电量']
    if ws2.max_row >= 2:
        ws2.delete_rows(2, ws2.max_row - 1)
    for m, d in enumerate(dd):
        r0 = 2 + 6 * m
        dval = dt.datetime.strptime(str(dates[d]), '%Y-%m-%d')
        prev_d = d - 1
        for bi in range(6):
            rr = r0 + bi
            ks, extra = BLOCK_K[bi]
            chg = float(Cf[d, ks].sum()); dis = float(Df[d, ks].sum())
            if bi == 0:
                ws2.cell(rr, 1, dval).number_format = 'mm-dd-yy'
                ws2.cell(rr, 5, dt.time(0, 0)); ws2.cell(rr, 6, round(float(Sf[d, 0]), 4))
                chg += float(Cf[prev_d, extra]); dis += float(Df[prev_d, extra])
            elif bi == 1:
                ws2.cell(rr, 5, '24:00'); ws2.cell(rr, 6, round(float(Sf[d, N - 1]), 4))
            ws2.cell(rr, 2, BLOCK_NAMES[bi])
            ws2.cell(rr, 3, round(chg, 4)); ws2.cell(rr, 4, round(dis, 4))
    # 4) 紧急购电量（连续段动态展开）
    ws3 = wb['紧急购电量']
    if ws3.max_row >= 2:
        ws3.delete_rows(2, ws3.max_row - 1)
    rr = 2; n_seg = 0
    for d in dd:
        dval = dt.datetime.strptime(str(dates[d]), '%Y-%m-%d')
        segs = merge_emergency(Eact[d])
        if not segs:
            ws3.cell(rr, 1, dval).number_format = 'mm-dd-yy'; rr += 1; continue
        for si, (lab, q) in enumerate(segs):
            if si == 0:
                ws3.cell(rr, 1, dval).number_format = 'mm-dd-yy'
            ws3.cell(rr, 2, lab); ws3.cell(rr, 3, round(q, 4)); rr += 1; n_seg += 1
    try:
        wb.save(OUT_XLSX)
    except PermissionError:
        wb.save(OUT_XLSX.replace('.xlsx', '_副本.xlsx'))
    print('已保存', OUT_XLSX, '| 紧急段数', n_seg)

    # ---- 回读校验 ----
    chk = openpyxl.load_workbook(OUT_XLSX, data_only=True)
    c1, c2, c3, c4 = (chk['计划购电量'], chk['调整购电量'],
                      chk['充放电量'], chk['紧急购电量'])
    assert c1.max_row == 335 and c2.max_row == 335
    assert c3.max_row == 2005
    for c in (c1, c2):
        d1 = [c.cell(r, 1).value.date() for r in range(2, 336)]
        assert d1[0] == dt.date(2025, 2, 1) and d1[-1] == dt.date(2025, 12, 31)
        for r in range(2, 336):
            v = [c.cell(r, 2 + k).value for k in range(N)]
            assert abs(sum(v) - c.cell(r, 146).value) < 0.01
    n_dates = sum(1 for r in range(2, c4.max_row + 1) if c4.cell(r, 1).value is not None)
    assert n_dates == 334
    n_got = sum(1 for r in range(2, c4.max_row + 1) if c4.cell(r, 2).value)
    assert n_got == n_seg
    for ws in (c1, c2, c3, c4):
        for row in ws.iter_rows(values_only=True):
            assert '⁝' not in row
    print('回读校验通过：计划/调整各334天、充放电2004行、紧急%d段、无省略符' % n_got)


if __name__ == '__main__':
    main()
