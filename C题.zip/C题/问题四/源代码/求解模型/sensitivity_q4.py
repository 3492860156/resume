# -*- coding: utf-8 -*-
"""
问题4 · 敏感性与稳健性分析（用户要求置于主结果之后）
维度：
  S1 电价预测方法（typ / 前7天水平 / 同星期水平×形状[主] / 同星期曲线）
  S2 清洗截尾比例 trim（0.05/0.10/0.15/0.20）
  S3 电价波动幅度 alpha（0/0.5/1/1.5/2，围绕典型曲线缩放偏离）
  S4 硬件参数龙卷风（充放效率 eta / 功率 P_MAX / 储能容量 S_MAX）
  S5 光伏预报展开口径 legacy(同问题3,主) vs strict(严格)
全部全年(365天递推,汇总334天)重解，保证 SOC 连续；结果存 sensitivity_q4.json。
"""
import os
import json
import numpy as np
from scipy.optimize import linprog

from q4_common import (H, N, DAYS, S_INIT, S_MIN, S_MAX, ETA, E_MAX, EMULT,
                       OUTDIR, SRCDIR, load_all, day_vector, fixed_price_lp)
from price_model import build_forecast, get_forecast
from solve_q4_3 import run_year

OUT_JSON = os.path.join(OUTDIR, '数据', 'sensitivity_q4.json')
FROM = 31


def det_param(L, PV, price, s_init, eta=ETA, e_max=E_MAX, s_min=S_MIN, s_max=S_MAX, emult=EMULT):
    """参数化单日确定性 LP（不改动主求解器，专供硬件敏感性）。"""
    nv = 5 * N + (N + 1)
    off = {'x': 0, 'c': N, 'd': 2 * N, 'u': 3 * N, 'e': 4 * N, 'S': 5 * N}
    vid = lambda i, k: off[k] + i
    obj = np.zeros(nv); obj[off['x']:off['x'] + N] = price; obj[off['e']:off['e'] + N] = emult * price
    A = np.zeros((2 * N, nv)); b = np.zeros(2 * N)
    for i in range(N):
        A[i, vid(i, 'x')] = 1; A[i, vid(i, 'u')] = 1; A[i, vid(i, 'd')] = eta
        A[i, vid(i, 'e')] = 1; A[i, vid(i, 'c')] = -1; b[i] = L[i]
        A[N + i, vid(i + 1, 'S')] = 1; A[N + i, vid(i, 'S')] = -1
        A[N + i, vid(i, 'c')] = -eta; A[N + i, vid(i, 'd')] = 1
    bounds = [(0.0, None)] * nv
    for i in range(N):
        bounds[vid(i, 'c')] = (0, e_max); bounds[vid(i, 'd')] = (0, e_max); bounds[vid(i, 'u')] = (0, PV[i])
    for i in range(N + 1):
        bounds[vid(i, 'S')] = (s_min, s_max)
    bounds[vid(0, 'S')] = (s_init, s_init)
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        return None
    g = lambda k: res.x[off[k]:off[k] + N]
    return g('x'), g('c'), g('d'), g('u'), g('e'), res.x[off['S']:off['S'] + N + 1]


def run_det_year(inp, dec_nat, set_nat, **hw):
    """决策价/结算价均为自然列序(365,144)，全年逐日参数化LP。返回334天汇总。"""
    load_m, pv_m = inp['load_m'], inp['pv_m']
    s = S_INIT; cost = 0.0; buy = 0.0
    for d in range(DAYS):
        L = day_vector(load_m, d) * H; PV = day_vector(pv_m, d) * H
        pd_ = day_vector(dec_nat, d); ps_ = day_vector(set_nat, d)
        out = det_param(L, PV, pd_, s, **hw)
        if out is None:
            return dict(settle=np.nan, buy=np.nan)
        x, c, dd, u, e, ss = out
        if d >= FROM:
            cost += float((ps_ * x).sum()); buy += float(x.sum())
        s = float(ss[N])
    return dict(settle=cost, buy=buy)


def mape(dec_nat, pm):
    return float(100 * (np.abs(pm[FROM:] - dec_nat[FROM:]) / pm[FROM:]).mean())


def main():
    inp = load_all(); typ, pm = inp['typ_price'], inp['price_m']
    typ_rep = np.repeat(typ[None, :], DAYS, 0)
    fc_main = get_forecast(); pred_main = fc_main['pred_nat'][0]
    res = {}

    # ---------- S1 预测方法 ----------
    print('S1 预测方法...'); s1 = {}
    cands = {'典型曲线': (typ_rep, None)}
    for m in ('level', 'clean_weekly', 'weekly'):
        _, _, pn, _ = build_forecast(pm, typ, method=m); cands[m] = (pn[0], m)
    name = {'典型曲线': '典型曲线(忽略波动)', 'level': '前7天日水平×形状',
            'clean_weekly': '同星期水平×形状(主口径)', 'weekly': '同星期同时段曲线'}
    for key, (dec, _) in cands.items():
        r = run_det_year(inp, dec, pm)
        s1[key] = dict(name=name[key], mape=mape(dec, pm), settle_wan=r['settle'] / 1e4)
        print('  %-14s MAPE %.2f%%  结算 %.2f 万' % (key, s1[key]['mape'], s1[key]['settle_wan']))
    res['S1_method'] = s1

    # ---------- S2 清洗 trim ----------
    print('S2 截尾比例...'); s2 = {}
    for tr in (0.05, 0.10, 0.15, 0.20):
        _, _, pn, _ = build_forecast(pm, typ, method='clean_weekly', trim=tr)
        r = run_det_year(inp, pn[0], pm)
        s2[str(tr)] = dict(mape=mape(pn[0], pm), settle_wan=r['settle'] / 1e4)
        print('  trim=%.2f MAPE %.2f%% 结算 %.2f 万' % (tr, s2[str(tr)]['mape'], s2[str(tr)]['settle_wan']))
    res['S2_trim'] = s2

    # ---------- S3 波动幅度 ----------
    print('S3 波动幅度...'); s3 = {}
    for a in (0.0, 0.5, 1.0, 1.5, 2.0):
        pm_a = typ[None, :] + a * (pm - typ[None, :])
        pred_a = typ[None, :] + a * (pred_main - typ[None, :])
        naive = run_det_year(inp, typ_rep, pm_a)['settle'] / 1e4
        fore = run_det_year(inp, pred_a, pm_a)['settle'] / 1e4
        perf = run_det_year(inp, pm_a, pm_a)['settle'] / 1e4
        s3[str(a)] = dict(naive=naive, forecast=fore, perfect=perf,
                          fvalue=naive - fore, evpi=fore - perf)
        print('  alpha=%.1f naive %.2f forecast %.2f perfect %.2f EVPI %.2f'
              % (a, naive, fore, perf, fore - perf))
    res['S3_alpha'] = s3

    # ---------- S4 硬件龙卷风（主口径预测决策、实际价结算）----------
    print('S4 硬件参数...'); s4 = {}
    base = run_det_year(inp, pred_main, pm); base_c = base['settle']
    s4['baseline'] = dict(settle_wan=base_c / 1e4, eta=ETA, pmax=5000, smax=S_MAX)
    tornado = []
    for eta in (0.85, 0.95):
        r = run_det_year(inp, pred_main, pm, eta=eta)['settle'] / 1e4
        tornado.append(dict(param='充放效率η', level='%.2f' % eta, settle_wan=r, delta=r - base_c / 1e4))
    for pmax in (4000.0, 6000.0):
        r = run_det_year(inp, pred_main, pm, e_max=pmax * H)['settle'] / 1e4
        tornado.append(dict(param='最大充放功率', level='%dkW' % pmax, settle_wan=r, delta=r - base_c / 1e4))
    for smax in (9600.0, 12000.0):
        r = run_det_year(inp, pred_main, pm, s_max=smax)['settle'] / 1e4
        tornado.append(dict(param='储能容量上限', level='%.0fkWh' % smax, settle_wan=r, delta=r - base_c / 1e4))
    s4['tornado'] = tornado
    for t in tornado:
        print('  %s=%s 结算 %.2f 万 (Δ%+.2f)' % (t['param'], t['level'], t['settle_wan'], t['delta']))
    res['S4_hardware'] = s4

    # ---------- S5 光伏口径（4-3 full / no_adjust）----------
    print('S5 光伏预报口径...'); s5 = {}
    pred_lp = fc_main['pred_lp']
    for legacy in (True, False):
        inp_x = load_all(legacy_forecast=legacy)
        row = {}
        for mode in ('no_adjust', 'full'):
            _, summ = run_year(inp_x, pred_lp, mode)
            row[mode] = dict(total_wan=summ['total'] / 1e4, em_wan_kwh=summ['em_kwh'] / 1e4)
        s5['legacy(同问题3,主)' if legacy else 'strict(严格)'] = row
        print('  ', 'legacy' if legacy else 'strict', row)
    res['S5_forecast_align'] = s5

    json.dump(res, open(OUT_JSON, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('\n已存', OUT_JSON)


if __name__ == '__main__':
    main()
