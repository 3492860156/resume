# -*- coding: utf-8 -*-
"""生成问题4（4-2 / 4-3）四指定日论文表格 + 全年情景汇总，输出 Markdown。"""
import os
import json
import numpy as np

from q4_common import (FOCUS, BLOCK_NAMES, BLOCK_K, T1_SPECS, OUTDIR, DOCDIR,
                       load_all, N)
from solve_q4_2 import OUT_NPZ as Q2_NPZ
from solve_q4_3 import OUT_NPZ as Q3_NPZ
from build_result4_3 import merge_emergency


def block_cd(C, D, d, bi):
    ks, extra = BLOCK_K[bi]
    c = float(C[d, ks].sum()); dis = float(D[d, ks].sum())
    if bi == 0:
        c += float(C[d - 1, extra]); dis += float(D[d - 1, extra])
    return c, dis


def main():
    inp = load_all(); dates = [str(x) for x in inp['dates']]
    z2 = np.load(Q2_NPZ); z3 = np.load(Q3_NPZ)
    s2 = json.load(open(os.path.join(OUTDIR, '数据', 'q4_2_summary.json'), encoding='utf-8'))
    s3 = json.load(open(os.path.join(OUTDIR, '数据', 'q4_3_summary.json'), encoding='utf-8'))
    L = []
    L.append('# 问题4 论文表格数据（波动电价；4 个指定日期 + 全年汇总）\n')

    # ---------- 全年情景汇总 ----------
    L.append('## 一、全年汇总（输出区间 2025.2.1–12.31，334 天）\n')
    L.append('### 表A 问题4-2（重算问题2）不同信息情景对比\n')
    L.append('| 情景 | 购电量(万kWh) | 实际结算费(万元) | 说明 |')
    L.append('|---|---|---|---|')
    name_cn = {'fixed': '固定电价(复现问题2)', 'perfect': '完美预见(波动下界)',
               'naive_fixed': '按典型曲线决策', 'forecast': '清洗预测决策(主结果)'}
    for k in ('fixed', 'perfect', 'naive_fixed', 'forecast'):
        v = s2[k]
        L.append('| %s | %.2f | %.2f | %s |' % (k, v['buy_kwh'] / 1e4,
                                            v['settle_cost'] / 1e4, name_cn[k]))
    L.append('\n- 电价预测价值（典型曲线→清洗预测）：**%.2f 万元**' % (s2['forecast_value'] / 1e4))
    L.append('- 电价完美信息价值 EVPI（清洗预测→完美预见）：**%.2f 万元**\n' % (s2['EVPI_price'] / 1e4))

    L.append('### 表B 问题4-3（重算问题3）不同决策模式对比\n')
    L.append('| 模式 | 总费用(万元) | 最终购电(万kWh) | 紧急电量(万kWh) | 紧急费(万元) |')
    L.append('|---|---|---|---|---|')
    cn = {'no_adjust': '仅0点计划不调整', 'naive_pv': '光伏滚动+典型电价',
          'pv_only': '光伏滚动+电价日前预测', 'full': '光伏+电价双滚动(主结果)',
          'perfect': '全信息完美预见'}
    for k in ('no_adjust', 'naive_pv', 'pv_only', 'full', 'perfect'):
        v = s3[k]
        L.append('| %s | %.2f | %.2f | %.2f | %.2f |'
                 % (cn[k], v['total'] / 1e4, v['buy'] / 1e4, v['em_kwh'] / 1e4,
                    v['em_cost'] / 1e4))
    L.append('\n- 光伏滚动更新价值：**%.2f 万元**；电价日前预测价值：**%.2f 万元**；'
             '电价日内更新价值：**%.2f 万元**'
             % (s3['pv_update_value'] / 1e4, s3['price_dayahead_value'] / 1e4,
                s3['price_intraday_value'] / 1e4))
    L.append('- 相对全信息的总代价 EVPI：**%.2f 万元**\n' % (s3['EVPI'] / 1e4))

    # ---------- 指定日明细 ----------
    for f in FOCUS:
        d = dates.index(f)
        L.append('\n---\n## %s\n' % f)
        # ===== 4-2 =====
        X, C, D, S = z2['forecast_X'], z2['forecast_C'], z2['forecast_D'], z2['forecast_S']
        cost = z2['forecast_cost_set']
        L.append('### 【问题4-2】表1 指定时间段购电量（kWh）\n')
        L.append('| 时间段 | 购电量 | 时间段 | 购电量 |')
        L.append('|---|---|---|---|')
        for i in range(0, 6, 2):
            n1, k1 = T1_SPECS[i]; n2, k2 = T1_SPECS[i + 1]
            L.append('| %s | %.4f | %s | %.4f |' % (n1, X[d, k1], n2, X[d, k2]))
        L.append('\n全天购电量 **%.2f kWh**；实际电价结算购电费 **%.2f 元**\n'
                 % (X[d].sum(), cost[d]))
        L.append('### 【问题4-2】表2 储能充放电量与储电量（kWh）\n')
        L.append('| 时间段 | 充电量 | 放电量 | 时间段 | 充电量 | 放电量 |')
        L.append('|---|---|---|---|---|---|')
        for i in range(0, 6, 2):
            c1, dd1 = block_cd(C, D, d, i); c2, dd2 = block_cd(C, D, d, i + 1)
            L.append('| %s | %.2f | %.2f | %s | %.2f | %.2f |'
                     % (BLOCK_NAMES[i], c1, dd1, BLOCK_NAMES[i + 1], c2, dd2))
        L.append('\n0:00 储电量 **%.2f**；24:00 储电量 **%.2f** kWh\n'
                 % (S[d, 0], S[d, N - 1]))
        L.append('### 【问题4-2】表3 紧急购电量：无（全信息确定性最优，e≡0）\n')

        # ===== 4-3 =====
        Xp, Xf, Cf, Df, Sf, Eact = (z3['Xp'], z3['Xf'], z3['Cf'], z3['Df'],
                                    z3['Sf'], z3['Eact'])
        L.append('### 【问题4-3】表1 指定时间段购电量（计划 / 最终，kWh）\n')
        L.append('| 时间段 | 计划 | 最终 | 时间段 | 计划 | 最终 |')
        L.append('|---|---|---|---|---|---|')
        for i in range(0, 6, 2):
            n1, k1 = T1_SPECS[i]; n2, k2 = T1_SPECS[i + 1]
            L.append('| %s | %.4f | %.4f | %s | %.4f | %.4f |'
                     % (n1, Xp[d, k1], Xf[d, k1], n2, Xp[d, k2], Xf[d, k2]))
        L.append('\n计划全天购电 **%.2f**、最终 **%.2f kWh**；计划费 %.2f、调整 %.2f、'
                 '紧急费 %.2f、**总费用 %.2f 元**（紧急 %.2f kWh）\n'
                 % (Xp[d].sum(), Xf[d].sum(), z3['cost_plan'][d], z3['cost_adj'][d],
                    z3['cost_em'][d], z3['cost_tot'][d], Eact[d].sum()))
        L.append('### 【问题4-3】表2 储能最终充放电量与储电量（kWh）\n')
        L.append('| 时间段 | 充电量 | 放电量 | 时间段 | 充电量 | 放电量 |')
        L.append('|---|---|---|---|---|---|')
        for i in range(0, 6, 2):
            c1, dd1 = block_cd(Cf, Df, d, i); c2, dd2 = block_cd(Cf, Df, d, i + 1)
            L.append('| %s | %.2f | %.2f | %s | %.2f | %.2f |'
                     % (BLOCK_NAMES[i], c1, dd1, BLOCK_NAMES[i + 1], c2, dd2))
        L.append('\n0:00 储电量 **%.2f**；24:00 储电量 **%.2f** kWh\n'
                 % (Sf[d, 0], Sf[d, N - 1]))
        segs = merge_emergency(Eact[d])
        L.append('### 【问题4-3】表3 紧急购电量（共%d段，合计%.2f kWh）\n'
                 % (len(segs), Eact[d].sum()))
        L.append('| 时间段 | 购电量 |')
        L.append('|---|---|')
        for lab, q in segs:
            L.append('| %s | %.2f |' % (lab, q))
        L.append('')

    out = os.path.join(DOCDIR, '论文表格数据_Q4.md')
    open(out, 'w', encoding='utf-8').write('\n'.join(L))
    print('已生成', out)
    print('\n'.join(L[:46]))


if __name__ == '__main__':
    main()
