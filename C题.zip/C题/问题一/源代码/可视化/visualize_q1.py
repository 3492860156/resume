# -*- coding: utf-8 -*-
"""
问题1 最优计划购电策略可视化
==================================================================
读取同目录下的 chart_data.json（由 solve_q1.py 生成），绘制全天策略图：
  - 左轴：每10分钟购电量（柱状） + 储能设备电量（折线）
  - 右轴：电价（折线）
输出图片：问题1_购电策略可视化.png（可直接插入论文）

运行方式：先运行 solve_q1.py 生成 chart_data.json，再运行本脚本。
依赖：matplotlib（若未安装：pip install matplotlib）
"""
import json
import os
import datetime

import matplotlib
matplotlib.use('Agg')                      # 不弹窗，直接存文件（无显示环境也能跑）
import matplotlib.pyplot as plt

# ---------- 中文字体设置（Windows 常用字体，按优先级回退） ----------
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False   # 正常显示负号

# 向上查找“问题一”根目录（脚本在 源代码\可视化 下，需上溯两级）
BASE = os.path.dirname(os.path.abspath(__file__))
def _find_q1():
    d = BASE
    for _ in range(6):
        if os.path.basename(d) == '问题一' and os.path.isdir(d):
            return d
        p = os.path.dirname(d)
        if p == d:
            break
        d = p
    return BASE
Q1 = _find_q1()
JSON_PATH = os.path.join(Q1, '数据', 'chart_data.json')                 # 输入数据
OUT_PNG = os.path.join(Q1, '问题1_购电策略可视化.png')           # 输出图片

# ---------- 1. 读取数据 ----------
with open(JSON_PATH, encoding='utf-8') as f:
    d = json.load(f)
labels = d['labels']          # 144 个间隔结束时刻（字符串，如 00:10）
buy    = d['buy']             # 购电量 kWh/10min
store  = d['store'][1:]       # S_1..S_144，去掉S0以与 144 个区间末时刻对齐
price  = d['price']           # 电价 元/kWh

# 时间标签 -> 一天内的小时数（x 轴坐标），如 '02:30'→2.5
x = []
for lab in labels:
    lab2 = '24:00' if lab.endswith('+') else lab   # 跨日标签 0:00+ 归一为 24:00
    hh, mm = lab2.split(':')
    x.append(int(hh) + int(mm) / 60.0)

# ---------- 2. 绘图（左轴：电量；右轴：电价） ----------
fig, ax1 = plt.subplots(figsize=(13, 6.2), dpi=200)

# 购电量柱（浅蓝，柱宽略小于区间宽度1/6h）
ax1.bar(x, buy, width=(1 / 6) * 0.78, color='#A8C5E0',
        label='购电量(kWh/10min)', edgecolor='none')
# 储电量线（深蓝）
ax1.plot(x, store, color='#6C8EBF', linewidth=2.0, label='储能设备电量(kWh)')

ax1.set_xlabel('时间', fontsize=12)
ax1.set_ylabel('电量 (kWh)', fontsize=12)
ax1.set_xlim(0, 24)
ax1.set_xticks(range(0, 25, 2))
ax1.set_xticklabels(['%02d:00' % h for h in range(0, 25, 2)])
ax1.tick_params(labelsize=11)
ax1.grid(axis='y', linestyle='--', alpha=0.4)   # 仅横向网格线

# 电价线（橙色，右轴）
ax2 = ax1.twinx()
ax2.plot(x, price, color='#E2A76F', linewidth=2.2, label='电价(元/kWh)')
ax2.set_ylabel('电价 (元/kWh)', fontsize=12, color='#B26A2E')
ax2.set_ylim(0, 1.6)                              # 固定纵轴范围便于跨图比较
ax2.tick_params(axis='y', labelcolor='#B26A2E', labelsize=11)

# 合并左右轴图例
h1, l1 = ax1.get_legend_handles_labels()
h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=11, framealpha=0.9)

ax1.set_title('问题1 最优计划购电策略（2026国赛C题，基于附件1）', fontsize=14, pad=12)

fig.tight_layout()                  # 自动调整边距防裁切
fig.savefig(OUT_PNG, bbox_inches='tight')
print('已保存:', OUT_PNG)
