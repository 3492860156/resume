# -*- coding: utf-8 -*-
"""把 chart_data.json 中的四组序列打印成逗号分隔文本，方便复制到其它绘图工具/论文表格。"""
import json
import os

# 以脚本所在目录向上找到“问题一”根目录，读取 chart_data.json（由 solve_q1.py 生成）
BASE = os.path.dirname(os.path.abspath(__file__))
def _find_q1():
    d = BASE
    for _ in range(6):
        if os.path.basename(d) == '问题一' and os.path.isdir(d):
            return d
        p = os.path.dirname(d)
        if p == d:
            break
        d = p
    return BASE
Q1 = _find_q1()
d = json.load(open(os.path.join(Q1, '数据', 'chart_data.json'), encoding='utf-8'))
print('BUY=')                                    # 144个区间购电量
print(','.join(str(v) for v in d['buy']))
print()
print('STORE=')                                  # 储电量（去掉S0，保留144个区间末状态）
print(','.join(str(v) for v in d['store'][1:]))
print()
print('PRICE=')                                  # 电价
print(','.join(str(v) for v in d['price']))
print()
print('LABELS=')                                 # 时间标签，带双引号便于直接作为JS数组
print(','.join('"' + v + '"' for v in d['labels']))
