# -*- coding: utf-8 -*-
"""
2026 国赛 C 题  问题 1：敏感性分析与稳健性分析实验脚本
==================================================================
复用 solve_q1.py 的线性规划模型（目标 min Σ 电价×购电量；
约束：母线平衡 / 储能状态递推 / S0=SN / 容量与功率边界）。

输出：
  1) 单参数敏感性分析（7 个参数 × 5 个取值）→ sensitivity_results.json + 控制台表
  2) 归一化扰动对比（各参数 ±10% 附近）→ 计算购电费变化幅度与弹性系数
  3) 稳健性分析（光伏预测偏差情景：基准策略的执行缺口检验）
"""
import os
import json
import numpy as np
import openpyxl
from scipy.optimize import linprog

# ------------------------- 路径 -------------------------
# 向上查找含“附件”的目录作为 C题 根目录（脚本在 问题一\源代码\敏感性分析 下）
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
def _find_c_root(d):
    for _ in range(8):
        if os.path.isdir(os.path.join(d, '附件')):
            return d
        p = os.path.dirname(d)
        if p == d:
            break
        d = p
    return SCRIPT_DIR
ROOT = _find_c_root(SCRIPT_DIR)
Q1 = os.path.join(ROOT, '问题一')
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')
OUT_JSON = os.path.join(Q1, '数据', 'sensitivity_results.json')

# ------------------------- 读取附件1 -------------------------
wb = openpyxl.load_workbook(ATT1, data_only=True)
ws = wb['Sheet1']
rows = list(ws.iter_rows(min_row=2, values_only=True))
price = np.array([float(r[1]) for r in rows])   # 元/kWh
load  = np.array([float(r[2]) for r in rows])   # kW
pv    = np.array([float(r[3]) for r in rows])   # kW
N = len(rows)
h = 1/6                                        # 10分钟=1/6小时
l   = load * h                                 # 负载电量 kWh
pvE = pv * h                                   # 光伏电量 kWh

# ------------------------- LP 求解函数（与 solve_q1 同口径，参数可覆盖） -------------------------
def solve(price_v, load_h, pv_h, eta=0.9, S0=6000.0, Smin=1200.0, Smax=10800.0, Pmax=5000.0):
    """单日 LP。返回 (全天购电量, 全天购电费, X, C, D, U, S)；无可行解返回 None。"""
    Nn = len(price_v)
    Emax = Pmax * h                             # 单区间充/放上界
    nv = 4*Nn + (Nn+1)                          # x,c,d,u 各Nn + S 共Nn+1
    def vid(i, k):
        return {'x':0,'c':Nn,'d':2*Nn,'u':3*Nn,'S':4*Nn}[k] + i
    c_obj = np.zeros(nv)
    for i in range(Nn):
        c_obj[vid(i,'x')] = price_v[i]          # 目标系数=电价
    A_eq, b_eq = [], []
    for i in range(Nn):                       # 母线平衡 x+u+ηd−c=负载
        row = np.zeros(nv)
        row[vid(i,'x')] = 1; row[vid(i,'u')] = 1; row[vid(i,'d')] = eta; row[vid(i,'c')] = -1
        A_eq.append(row); b_eq.append(load_h[i])
    for i in range(Nn):                       # 储能递推 S_{i+1}−S_i−ηc+d=0
        row = np.zeros(nv)
        row[vid(i+1,'S')] = 1; row[vid(i,'S')] = -1; row[vid(i,'c')] = -eta; row[vid(i,'d')] = 1
        A_eq.append(row); b_eq.append(0)
    row = np.zeros(nv); row[vid(0,'S')] = 1; A_eq.append(row); b_eq.append(S0)   # 首储电量
    row = np.zeros(nv); row[vid(Nn,'S')] = 1; A_eq.append(row); b_eq.append(S0)  # 末储电量=首（日循环）
    bounds = [(0, None)]*nv
    for i in range(Nn):
        bounds[vid(i,'x')] = (0, None)
        bounds[vid(i,'c')] = (0, Emax)
        bounds[vid(i,'d')] = (0, Emax)
        bounds[vid(i,'u')] = (0, pv_h[i])
    for i in range(Nn+1):
        bounds[vid(i,'S')] = (Smin, Smax)
    res = linprog(c_obj, A_eq=np.array(A_eq), b_eq=np.array(b_eq),
                  bounds=bounds, method='highs')
    if not res.success:
        return None
    X = res.x[0:Nn]; C = res.x[Nn:2*Nn]; D = res.x[2*Nn:3*Nn]
    U = res.x[3*Nn:4*Nn]; S = res.x[4*Nn:]
    return (float(X.sum()), float((price_v*X).sum()), X, C, D, U, S)

# ------------------------- 0. 基准解 -------------------------
base = solve(price, l, pvE)
assert base is not None
B_BUY, B_COST = base[0], base[1]
print('== 基准解 ==  全天购电量 = %.2f kWh, 全天购电费 = %.2f 元' % (B_BUY, B_COST))

# ------------------------- 1. 单参数敏感性分析 -------------------------
# 每个参数给5个水平（含基准值），逐水平重解LP观察购电费变化
param_grids = {
    '储能效率η':     [0.85, 0.875, 0.90, 0.925, 0.95],
    '初始电量S0':    [4000.0, 5000.0, 6000.0, 7000.0, 8000.0],
    '容量上限Smax':  [9600.0, 10200.0, 10800.0, 11400.0, 12000.0],
    '容量下限Smin':  [1000.0, 1200.0, 1400.0, 1600.0, 1800.0],
    '功率上限Pmax':  [4000.0, 4500.0, 5000.0, 5500.0, 6000.0],
    '光伏比例pv':    [0.90, 0.95, 1.00, 1.05, 1.10],
    '电价比例pr':    [0.90, 0.95, 1.00, 1.05, 1.10],
}

def run_case(name, v):
    """按参数名把水平值送入 solve 的对应入口（其余参数保持基准）。"""
    if   name == '储能效率η':    return solve(price, l, pvE, eta=v)
    elif name == '初始电量S0':   return solve(price, l, pvE, S0=v)
    elif name == '容量上限Smax': return solve(price, l, pvE, Smax=v)
    elif name == '容量下限Smin': return solve(price, l, pvE, Smin=v)
    elif name == '功率上限Pmax': return solve(price, l, pvE, Pmax=v)
    elif name == '光伏比例pv':   return solve(price, l, pvE*v)   # 光伏整体缩放
    elif name == '电价比例pr':   return solve(price*v, l, pvE)   # 电价整体缩放
    return None

sens = {}
print('\n== 单参数敏感性分析 ==')
for name, vals in param_grids.items():
    rows_out = []
    for v in vals:
        r = run_case(name, v)
        if r is None:
            rows_out.append({'param': v, 'buy': None, 'cost': None})
            continue
        chg = (r[1] - B_COST) / B_COST * 100          # 相对基准费用变化百分比
        rows_out.append({'param': v, 'buy': round(r[0], 2), 'cost': round(r[1], 2),
                         'cost_chg_pct': round(chg, 2)})
        print('  %-8s = %8.3f  购电费 %10.2f 元 (变化 %+6.2f%%)  购电量 %10.2f kWh'
              % (name, v, r[1], chg, r[0]))
    sens[name] = rows_out

# ------------------------- 2. 归一化弹性对比 -------------------------
# 弹性 ε ≈ 费用变化% / 参数变化%，|ε|越大越敏感；用参数低端/高端两点做中心差分
print('\n== 归一化弹性对比（近似 ±10% 相对扰动，弹性 ε ≈ Δcost%/Δparam%） ==')
# 各参数取“尽量接近 ±10% 相对变化”的可行网格
grids_norm = {
    '储能效率η':    ('eta',   0.9, 0.9*0.90, 0.9*1.10,   'ε(η)'),
    '初始电量S0':   ('S0',    6000.0, 5400.0, 6600.0,    'ε(S0)'),
    '容量上限Smax': ('Smax',  10800.0, 9720.0, 11880.0,  'ε(Smax)'),
    '容量下限Smin': ('Smin',  1200.0, 1080.0, 1320.0,    'ε(Smin)'),
    '功率上限Pmax': ('Pmax',  5000.0, 4500.0, 5500.0,    'ε(Pmax)'),
    '光伏比例pv':   ('pv',    1.0, 0.90, 1.10,           'ε(pv)'),
    '电价比例pr':   ('pr',    1.0, 0.90, 1.10,           'ε(pr)'),
}
elas = []
for name, (kind, p0, plo, phi, tag) in grids_norm.items():
    rlo = run_case(name, plo); rhi = run_case(name, phi)
    if rlo is None or rhi is None:
        continue
    clo, chi = rlo[1], rhi[1]
    dcost_pct = (chi - clo) / B_COST * 100       # 低→高端费用跨度（占基准%）
    dparam_pct = (phi - plo) / p0 * 100         # 低→高端参数跨度%
    e = dcost_pct / dparam_pct if dparam_pct != 0 else float('nan')
    elas.append({'param': name, 'p0': p0, 'plo': plo, 'phi': phi,
                 'cost_lo': round(clo,2), 'cost_hi': round(chi,2),
                 'cost_span_pct': round(dcost_pct, 2), 'elasticity': round(e, 3)})
    print('  %-10s %-6s=%.2f → [%.2f, %.2f]  费用 %10.2f→%10.2f 元 (跨度 %+6.2f%%)  弹性 %+.3f'
          % (name, kind, p0, plo, phi, clo, chi, dcost_pct, e))
elas.sort(key=lambda d: -abs(d['elasticity']))   # 按弹性绝对值降序（龙卷风排序依据）

# ------------------------- 3. 稳健性分析：光伏预测偏差的执行检验 -------------------------
# 思路：基准计划是按“预测光伏”优化的；若实际光伏=预测×(1+δ)，计划被冻结无法重排，
# 原计划要用 u 的地方光伏不够就形成缺口，只能按5倍时刻电价紧急购电弥补。
print('\n== 稳健性分析：光伏预测偏差下基准策略的执行缺口 ==')
# 基准策略（按预测优化的 X,C,D,U）在实际光伏 pv_act = pv*(1+δ) 下执行：
#   每时刻实际可用的光伏 = min(U_i, pv_act_i)；缺口 = U_i - pv_act_i (>0 时)
#   额外费用按问题2口径（电价×5）估算，仅作量化说明。
X0, C0, D0, U0, S0_ = base[2], base[3], base[4], base[5], base[6]
robust = []
for delta in [-0.20, -0.15, -0.10, -0.05, 0.0, 0.05, 0.10]:
    pv_act = np.maximum(pvE * (1+delta), 0.0)
    gap = np.maximum(U0 - pv_act, 0.0)          # 缺电量 kWh
    gap_energy = float(gap.sum())
    gap_cost = float((5.0 * price * gap).sum()) # 按5倍电价计紧急购电费
    pct = gap_cost / B_COST * 100
    robust.append({'delta_pct': round(delta*100,1), 'gap_kwh': round(gap_energy,2),
                   'gap_cost5x': round(gap_cost,2), 'gap_cost_pct': round(pct,2)})
    print('  光伏偏差 %+5.1f%%  缺口电量 %9.2f kWh  额外费用(5倍价) %9.2f 元 (占基准 %5.2f%%)'
          % (delta*100, gap_energy, gap_cost, pct))

# ------------------------- 保存 -------------------------
out = {
    'base': {'buy': round(B_BUY,2), 'cost': round(B_COST,2)},
    'sensitivity': sens,
    'elasticity': elas,
    'robustness': robust,
}
with open(OUT_JSON, 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print('\n结果已保存:', OUT_JSON)
