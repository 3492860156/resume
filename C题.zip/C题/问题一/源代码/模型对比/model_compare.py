# -*- coding: utf-8 -*-
"""
问题1 多模型对比实验
A: 原 LP（递推差分形式）            scipy linprog / HiGHS-LP
B: 展开（累积）形式 LP              scipy linprog / HiGHS-LP
C: 消元形式 LP（无 S 变量）         scipy linprog / HiGHS-LP
D: MILP 充放互斥（二进制+大M）      scipy milp  / HiGHS-MIP
E: 原 LP                            PuLP / CBC
F: MILP 充放互斥                    PuLP / CBC
"""
import time
import json
import numpy as np
import openpyxl
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
import pulp

ATT1 = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题\附件\附件1.xlsx'
wb = openpyxl.load_workbook(ATT1, data_only=True)
rows = list(wb['Sheet1'].iter_rows(min_row=2, values_only=True))
price = np.array([float(r[1]) for r in rows])
load = np.array([float(r[2]) for r in rows])
pv = np.array([float(r[3]) for r in rows])
N = len(rows)
h, eta, Pmax, S0, Smin, Smax = 1/6, 0.9, 5000.0, 6000.0, 1200.0, 10800.0
l, pvE, Emax = load*h, pv*h, Pmax*h

def timeit(fn, repeat=3):
    out = None
    ts = []
    for _ in range(repeat):
        t0 = time.perf_counter()
        out = fn()
        ts.append(time.perf_counter() - t0)
    return out, float(np.mean(ts)), float(min(ts))

results = {}

# ============ 模型 A：原 LP（递推差分形式） ============
def model_A():
    nv = 4*N + (N+1)
    def vid(i, k):
        return {'x': 0, 'c': N, 'd': 2*N, 'u': 3*N, 'S': 4*N}[k] + i
    cobj = np.zeros(nv)
    for i in range(N):
        cobj[vid(i, 'x')] = price[i]
    Aeq, beq = [], []
    for i in range(N):  # 母线
        r = np.zeros(nv)
        r[vid(i,'x')]=1; r[vid(i,'u')]=1; r[vid(i,'d')]=eta; r[vid(i,'c')]=-1
        Aeq.append(r); beq.append(l[i])
    for i in range(N):  # 递推
        r = np.zeros(nv)
        r[vid(i+1,'S')]=1; r[vid(i,'S')]=-1; r[vid(i,'c')]=-eta; r[vid(i,'d')]=1
        Aeq.append(r); beq.append(0)
    r = np.zeros(nv); r[vid(0,'S')]=1; Aeq.append(r); beq.append(S0)
    r = np.zeros(nv); r[vid(N,'S')]=1; Aeq.append(r); beq.append(S0)
    bounds = [(0, None)]*nv
    for i in range(N):
        bounds[vid(i,'x')]=(0,None); bounds[vid(i,'c')]=(0,Emax)
        bounds[vid(i,'d')]=(0,Emax); bounds[vid(i,'u')]=(0,pvE[i])
    for i in range(N+1):
        bounds[vid(i,'S')]=(Smin,Smax)
    res = linprog(cobj, A_eq=np.array(Aeq), b_eq=np.array(beq),
                  bounds=bounds, method='highs')
    X = np.array([res.x[vid(i,'x')] for i in range(N)])
    C = np.array([res.x[vid(i,'c')] for i in range(N)])
    D = np.array([res.x[vid(i,'d')] for i in range(N)])
    return res, X, C, D, nv, len(beq)

(resA, XA, CA, DA, nvA, ncA), tA, tAmin = timeit(model_A)
results['A_递推形式LP_HiGHS'] = dict(vars=nvA, cons=ncA, fun=float(resA.fun),
    buy=float(XA.sum()), nit=int(resA.nit), time_mean=round(tA,4), time_min=round(tAmin,4),
    both=int(((CA>1e-6)&(DA>1e-6)).sum()))
print('A 递推LP: 变量%d 约束%d 费用%.2f 购电%.2f 迭代%d 用时%.4fs' % (nvA,ncA,resA.fun,XA.sum(),resA.nit,tA))

# ============ 模型 B：展开（累积）形式 LP ============
def model_B():
    nv = 4*N + (N+1)
    def vid(i, k):
        return {'x': 0, 'c': N, 'd': 2*N, 'u': 3*N, 'S': 4*N}[k] + i
    cobj = np.zeros(nv)
    for i in range(N):
        cobj[vid(i,'x')] = price[i]
    Aeq, beq = [], []
    for i in range(N):  # 母线
        r = np.zeros(nv)
        r[vid(i,'x')]=1; r[vid(i,'u')]=1; r[vid(i,'d')]=eta; r[vid(i,'c')]=-1
        Aeq.append(r); beq.append(l[i])
    # 展开: S_i = S0 + sum_{k<i}(eta*c_k - d_k), i=1..N
    for i in range(1, N+1):
        r = np.zeros(nv)
        r[vid(i,'S')] = 1
        for k in range(i):
            r[vid(k,'c')] = -eta
            r[vid(k,'d')] = 1
        Aeq.append(r); beq.append(S0)
    r = np.zeros(nv); r[vid(0,'S')]=1; Aeq.append(r); beq.append(S0)   # S0
    # 循环闭合: sum(eta*c-d)=0  => SN=S0
    r = np.zeros(nv)
    for k in range(N):
        r[vid(k,'c')] = eta; r[vid(k,'d')] = -1
    Aeq.append(r); beq.append(0)
    bounds = [(0, None)]*nv
    for i in range(N):
        bounds[vid(i,'x')]=(0,None); bounds[vid(i,'c')]=(0,Emax)
        bounds[vid(i,'d')]=(0,Emax); bounds[vid(i,'u')]=(0,pvE[i])
    for i in range(N+1):
        bounds[vid(i,'S')]=(Smin,Smax)
    res = linprog(cobj, A_eq=np.array(Aeq), b_eq=np.array(beq),
                  bounds=bounds, method='highs')
    X = np.array([res.x[vid(i,'x')] for i in range(N)])
    return res, X, nv, len(beq), int(np.count_nonzero(np.array(Aeq)))

(resB, XB, nvB, ncB, nnzB), tB, tBmin = timeit(model_B)
results['B_展开形式LP_HiGHS'] = dict(vars=nvB, cons=ncB, nnz=nnzB, fun=float(resB.fun),
    buy=float(XB.sum()), nit=int(resB.nit), time_mean=round(tB,4), time_min=round(tBmin,4))
print('B 展开LP: 变量%d 约束%d 非零元%d 费用%.2f 购电%.2f 迭代%d 用时%.4fs' % (nvB,ncB,nnzB,resB.fun,XB.sum(),resB.nit,tB))

# ============ 模型 C：消元形式 LP（无 S 变量） ============
def model_C():
    nv = 4*N
    def vid(i, k):
        return {'x': 0, 'c': N, 'd': 2*N, 'u': 3*N}[k] + i
    cobj = np.zeros(nv)
    for i in range(N):
        cobj[vid(i,'x')] = price[i]
    Aeq, beq = [], []
    Aub, bub = [], []
    for i in range(N):  # 母线
        r = np.zeros(nv)
        r[vid(i,'x')]=1; r[vid(i,'u')]=1; r[vid(i,'d')]=eta; r[vid(i,'c')]=-1
        Aeq.append(r); beq.append(l[i])
    # 容量约束直接约束累积和: Smin-S0 <= sum_{k<i}(eta*c-d) <= Smax-S0, i=1..N
    for i in range(1, N+1):
        r = np.zeros(nv)
        for k in range(i):
            r[vid(k,'c')] = eta; r[vid(k,'d')] = -1
        ru = r.copy(); Aub.append(ru); bub.append(Smax-S0)      # 累积 <= Smax-S0
        Aub.append(-r); bub.append(-(Smin-S0))                  # 累积 >= Smin-S0
    # 循环闭合
    r = np.zeros(nv)
    for k in range(N):
        r[vid(k,'c')] = eta; r[vid(k,'d')] = -1
    Aeq.append(r); beq.append(0)
    bounds = [(0, None)]*nv
    for i in range(N):
        bounds[vid(i,'x')]=(0,None); bounds[vid(i,'c')]=(0,Emax)
        bounds[vid(i,'d')]=(0,Emax); bounds[vid(i,'u')]=(0,pvE[i])
    res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub),
                  A_eq=np.array(Aeq), b_eq=np.array(beq),
                  bounds=bounds, method='highs')
    X = np.array([res.x[vid(i,'x')] for i in range(N)])
    return res, X, nv, len(Aeq)+len(Aub)

(resC, XC, nvC, ncC), tC, tCmin = timeit(model_C)
results['C_消元形式LP_HiGHS'] = dict(vars=nvC, cons=ncC, fun=float(resC.fun),
    buy=float(XC.sum()), nit=int(resC.nit), time_mean=round(tC,4), time_min=round(tCmin,4))
print('C 消元LP: 变量%d 约束%d 费用%.2f 购电%.2f 迭代%d 用时%.4fs' % (nvC,ncC,resC.fun,XC.sum(),resC.nit,tC))

# ============ 模型 D：MILP 充放互斥（scipy milp / HiGHS-MIP） ============
def model_D():
    nv = 6*N + 1   # x,c,d,u 各N + S(N+1) + y(N)
    def vid(i, k):
        return {'x':0,'c':N,'d':2*N,'u':3*N,'S':4*N,'y':5*N+1}[k] + i
    cobj = np.zeros(nv)
    for i in range(N):
        cobj[vid(i,'x')] = price[i]
    Aeq, beq = [], []
    Aub, bub = [], []
    for i in range(N):
        r = np.zeros(nv)
        r[vid(i,'x')]=1; r[vid(i,'u')]=1; r[vid(i,'d')]=eta; r[vid(i,'c')]=-1
        Aeq.append(r); beq.append(l[i])
    for i in range(N):
        r = np.zeros(nv)
        r[vid(i+1,'S')]=1; r[vid(i,'S')]=-1; r[vid(i,'c')]=-eta; r[vid(i,'d')]=1
        Aeq.append(r); beq.append(0)
    r = np.zeros(nv); r[vid(0,'S')]=1; Aeq.append(r); beq.append(S0)
    r = np.zeros(nv); r[vid(N,'S')]=1; Aeq.append(r); beq.append(S0)
    # 大M互斥: c - Emax*y <= 0 ; d + Emax*y <= Emax
    for i in range(N):
        r1 = np.zeros(nv); r1[vid(i,'c')]=1; r1[vid(i,'y')]=-Emax; Aub.append(r1); bub.append(0)
        r2 = np.zeros(nv); r2[vid(i,'d')]=1; r2[vid(i,'y')]=Emax; Aub.append(r2); bub.append(Emax)
    Aeq=np.array(Aeq); beq=np.array(beq); Aub=np.array(Aub); bub=np.array(bub)
    A = np.vstack([Aeq, Aub])
    lb = np.concatenate([beq, np.full(len(bub), -np.inf)])
    ub = np.concatenate([beq, bub])
    lb_b = np.full(nv, -np.inf); ub_b = np.full(nv, np.inf)
    for i in range(N):
        lb_b[vid(i,'x')]=0; ub_b[vid(i,'x')]=np.inf
        lb_b[vid(i,'c')]=0; ub_b[vid(i,'c')]=Emax
        lb_b[vid(i,'d')]=0; ub_b[vid(i,'d')]=Emax
        lb_b[vid(i,'u')]=0; ub_b[vid(i,'u')]=pvE[i]
        lb_b[vid(i,'y')]=0; ub_b[vid(i,'y')]=1
    for i in range(N+1):
        lb_b[vid(i,'S')]=Smin; ub_b[vid(i,'S')]=Smax
    integ = np.zeros(nv)
    for i in range(N):
        integ[vid(i,'y')] = 1
    res = milp(cobj, constraints=LinearConstraint(A, lb, ub),
               integrality=integ, bounds=Bounds(lb_b, ub_b))
    X = np.array([res.x[vid(i,'x')] for i in range(N)])
    C = np.array([res.x[vid(i,'c')] for i in range(N)])
    D = np.array([res.x[vid(i,'d')] for i in range(N)])
    Y = np.array([res.x[vid(i,'y')] for i in range(N)])
    return res, X, C, D, Y, nv, len(beq)+len(bub)

(resD, XD, CD, DD, YD, nvD, ncD), tD, tDmin = timeit(model_D, repeat=1)
results['D_MILP互斥_HiGHS'] = dict(vars=nvD, cons=ncD, int_vars=N, fun=float(resD.fun),
    buy=float(XD.sum()), mip_nodes=getattr(resD,'mip_node_count',None),
    mip_gap=float(getattr(resD,'mip_gap',np.nan)),
    both=int(((CD>1e-6)&(DD>1e-6)).sum()), time_mean=round(tD,4))
print('D MILP(HiGHS): 变量%d(整数%d) 约束%d 费用%.2f 购电%.2f 节点%s gap%s 同时充放%d 用时%.4fs'
      % (nvD,N,ncD,resD.fun,XD.sum(),resD.mip_node_count,resD.mip_gap,
         ((CD>1e-6)&(DD>1e-6)).sum(),tD))

# ============ 模型 E：PuLP + CBC 求解 LP ============
def model_E(use_mip=False):
    prob = pulp.LpProblem('q1', pulp.LpMinimize)
    x = [pulp.LpVariable(f'x{i}', lowBound=0) for i in range(N)]
    c = [pulp.LpVariable(f'c{i}', lowBound=0, upBound=Emax) for i in range(N)]
    d = [pulp.LpVariable(f'd{i}', lowBound=0, upBound=Emax) for i in range(N)]
    u = [pulp.LpVariable(f'u{i}', lowBound=0, upBound=float(pvE[i])) for i in range(N)]
    S = [pulp.LpVariable(f'S{i}', lowBound=Smin, upBound=Smax) for i in range(N+1)]
    prob += pulp.lpSum(price[i]*x[i] for i in range(N))
    for i in range(N):
        prob += x[i]+u[i]+eta*d[i]-c[i] == float(l[i])
        prob += S[i+1]-S[i]-eta*c[i]+d[i] == 0
    prob += S[0] == S0
    prob += S[N] == S0
    if use_mip:
        y = [pulp.LpVariable(f'y{i}', cat=pulp.LpBinary) for i in range(N)]
        for i in range(N):
            prob += c[i] <= Emax*y[i]
            prob += d[i] <= Emax*(1-y[i])
    solver = pulp.PULP_CBC_CMD(msg=0)
    prob.solve(solver)
    buy = sum(pulp.value(x[i]) for i in range(N))
    return pulp.value(prob.objective), buy, (prob.solutionCpuTime if hasattr(prob,'solutionCpuTime') else 0)

t0=time.perf_counter(); objE, buyE, _ = model_E(False); tE=time.perf_counter()-t0
results['E_递推LP_CBC'] = dict(fun=float(objE), buy=float(buyE), time_mean=round(tE,4))
print('E LP(CBC): 费用%.2f 购电%.2f 用时%.4fs' % (objE,buyE,tE))

t0=time.perf_counter(); objF, buyF, _ = model_E(True); tF=time.perf_counter()-t0
results['F_MILP互斥_CBC'] = dict(int_vars=N, fun=float(objF), buy=float(buyF), time_mean=round(tF,4))
print('F MILP(CBC): 费用%.2f 购电%.2f 用时%.4fs' % (objF,buyF,tF))

# ============ 目标值一致性核对 ============
funs = [resA.fun, resB.fun, resC.fun, resD.fun, objE, objF]
print()
print('六个模型目标值最大差异 = %.2e 元' % (max(funs)-min(funs)))

OUT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题\问题一\数据\model_compare_results.json'
with open(OUT,'w',encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print('结果已保存:', OUT)
