# -*- coding: utf-8 -*-
"""
2026 国赛 C 题  问题 1：微网计划购电策略（线性规划求解）
==================================================================
目标：在“每天电价与小区负载相同、光伏预测已知”的前提下，于每天 0:00
制定当天的计划购电策略，使购电费用最小，并满足：
  (1) 微网供给电能 >= 小区负载（本模型按等号满足：不买多也不缺电）
  (2) 储能设备在 0:00 与 24:00 的储电量相同（= 6000 kWh，见附录1）
  (3) 储能电量保持在 1200 ~ 10800 kWh；充放电效率 90%；最大充放电功率 5000 kW

时间口径（重要假设，见分析）：
  附件1 每行时间 t 代表 10 分钟区间 [t-10min, t) 的数据；
  模板 result1.xlsx 中“t1-t2”区间对应附件1 中时间为 t2 的那一行；
  最后一格“0:00+1-0:10+1”即次日的 [0:00,0:10)，因每天完全相同，取本日第一行。

输出：result1.xlsx（计划购电量 / 充放电量 / 购电费用明细 三个工作表）

=========================== 详细备注版说明 ===========================
单位约定：附件1 中负载/光伏为功率(kW)，乘区间时长 h=1/6h 换算为电量(kWh)；
电价单位 元/kWh，价格×电量直接得到费用(元)。问题1为“单日稳态循环”模型：
每天完全相同且要求 S(0:00)=S(24:00)，故只解一天(144区间)即可代表每一天。
"""
import os
import json
import numpy as np
import openpyxl
from scipy.optimize import linprog

# ------------------------- 1. 读取附件1 -------------------------
# 路径规则：向上查找含“附件”的目录作为 C题 根目录；输出统一写到 C题\问题一
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))   # 本脚本所在目录
def _find_c_root(d):
    """从脚本目录逐级向上，找到包含“附件”文件夹的目录，即 C题 根目录（最多上溯8级）。"""
    for _ in range(8):
        if os.path.isdir(os.path.join(d, '附件')):
            return d
        p = os.path.dirname(d)
        if p == d:        # 已到磁盘根目录仍未找到
            break
        d = p
    return SCRIPT_DIR    # 找不到时回退为脚本目录，保证路径不崩
ROOT = _find_c_root(SCRIPT_DIR)
Q1 = os.path.join(ROOT, '问题一')
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')               # 输入：电价+负载+光伏预测
TPL  = os.path.join(ROOT, '附件', '附件5', 'result1.xlsx')     # 官方结果模板（只借它的时间段标签）
OUT  = os.path.join(Q1, 'result1.xlsx')                       # 结果输出路径
CHART_JSON = os.path.join(Q1, '数据', 'chart_data.json')   # 供 visualize_q1.py 画图使用

wb = openpyxl.load_workbook(ATT1, data_only=True)
ws = wb['Sheet1']
rows = list(ws.iter_rows(min_row=2, values_only=True))   # 跳过表头，取144行数据
price = np.array([float(r[1]) for r in rows])   # 电价 元/kWh（第2列）
load  = np.array([float(r[2]) for r in rows])   # 小区负载 kW（第3列）
pv    = np.array([float(r[3]) for r in rows])   # 光伏预测功率 kW（第4列）
N = len(rows)                                   # 144 个 10 分钟间隔

h   = 1/6            # 区间时长：10 分钟 = 1/6 小时
l   = load * h       # 每区间负载电量 kWh（功率×时长）
pvE = pv   * h       # 每区间光伏发电量 kWh
eta = 0.9            # 充放电效率（充、放各按 90%，循环效率0.81）
Pmax = 5000.0        # 最大充/放电功率 kW（附录1）
Emax = Pmax * h      # 单区间最大充/放电量 = 833.333 kWh
S0   = 6000.0        # 0:00 初始储电量 kWh（问题1要求24:00也回到该值）
Smin, Smax = 1200.0, 10800.0   # SOC 允许区间（容量12000的10%~90%）

# ------------------------- 2. 构建线性规划 -------------------------
# 决策变量排列（共 4*144+145=721 个，问题1无紧急购电变量 e）：
#   [x_0..x_{N-1}] 购电量, [c_0..c_{N-1}] 充电量(母线侧),
#   [d_0..d_{N-1}] 放电量(电池侧), [u_0..u_{N-1}] 光伏利用量,
#   [S_0..S_N] 各区间起点储电量(S_i 为区间 i 开始时刻, S_N 为 24:00)
nv = 4*N + (N+1)
def vid(i, k):            # 取第 i 区间第 k 类变量的全局下标；k: x/c/d/u/S
    return {'x':0,'c':N,'d':2*N,'u':3*N,'S':4*N}[k] + i

c_obj = np.zeros(nv)
for i in range(N):
    c_obj[vid(i,'x')] = price[i]      # 目标: 最小化 Σ 电价×购电量（其余变量不直接花钱）

A_eq, b_eq = [], []                   # 等式约束左端系数矩阵（逐行append）与右端向量
# 母线功率平衡: x_i + u_i + η·d_i = l_i + c_i   (u_i 可弃光, 0<=u_i<=pvE_i)
# 移项为 x+u+ηd−c = l：左边四种供给，右边负载+充电去向
for i in range(N):
    row = np.zeros(nv)
    row[vid(i,'x')] = 1
    row[vid(i,'u')] = 1
    row[vid(i,'d')] = eta
    row[vid(i,'c')] = -1
    A_eq.append(row); b_eq.append(l[i])
# 储能状态递推: S_{i+1} = S_i + η·c_i - d_i（充入打9折入库，放出多少电池就减多少）
for i in range(N):
    row = np.zeros(nv)
    row[vid(i+1,'S')] = 1
    row[vid(i,'S')]   = -1
    row[vid(i,'c')]   = -eta
    row[vid(i,'d')]   = 1
    A_eq.append(row); b_eq.append(0)
# 日循环约束：S_0 = 6000, S_N = 6000  (0:00 与 24:00 储电量相同，问题1特有)
row = np.zeros(nv); row[vid(0,'S')] = 1; A_eq.append(row); b_eq.append(S0)
row = np.zeros(nv); row[vid(N,'S')] = 1; A_eq.append(row); b_eq.append(S0)

# 变量边界（全部非负，再叠加物理上限）
bounds = [(0, None)]*nv
for i in range(N):
    bounds[vid(i,'x')] = (0, None)          # 购电量 ≥0，无联络线上限
    bounds[vid(i,'c')] = (0, Emax)          # 单区间充电量 ≤ 833.33 kWh（功率限制）
    bounds[vid(i,'d')] = (0, Emax)          # 单区间放电量 ≤ 833.33 kWh
    bounds[vid(i,'u')] = (0, pvE[i])        # 光伏利用量不超过预测可发电量（多余弃光）
for i in range(N+1):
    bounds[vid(i,'S')] = (Smin, Smax)       # 储电量始终落在 [1200,10800]

res = linprog(c_obj, A_eq=np.array(A_eq), b_eq=np.array(b_eq),
              bounds=bounds, method='highs')    # HiGHS 求解器
assert res.success, f'求解失败: {res.message}'

# 按变量块切片，还原成144/145维向量
X = np.array([res.x[vid(i,'x')] for i in range(N)])   # 计划购电量
C = np.array([res.x[vid(i,'c')] for i in range(N)])   # 充电量
D = np.array([res.x[vid(i,'d')] for i in range(N)])   # 放电量
U = np.array([res.x[vid(i,'u')] for i in range(N)])   # 光伏利用量
S = np.array([res.x[vid(i,'S')] for i in range(N+1)]) # 储电量轨迹（145个状态点）

# ------------------------- 3. 自检（把解代回约束看残差） -------------------------
print('== 自检 ==')
print('S0 =', S[0], ' SN =', S[N], ' | S range:', S.min(), '~', S.max())
print('max C =', C.max().round(4), ' max D =', D.max().round(4), '(上限 %.2f)' % Emax)
sim_ch = (C > 1e-6) & (D > 1e-6)                 # 同一区间既充又放（经济上不划算，应为0个）
print('同区间充放电的间隔数:', sim_ch.sum())
bal = X + U + eta*D - C - l                       # 母线平衡残差（应≈1e-13浮点量级）
print('母线平衡最大偏差:', np.abs(bal).max())
st  = S[1:] - S[:-1] - eta*C + D                  # 状态递推残差（应≈0）
print('状态递推最大偏差:', np.abs(st).max())
pv_used_rate = U.sum() / pvE.sum()                # 光伏利用率=利用量/可发电量
print('光伏利用率: %.4f  (弃光量 %.1f kWh)' % (pv_used_rate, (pvE-U).sum()))

# ------------------------- 4. 汇总指标 -------------------------
total_buy  = X.sum()                 # 全天购电量 kWh
total_cost = float((price * X).sum())# 全天购电费 元 = Σ 电价×购电量
print('全天购电量 = %.2f kWh, 全天购电费 = %.2f 元' % (total_buy, total_cost))

# 4.5 导出可视化数据 chart_data.json（供 visualize_q1.py 绘图使用）
chart = {
    'labels': [str(rows[i][0])[:5] for i in range(N)],   # 各间隔结束时刻，如 '00:10' ... '0:00+'
    'price':  [round(float(v), 4) for v in price],       # 电价 元/kWh
    'buy':    [round(float(v), 2) for v in X],           # 购电量 kWh/10min
    'store':  [round(float(v), 1) for v in S],           # 储电量 kWh（145个边界值）
}
with open(CHART_JSON, 'w', encoding='utf-8') as f:
    json.dump(chart, f, ensure_ascii=False)
print('可视化数据已导出:', CHART_JSON)

# 对照：无储能（光伏直供 + 缺口按时段电价直购）的基准购电费，用于量化储能套利价值
base_buy = np.maximum(l - pvE, 0.0)                    # 每区间净购电量=max(负载-光伏,0)
base_cost = float((price * base_buy).sum())
print('对照(无储能) 购电量 = %.2f kWh, 购电费 = %.2f 元, 储能节约 = %.2f 元'
      % (base_buy.sum(), base_cost, base_cost - total_cost))

# 指定时段购电量（表1）: 区间 [10:00,10:10) 等 = 附件1 中 10:10 等行（结束时刻口径）
def idx_of(hhmm):   # 附件1 时间字符串/时刻 -> 数据行号(0起)
    for j, t in enumerate(rows):
        s = str(t[0])
        if s.startswith(hhmm):
            return j
    raise KeyError(hhmm)
t1_periods = ['10:10','12:10','14:10','16:10','18:10','20:10']   # 表1六个指定区间的结束时刻
print('\n== 表1 指定时段购电量 ==')
for s in t1_periods:
    j = idx_of(s)
    start = s[:2] + ':00'
    print('%s-%s  购电 %.2f kWh  费用 %.2f 元' % (start, s[:5], X[j], price[j]*X[j]))

# 四小时块充放电量（表2）：(块名, 起始区间, 结束区间)，每块24个区间=4小时
blocks = [('0:00-4:00', 0, 24), ('4:00-8:00', 24, 48), ('8:00-12:00', 48, 72),
          ('12:00-16:00', 72, 96), ('16:00-20:00', 96, 120), ('20:00-24:00', 120, 144)]
print('\n== 表2 充放电量 ==')
for name, a, b in blocks:
    print('%s  充电 %.2f kWh  放电 %.2f kWh' % (name, C[a:b].sum(), D[a:b].sum()))
print('0:00 储电量 = %.2f kWh, 24:00 储电量 = %.2f kWh' % (S[0], S[N]))

# ------------------------- 5. 写出 result1.xlsx -------------------------
# 5.1 读取模板的“时间段”标签，保证输出的区间标签与官方模板完全一致
tpl = openpyxl.load_workbook(TPL)
tpl_pd = tpl['计划购电量']
labels = [tpl_pd.cell(r, 1).value for r in range(2, tpl_pd.max_row+1)]
assert labels[-1] == '0:00+1-0:10+1', labels[-1]   # 最后一行必须是跨日区间标签

out = openpyxl.Workbook()
# --- 工作表1: 计划购电量（模板: A=时间段, B=购电量kWh）---
ws1 = out.active; ws1.title = '计划购电量'
ws1.append(['时间段', '购电量'])
for k, lab in enumerate(labels):     # k=0..143 对应数据行 1..144, k=144 -> 行0(周期)
    j = k+1 if k < N-1 else 0        # 模板行 k+1 对应数据行 k+1; 最后一行(次日0:00-0:10)取行0
    ws1.append([lab, round(float(X[j]), 4)])
# 汇总两行
ws1.append(['全天购电量', round(float(total_buy), 4)])
ws1.append(['全天购电费', round(float(total_cost), 4)])

# --- 工作表2: 充放电量（A=时间段 B=充电量 C=放电量 D=时刻 E=储电量）---
ws2 = out.create_sheet('充放电量')
ws2.append(['时间段', '充电量', '放电量', '时刻', '储电量'])
for name, a, b in blocks:
    ws2.append([name, round(float(C[a:b].sum()), 4), round(float(D[a:b].sum()), 4), None, None])
ws2.append([None, None, None, '0:00', round(float(S[0]), 4)])    # 首储电量
ws2.append([None, None, None, '24:00', round(float(S[N]), 4)])   # 末储电量（=首，日循环）

# --- 工作表3: 购电量与金额（A=时间段 B=购电量 C=购电金额）---
ws3 = out.create_sheet('购电量与金额')
ws3.append(['时间段', '购电量(kWh)', '购电金额(元)'])
for k, lab in enumerate(labels):
    j = k+1 if k < N-1 else 0
    ws3.append([lab, round(float(X[j]), 4), round(float(price[j]*X[j]), 4)])
ws3.append(['全天购电量', round(float(total_buy), 4), ''])
ws3.append(['全天购电费', '', round(float(total_cost), 4)])

# 保存结果；若 result1.xlsx 正被 WPS/Excel 打开（文件占用），自动另存并给出提示
SAVED = OUT
try:
    out.save(SAVED)
    print('\n已保存:', SAVED)
except PermissionError:
    SAVED = os.path.join(Q1, 'result1_副本.xlsx')
    out.save(SAVED)
    print('\n提示: result1.xlsx 正被 WPS/Excel 占用（文件正在打开），无法覆盖写入。')
    print('已自动另存为:', SAVED)
    print('如需直接生成 result1.xlsx，请先在 WPS/Excel 中关闭该文件，再重新运行本脚本。')

# ------------------------- 6. 结果回读校验（写完再读回来核对） -------------------------
chk = openpyxl.load_workbook(SAVED, data_only=True)
w1 = chk['计划购电量']
purchases = [w1.cell(r,2).value for r in range(2, 2+len(labels))]   # 144个区间购电量
sum_back = sum(purchases)
print('回读校验: 计划购电量表 %d 行, 合计 = %.4f (应为 %.4f), 差异 = %.2e'
      % (len(purchases), sum_back, total_buy, sum_back-total_buy))
w2 = chk['充放电量']
print('充放电量表行数 =', w2.max_row, '(应为 9)')   # 表头+6块+0:00+24:00
w3 = chk['购电量与金额']
tot1 = w3.cell(2+len(labels), 2).value    # 全天购电量单元格
tot2 = w3.cell(3+len(labels), 3).value    # 全天购电费单元格
print('明细表: 全天购电量 =', tot1, ', 全天购电费 =', tot2)
