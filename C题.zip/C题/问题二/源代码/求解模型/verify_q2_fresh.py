# -*- coding: utf-8 -*-
"""独立回读校验已生成的 result2.xlsx（不重跑 LP）。
属于三层可行性校验的“结构/一致性”层：只打开结果文件，核对行数、日期范围、
行内合计、块口径、紧急购电是否为空、有无省略符残留等，确保写出的表本身自洽。"""
import datetime as dt
import openpyxl

OUT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题\问题二\result2.xlsx'
wb = openpyxl.load_workbook(OUT, data_only=True)
c1, c2, c3 = wb['计划购电量'], wb['充放电量'], wb['紧急购电量']

# 1) 计划购电量：表头 + 334 天，日期范围与模板一致（2025-02-01 ~ 2025-12-31）
assert c1.max_row == 335, c1.max_row
d1 = [c1.cell(r, 1).value.date() for r in range(2, 336)]
assert d1[0] == dt.date(2025, 2, 1) and d1[-1] == dt.date(2025, 12, 31) and len(d1) == 334
# 每行 144 区间列求和 = 全天购电量列（第146列），逐行校验，容差0.01
bad = 0
for r in range(2, 336):
    vals = [c1.cell(r, 2+k).value for k in range(144)]
    if abs(sum(vals) - c1.cell(r, 146).value) > 0.01:
        bad += 1
assert bad == 0, f'全天购电量与区间求和不一致的行数: {bad}'
print('计划购电量: 334 天日期正确，144 列求和与全天购电量逐行一致 ✓')

# 2) 充放电量：334 天 × 6 块 = 2004 行（+表头共2005行），日期首块行、0:00/24:00 储电量位置正确
assert c2.max_row == 2005, c2.max_row
# 只有每天首块行带日期，收集这些日期核对数量与首尾
d2 = [c2.cell(r, 1).value for r in range(2, 2006) if c2.cell(r, 1).value is not None]
assert len(d2) == 334 and str(d2[0].date()) == '2025-02-01' and str(d2[-1].date()) == '2025-12-31'
names = [c2.cell(2+i, 2).value for i in range(6)]   # 六个4小时块标签
assert names == ['0:00-4:00', '4:00-8:00', '8:00-12:00', '12:00-16:00', '16:00-20:00', '20:00-24:00']
# 每天首块行第5列是 0:00 时刻，第二块行第5列是字符串 '24:00'
assert c2.cell(2, 5).value == dt.time(0, 0) and c2.cell(3, 5).value == '24:00'
# 抽查：块1充电量的跨天口径是否与 JSON 记录一致
import json
j = json.load(open(r'D:\my\数学建模大赛\2026\2026国赛赛题\C题\问题二\数据\q2_fresh_results.json', encoding='utf-8'))
rec2_1 = next(x for x in j['daily'] if x['date'] == '2025-02-01')
rec1_31 = next(x for x in j['daily'] if x['date'] == '2025-01-31')
# 块1（0:00-4:00）= 当日区间0..22 + 前一日最后一个区间143（结束时刻口径下143对应0:00-0:10）
ff = j['focus_full']['2025-03-20']
prev = next(x for x in j['daily'] if x['date'] == '2025-03-19')
exp_blk1_c = sum(ff['C'][0:23]) + prev['c143']
idx_full = next(i for i, x in enumerate(j['daily']) if x['date'] == '2025-03-20')
row_blk1 = 2 + 6 * (idx_full - 31)                 # daily 从1月起算，输出从第31天(2/1)开始
assert abs(c2.cell(row_blk1, 3).value - exp_blk1_c) < 0.01, (c2.cell(row_blk1, 3).value, exp_blk1_c)
print('充放电量: 334 天 × 6 块结构、0:00/24:00 储电量位置与数值、块1口径 ✓')

# 3) 紧急购电量：334 天日期、数值列全空（确定性最优下紧急购电恒为0）
d3 = [c3.cell(r, 1).value for r in range(2, 1002) if c3.cell(r, 1).value is not None]
assert len(d3) == 334 and str(d3[-1].date()) == '2025-12-31'
em = [c3.cell(r, c).value for r in range(2, 1002) for c in (2, 3) if c3.cell(r, c).value not in (None, '')]
assert em == [], em[:5]
print('紧急购电量: 334 天日期齐全，购电时间段/购电量全空（无紧急购电）✓')

# 4) 无省略符残留（防止开发期用 ⁝ 折叠行后忘记展开）
for ws in (c1, c2, c3):
    for row in ws.iter_rows(values_only=True):
        assert '⁝' not in row, '仍残留省略行'
print('无省略符残留 ✓')
print('\n全部回读校验通过')
