# -*- coding: utf-8 -*-
"""
对照验证：全局全年 LP（完美信息全局最优） vs 逐日滚动 LP
用途：量化问题2 "每天0:00制定当天策略"（逐日滚动）相对全局最优的成本差距，
      验证逐日滚动方案的有效性。
说明：全局 LP 假设一开始就掌握全年365天全部负载/光伏，一次性优化整年储能轨迹，
      是理论下界（现实中做不到）；逐日滚动只知道当天信息，靠日末SOC向后耦合。
      两者费用差即“滚动决策”的近优性代价（论文中报告为 0.237%）。
"""
import os
import numpy as np
import pandas as pd
import scipy.sparse as sp          # 全年LP变量/约束巨大，用稀疏矩阵构造
from scipy.optimize import linprog

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')

H, ETA = 1/6, 0.9                  # 区间时长、充放效率
E_MAX = 5000.0 * H                 # 单区间充/放上界 833.333 kWh
S_MIN, S_MAX, S_INIT = 1200.0, 10800.0, 6000.0   # SOC区间、年初初始电量
N, DAYS = 144, 365
EMULT = 5.0                        # 紧急购电单价倍数（最优解中不会被使用）

# ---- 读取并按“结束时刻口径”拼成全年逐区间序列 ----
att1 = pd.read_excel(ATT1)
price_raw = att1['电价'].to_numpy(float)
# 循环移位：区间0:00-0:10取附件1的0:10行……最后一区间取次日0:00=本日0:00行
price_day = np.concatenate([price_raw[1:], price_raw[:1]])
load = pd.read_excel(ATT2, sheet_name='小区负载').iloc[:, 1:].to_numpy(float)
pv   = pd.read_excel(ATT2, sheet_name='光伏发电实际功率').iloc[:, 1:].to_numpy(float)

def day_vector(mat, d):
    """取第 d 天的144维日向量：k=0..142取当天第k+1列，k=143跨天取下一天第0列。"""
    v = np.empty(N)
    v[:N-1] = mat[d, 1:N]
    v[N-1] = mat[d+1, 0] if d+1 < DAYS else mat[d, N-1]   # 年末最后一天无次日，退回本列
    return v

L = np.concatenate([day_vector(load, d) * H for d in range(DAYS)])   # 全年负载电量 kWh
PV = np.concatenate([day_vector(pv, d) * H for d in range(DAYS)])    # 全年光伏电量 kWh
PR = np.tile(price_day, DAYS)                                        # 电价每天相同，平铺365份

T = DAYS * N                        # 52,560 个区间
NX = T
# 决策变量分块：x购电/c充电/d放电/u光伏利用/e紧急购电 各T个 + S 共T+1个
off = {'x': 0, 'c': NX, 'd': 2*NX, 'u': 3*NX, 'e': 4*NX, 'S': 5*NX}
nv = 5*NX + (T + 1)

c_obj = np.zeros(nv)
c_obj[off['x']:off['x']+NX] = PR              # 普通购电单价 p
c_obj[off['e']:off['e']+NX] = EMULT * PR      # 紧急购电单价 5p

# 用 COO 三元组(行,列,值)稀疏装配等式约束：每区间2条（母线平衡+储能递推）
rows, cols, vals = [], [], []
b_eq = np.zeros(2*T)
for t in range(T):
    # 母线平衡: x+u+ηd+e−c = L
    rows += [t]*5
    cols += [off['x']+t, off['u']+t, off['d']+t, off['e']+t, off['c']+t]
    vals += [1.0, 1.0, ETA, 1.0, -1.0]
    b_eq[t] = L[t]
    # 储能递推: S_{t+1}−S_t−ηc+d = 0（全年连续，不做日循环闭合）
    rows += [T+t]*4
    cols += [off['S']+t+1, off['S']+t, off['c']+t, off['d']+t]
    vals += [1.0, -1.0, -ETA, 1.0]

A_eq = sp.csr_matrix((vals, (rows, cols)), shape=(2*T, nv))
bounds = [(0.0, None)] * nv
for t in range(T):
    bounds[off['c']+t] = (0.0, E_MAX)
    bounds[off['d']+t] = (0.0, E_MAX)
    bounds[off['u']+t] = (0.0, PV[t])
for i in range(T+1):
    bounds[off['S']+i] = (S_MIN, S_MAX)
bounds[off['S']] = (S_INIT, S_INIT)           # 仅年初(1/1 0:00)固定为6000，年末自由

print('全局 LP 规模: 变量 %d, 等式约束 %d, 非零元 %d' % (nv, 2*T, len(vals)))
res = linprog(c_obj, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method='highs')
if not res.success:
    raise RuntimeError(res.message)

X = res.x[off['x']:off['x']+NX]
E = res.x[off['e']:off['e']+NX]
S = res.x[off['S']:off['S']+NX+1]
cost_all = float((PR * (X + EMULT*E)).sum())             # 全年（含1月预热）费用
cost_rep = float((PR[DAYS*N:][31*N:] * (X[DAYS*N:][31*N:] + EMULT*E[DAYS*N:][31*N:])).sum())
# 输出区间 2.1-12.31：区间下标 [31*144, 365*144)，与逐日滚动的输出口径对齐
rep = slice(31*N, DAYS*N)
cost_rep = float((PR[rep] * (X[rep] + EMULT*E[rep])).sum())
print('全局最优全年总购电费: %.2f 元' % cost_all)
print('全局最优 2.1-12.31 购电费: %.2f 元' % cost_rep)
print('逐日滚动 2.1-12.31 购电费: 12262168.58 元')
gap = (12262168.58 - cost_rep) / cost_rep * 100          # 滚动相对全局的额外成本比例
print('逐日滚动相对全局最优的额外成本: %.2f 元 (%.3f%%)' % (12262168.58 - cost_rep, gap))
print('全局最优年末(12/31 24:00)储电量: %.2f kWh' % S[-1])
print('紧急购电总量: %.6f kWh' % E.sum())
