# -*- coding: utf-8 -*-
"""逐小时校验：3/20 电价与 X/C/D/S 的经济逻辑一致性。
即人工抽查指定日的策略是否符合“低价充电、高价放电、峰段少购电”的套利逻辑。"""
import json
import numpy as np

# 读取主求解器保存的逐日结果（含当日144维 X购电/C充电/D放电/S储电轨迹）
j = json.load(open(r'D:\my\数学建模大赛\2026\2026国赛赛题\C题\问题二\数据\q2_fresh_results.json', encoding='utf-8'))
price = np.array(j['price_day'])               # 循环移位后的当日电价序列（结束时刻口径）
r = j['focus_full']['2025-03-20']              # 春分指定日的完整解
X, C, D, S = np.array(r['X']), np.array(r['C']), np.array(r['D']), np.array(r['S'])

print('时刻   电价   购电X    充电C    放电D   储电S(时段初)')
# 每 30 分钟打印一行（间隔 3 个区间）；v[k] = 区间 [(k+1)*10,(k+2)*10) 分钟，标签取结束时刻
for k in range(0, 144, 3):
    t = (k + 2) * 10            # 区间结束时刻(分钟)：数据按结束时刻排列，故+2个10分钟
    hh, mm = t // 60, t % 60
    print('%02d:%02d  %6.4f  %8.1f %8.1f %8.1f  %8.1f'
          % (hh, mm, price[k], X[k], C[k], D[k], S[k]))
# 关键时段合计（区间 [a,b) 按下标计），用于观察各时段充/放/购电的总量方向
for name, a, b in [('0:00-4:00', 0, 23), ('4:00-8:00', 23, 47), ('7:00-9:00', 41, 54),
                   ('11:00-14:00', 65, 84), ('16:00-20:00', 95, 119), ('19:00-21:00', 113, 126)]:
    print('%-12s 购电%9.1f 充电%9.1f 放电%9.1f' % (name, X[a:b].sum(), C[a:b].sum(), D[a:b].sum()))
# 标出全天电价最低/最高出现时刻（结束时刻分钟），对照策略是否在最低点附近充满
print('电价峰谷: min %.4f @结束%dmin | max %.4f @结束%dmin' % (price.min(), 10*(price.argmin()+2), price.max(), 10*(price.argmax()+2)))
