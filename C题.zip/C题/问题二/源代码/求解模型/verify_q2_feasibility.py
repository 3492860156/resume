# -*- coding: utf-8 -*-
"""
问题2 结果可行性与一致性校验（层1+层2，不重跑 LP）
=====================================================================
层1 表内块级：由 result2.xlsx「充放电量」按正确口径
        S(i+1)=S(i)+0.9c(i)-d(i) 递推，核日末闭合、SOC 边界[1200,10800]、
        跨天连续（当日0:00 S=前日24:00 S）、块功率必要界(≤20000 kWh/4h)；
        并与 q2_fresh_results.json 逐日交叉核对。
层2 10分钟粒度（4个指定日）：储能递推残差、母线平衡 x+u+0.9d = L+c、
        0≤u≤光伏、SOC 边界、功率≤833.3333kWh、无同时充放。
层3（独立重解逐格比对）见 verify_q2_resolve_compare.py。
模型口径（与 solve_q2_fresh.py 一致）：双侧效率各 90%（循环效率 0.81）。
"""
import json, sys, io, datetime
import numpy as np, pandas as pd, openpyxl
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')   # 强制控制台UTF-8，防中文乱码

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
XLSX = ROOT + r'\问题二\result2.xlsx'
JSONP = ROOT + r'\问题二\数据\q2_fresh_results.json'
ATT2 = ROOT + r'\附件\附件2.xlsx'
ETA, H = 0.9, 1/6
S_MIN, S_MAX, P_MAX = 1200.0, 10800.0, 5000.0
E_MAX_SLOT = P_MAX * H            # 833.3333 kWh / 10min（单区间功率上界）
E_MAX_BLOCK = 24 * E_MAX_SLOT     # 20000 kWh / 4h（一个4小时块的必要上界）
FOCUS = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']   # 四个指定日

# ---------------- 层1：表内块级 ----------------
# 把「充放电量」表按“首块行带日期”重组为每天一条记录（6块 + s0 + s24）
wb = openpyxl.load_workbook(XLSX, read_only=True, data_only=True)
rows = [r for r in wb['充放电量'].iter_rows(values_only=True)][1:]
days, cur = [], None
for r in rows:
    if r[0] is not None:                       # 出现日期 => 新的一天
        cur = {'date': r[0], 'blocks': [], 's0': None, 's24': None}
        days.append(cur)
    cur['blocks'].append((r[2] or 0.0, r[3] or 0.0))   # (块充电量, 块放电量)
    if r[4] == datetime.time(0, 0):            # 时刻列=0:00 → 记录日初储电量
        cur['s0'] = r[5]
    if r[4] == '24:00':                        # 时刻列='24:00' → 记录日末储电量
        cur['s24'] = r[5]
assert len(days) == 334 and set(len(d['blocks']) for d in days) == {6}

# 用块级 c/d 从 s0 递推到日末，检查闭合、边界、跨天连续、块功率
close_bad = bound_bad = power_bad = cont_bad = 0
max_close = hi = lo = 0.0
prev_s24 = None
for d in days:
    soc = d['s0']
    if prev_s24 is not None and abs(soc - prev_s24) > 1e-4:   # 当日0:00应=前日24:00
        cont_bad += 1
    for c, dis in d['blocks']:
        soc = soc + ETA*c - dis                # 块级递推（充入打9折）
        hi = max(hi, soc - S_MAX); lo = max(lo, S_MIN - soc)  # 记录最大越界幅度
        if not (S_MIN - 1e-4 <= soc <= S_MAX + 1e-4):
            bound_bad += 1
        if c > E_MAX_BLOCK + 1e-4 or dis > E_MAX_BLOCK + 1e-4:
            power_bad += 1
    max_close = max(max_close, abs(soc - d['s24']))           # 递推日末 vs 表内s24
    if abs(soc - d['s24']) > 1e-3:
        close_bad += 1
    prev_s24 = d['s24']
print('[层1] 334天×6块：日末不闭合%d（最大偏差%.1e）｜块末越界%d（上越%.1e/下越%.1e kWh）'
      '｜跨天断裂%d｜块功率超限%d' % (close_bad, max_close, bound_bad, hi, lo, cont_bad, power_bad))

# 与 JSON 逐日记录交叉核对（注意块1含前一日143区间的跨天口径）
j = json.load(open(JSONP, encoding='utf-8'))
daily = {x['date']: x for x in j['daily']}
mc = md_ = ms0 = ms24 = 0.0
for d in days:
    rec = daily[d['date'].strftime('%Y-%m-%d')]
    prev = daily[(d['date'] - datetime.timedelta(days=1)).strftime('%Y-%m-%d')]
    # 表内块充电合计应=当日总充电-当日143区间+前日143区间（143被划到次日块1）
    exp_c = rec['chg'] - rec['c143'] + prev['c143']
    exp_d = rec['dis'] - rec['d143'] + prev['d143']
    mc = max(mc, abs(sum(b[0] for b in d['blocks']) - exp_c))
    md_ = max(md_, abs(sum(b[1] for b in d['blocks']) - exp_d))
    ms0 = max(ms0, abs(d['s0'] - rec['s0'])); ms24 = max(ms24, abs(d['s24'] - rec['s24']))
print('[层1] 与JSON交叉：块充电量偏差%.1e｜块放电量偏差%.1e｜s0偏差%.1e｜s24偏差%.1e'
      % (mc, md_, ms0, ms24))

# ---------------- 层2：四指定日 10 分钟粒度 ----------------
load_df = pd.read_excel(ATT2, sheet_name='小区负载')
pv_df = pd.read_excel(ATT2, sheet_name='光伏发电实际功率')
dates = pd.to_datetime(load_df.iloc[:, 0]).dt.strftime('%Y-%m-%d').tolist()
load_mat = load_df.iloc[:, 1:].to_numpy(float)
pv_mat = pv_df.iloc[:, 1:].to_numpy(float)

def day_vector(mat, idx):
    """与主求解器相同的跨天取数：前143列取当天1:144，末列取次日第0列。"""
    v = np.empty(144)
    v[:143] = mat[idx, 1:144]
    v[143] = mat[idx+1, 0] if idx+1 < 365 else mat[idx, 143]
    return v

print('[层2] 四指定日 10分钟粒度：')
for f in FOCUS:
    idx = dates.index(f)
    L = day_vector(load_mat, idx) * H       # 负载电量
    PV = day_vector(pv_mat, idx) * H        # 光伏电量
    rr = j['focus_full'][f]
    X, C, D, S = (np.array(rr[k]) for k in ('X', 'C', 'D', 'S'))
    rec_res = float(np.abs(S[1:] - S[:-1] - ETA*C + D).max())     # 储能递推残差
    U = L + C - X - ETA*D                       # 母线平衡（e=0）反推光伏利用：u = L+c-x-0.9d
    bal_res = float(np.abs(X + U + ETA*D - C - L).max())          # 母线平衡残差
    n_bad_u = int(((U < -1e-7) | (U > PV + 1e-7)).sum())         # 光伏利用越界计数
    n_bad_s = int(((S < S_MIN-1e-6) | (S > S_MAX+1e-6)).sum())   # SOC越界计数
    n_bad_p = int((C > E_MAX_SLOT+1e-6).sum() + (D > E_MAX_SLOT+1e-6).sum())  # 功率越界
    n_sim = int(((C > 1e-6) & (D > 1e-6)).sum())                 # 同时充放（应0）
    print('  %s 递推残差%.1e 平衡残差%.1e u越界%d SOC越界%d 功率越界%d 同时充放%d S∈[%.0f,%.0f]'
          % (f, rec_res, bal_res, n_bad_u, n_bad_s, n_bad_p, n_sim, S.min(), S.max()))
wb.close()
print('\n校验完成：层1/层2 全部通过即结果与模型约束相容（层3见 verify_q2_resolve_compare.py）')
