# -*- coding: utf-8 -*-
"""
2026 国赛 C 题 · 问题 2 —— 从零求解（逐日线性规划，跨天储能递推）
====================================================================
模型要点（全部依据题目原文与附件自建，未参考任何外部资料）：
  1) 时间口径：附件2/附件1 列时间 t 代表 10 分钟区间 [t-10min, t)（结束时刻标注）。
     模板 result2 的计划购电量列 "t1-t2" 取附件2 中 t2 时刻的列；
     模板末列 "0:00-0:10+1" 取次日 0:10 列（12/31 无次日数据，以当日 0:00+1 列近似）。
  2) 决策（每天 0:00 制定，144 个 10 分钟时段）：
       x_i 计划购电量 / c_i 充电量 / d_i 放电量 / u_i 光伏使用量 / e_i 紧急购电量 / S_i 储电量
  3) 约束：
       母线平衡:  x_i + u_i + η·d_i + e_i = L_i + c_i        （光伏可弃）
       储能递推:  S_{i+1} = S_i + η·c_i − d_i，η = 0.9
       边界:      1200 ≤ S_i ≤ 10800；c_i, d_i ≤ 5000kW×10min = 833.3333 kWh
       初始:      2025-01-01 0:00 储电量 = 6000 kWh（附录1）
  4) 目标：min Σ 电价_i·(x_i + 5·e_i)。紧急购电为 5 倍时刻电价的安全阀；
     问题2为全信息确定性问题，计划购电无上限 ⇒ 最优解 e_i ≡ 0（模型内保留该机制）。
  5) 求解：每天一个 LP（scipy.optimize.linprog / HiGHS），逐天滚动、跨天递推储电量；
     1月为预热期，结果文件按题目要求只输出 2025.2.1–12.31（334 天）。
  6) 表2 时间块的精确对齐：块 "0:00-4:00" = 当日 [0:00,0:10)（即前一日行的末区间）
     与当日 [0:10,4:00) 之和；其余块为当日连续区间（详见代码 BLOCKS）。
     "0:00储电量" = 当日 0:00 真实储电量 = 前一日行末区间起点储电量；
     "24:00储电量" = 当日 24:00 真实储电量 = 当日行末区间起点储电量。

输出：
  result2.xlsx  —— 计划购电量 / 充放电量 / 紧急购电量（334 天全展开，无省略行）
  q2_fresh_results.json —— 全年逐日结果（论文表格与可视化复用）
  论文表格数据_Q2.md   —— 4 个指定日期的表1/表2/表3 数据

=========================== 详细备注版说明 ===========================
本文件为【最终求解器】，注释仅作解释，不改变任何求解逻辑；单位约定：
  · 附件中负载/光伏列是功率(kW)，乘区间时长 H=1/6 h 后换算成电量(kWh)；
  · 电价单位 元/kWh，故 价格×电量 直接得到费用(元)；
  · 下标 i/k 均为区间编号 0..143，S 有 145 个节点（区间首尾各一个状态点）。
"""
import os
import json
import datetime as dt

import numpy as np
import pandas as pd
import openpyxl
from scipy.optimize import linprog

# ----------------------------- 0. 路径与常量 -----------------------------
ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'          # 赛题目录根
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')              # 电价(144) + 单日负载/光伏预测
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')              # 全年365天 × 144 区间实际负载/光伏
TPL  = os.path.join(ROOT, '附件', '附件5', 'result2.xlsx')    # 官方结果模板（复制后填充，不改模板原件）
OUTDIR = os.path.join(ROOT, '问题二')
OUT_XLSX = os.path.join(OUTDIR, 'result2.xlsx')        # 最终结果表（勿覆盖）
OUT_JSON = os.path.join(OUTDIR, '数据', 'q2_fresh_results.json')     # 求解明细（可视化/论文复用）
OUT_MD   = os.path.join(OUTDIR, '论文表格数据_Q2.md')         # 四指定日表1/2/3 数据

H = 1.0 / 6.0        # 区间时长：10 分钟 = 1/6 小时（功率×H 得电量）
ETA = 0.9            # 充/放电效率 90%（双侧：充电乘0.9入库，放电时放出0.9到母线）
P_MAX = 5000.0       # 最大充/放电功率 5000 kW（附录1）
E_MAX = P_MAX * H    # 单区间最大充/放电量 = 833.3333 kWh（附录1功率上限的电量形式）
S_MIN, S_MAX = 1200.0, 10800.0   # SOC 允许区间（附录1：容量12000的10%~90%）
S_INIT = 6000.0      # 2025-01-01 0:00 储电量（附录1给定的全年唯一初始条件）
N = 144              # 每天 144 个 10 分钟区间
EMULT = 5.0          # 紧急购电电价倍数（问题2原文：交易时刻电价的5倍）

FOCUS = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']  # 表3指定的4个日期
# 表1六个指定时间段 → 当日LP区间下标；如 10:00-10:10 区间结束时刻10:10=第610分钟，(610/10)-2=59
T1_SPECS = [('10:00-10:10', 59), ('12:00-12:10', 71), ('14:00-14:10', 83),
            ('16:00-16:10', 95), ('18:00-18:10', 107), ('20:00-20:10', 119)]
# 表2 的六个 4 小时时间块名称
BLOCK_NAMES = ['0:00-4:00', '4:00-8:00', '8:00-12:00', '12:00-16:00',
               '16:00-20:00', '20:00-24:00']
# 每个块由哪些LP区间构成（元组第二项=需额外借用前一日行的区间下标）：
#   当日LP列序为 0:20..24:00,次日0:10；故 0:00-4:00 块 = 当日 k=0..22（0:20~4:00）
#   再加上前一日 k=143（跨日的 [0:00,0:10) 区间），凑满 0:00~4:00 共24个区间；
#   其余块均为当日连续24个区间，无需借位。
BLOCK_K = [(list(range(0, 23)), 143), (list(range(23, 47)), None),
           (list(range(47, 71)), None), (list(range(71, 95)), None),
           (list(range(95, 119)), None), (list(range(119, 143)), None)]

# ----------------------------- 1. 读取数据 -----------------------------
att1 = pd.read_excel(ATT1)
assert len(att1) == 144 and '电价' in att1.columns   # 附件1必须恰好144行且含电价列
price_raw = att1['电价'].to_numpy(dtype=float)          # 行序 0:10..0:00+1（144）

load_df = pd.read_excel(ATT2, sheet_name='小区负载')
pv_df   = pd.read_excel(ATT2, sheet_name='光伏发电实际功率')
dates_all = pd.to_datetime(load_df.iloc[:, 0]).dt.date.to_numpy()  # 365个日期
load_mat = load_df.iloc[:, 1:].to_numpy(dtype=float)    # (365,144) 单位kW，列按结束时刻0:10..24:00
pv_mat   = pv_df.iloc[:, 1:].to_numpy(dtype=float)
assert load_mat.shape == (365, 144) and pv_mat.shape == (365, 144)   # 全年完整性校验
assert str(dates_all[0]) == '2025-01-01' and str(dates_all[-1]) == '2025-12-31'  # 日期首尾校验

# 当日行（模板列序）向量：模板一行从 0:20 列开始、到次日 0:10 列结束，
# 故 k=0..142 取当日第 k+1 列（0:20..24:00）；k=143 借次日第0列（次日0:10）；
# 12/31 无次日数据，末尾区间以当日最后一列近似。
def day_vector(mat, d):
    v = np.empty(N)
    v[:N-1] = mat[d, 1:N]
    v[N-1] = mat[d+1, 0] if d + 1 < 365 else mat[d, N-1]
    return v

# 电价每天相同，但要与模板列序对齐：原始 0:10..24:00 循环左移一位 → 0:20..24:00,0:10
price_day = np.concatenate([price_raw[1:], price_raw[:1]])

# ----------------------------- 2. 单日 LP -----------------------------
def solve_day(load_kW, pv_kW, price, s_init):
    """求解一天的线性规划。
    输入：当日144点负载(kW)、光伏(kW)、144点电价(元/kWh)、当日起始储电量 s_init(kWh)
    变量排列（共 5*144+145=865 个）：x|c|d|u|e 各144，S 145；off 记录各变量块起始偏移。
    """
    L = load_kW * H          # 负载电量(kWh)：功率×1/6h
    PV = pv_kW * H           # 光伏可发电量(kWh)
    nv = 5 * N + (N + 1)     # 变量总数
    off = {'x': 0, 'c': N, 'd': 2*N, 'u': 3*N, 'e': 4*N, 'S': 5*N}
    vid = lambda i, k: off[k] + i      # 取第 i 区间第 k 类变量的全局下标

    # ---- 目标函数系数：x 系数=时刻电价；e 系数=5倍时刻电价；其余变量不直接花钱，系数0
    c_obj = np.zeros(nv)
    c_obj[off['x']:off['x']+N] = price
    c_obj[off['e']:off['e']+N] = EMULT * price

    # ---- 等式约束 A_eq·z = b_eq，共 2*144 行：前144行母线平衡，后144行储能递推
    A_eq = np.zeros((2*N, nv))
    b_eq = np.zeros(2*N)
    for i in range(N):                       # 母线平衡：x+u+ηd+e−c = L（供给=负载+充电去向）
        A_eq[i, vid(i,'x')] = 1; A_eq[i, vid(i,'u')] = 1
        A_eq[i, vid(i,'d')] = ETA; A_eq[i, vid(i,'e')] = 1
        A_eq[i, vid(i,'c')] = -1
        b_eq[i] = L[i]
    for i in range(N):                       # 储能递推：S_{i+1}−S_i−ηc+d = 0
        A_eq[N+i, vid(i+1,'S')] = 1; A_eq[N+i, vid(i,'S')] = -1
        A_eq[N+i, vid(i,'c')] = -ETA; A_eq[N+i, vid(i,'d')] = 1

    # ---- 变量边界（全部非负，再叠加物理上限）
    bounds = [(0.0, None)] * nv              # 默认 [0,+∞)：x、e 无上限（计划购电不限量）
    for i in range(N):
        bounds[vid(i,'c')] = (0.0, E_MAX)    # 单区间充电量 ≤ 833.33 kWh
        bounds[vid(i,'d')] = (0.0, E_MAX)    # 单区间放电量 ≤ 833.33 kWh
        bounds[vid(i,'u')] = (0.0, PV[i])    # 光伏使用量不能超过可发电量（多余即弃光）
    for i in range(N+1):
        bounds[vid(i,'S')] = (S_MIN, S_MAX)  # 储电量始终落在 [1200,10800]
    bounds[vid(0,'S')] = (s_init, s_init)    # 当日首个状态点锁死为传入的跨天初始值

    # ---- 调用 HiGHS 单纯形/内点求解器
    res = linprog(c_obj, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError(f'LP 求解失败: {res.message}')
    get = lambda k: res.x[off[k]:off[k]+N]  # 按变量块切片还原144维向量
    X, C, D, U, E = get('x'), get('c'), get('d'), get('u'), get('e')
    S = res.x[off['S']:off['S']+N+1]         # 储电量轨迹145个点
    return X, C, D, U, E, S

# ----------------------------- 3. 逐天滚动 365 天 -----------------------------
# 滚动机制：每天解一个独立单日LP，相邻两天只通过"日末储电量→次日初始储电量"耦合；
# 1月照常求解（预热，让6000的初值演化到稳定日界），但只输出2月起的334天。
records = []
s_init = S_INIT                 # 第一天(1/1)初始储电量=附录1的6000
max_bal = max_rec = 0.0         # 记录全年最大平衡/递推残差（数值误差体检）
sim_cd = 0                      # 统计同时充放电的区间数（最优解应为0）
for d in range(365):
    lv = day_vector(load_mat, d)   # 当日负载(kW)，已按模板列序对齐
    pv = day_vector(pv_mat, d)     # 当日光伏(kW)
    X, C, D, U, E, S = solve_day(lv, pv, price_day, s_init)

    # ---- 解后体检：把最优解代回约束，看等式残差是否仅为浮点量级
    bal = X + U + ETA*D + E - C - lv*H          # 母线平衡残差（应≈0）
    rec = S[1:] - S[:-1] - ETA*C + D            # 储能递推残差（应≈0）
    max_bal = max(max_bal, float(np.abs(bal).max()))
    max_rec = max(max_rec, float(np.abs(rec).max()))
    sim_cd += int(((C > 1e-6) & (D > 1e-6)).sum())   # 同一区间既充又放的个数（经济上不划算，应为0）
    assert S.min() >= S_MIN - 1e-6 and S.max() <= S_MAX + 1e-6   # SOC不越界
    assert C.max() <= E_MAX + 1e-6 and D.max() <= E_MAX + 1e-6   # 功率不越界
    assert E.sum() < 1e-6, '全信息最优解不应出现紧急购电'           # x无上限且1倍价，严格占优于5倍价的e
    assert abs(S[0] - s_init) < 1e-6                              # 初始状态确实被锁死

    # 0:00 储电量 = 当日 0:00 真实值 = 前一日行末区间(k=143,[0:00,0:10))的起点状态
    #（1/1 为给定初始条件 6000）
    s0_true = 6000.0 if d == 0 else float(records[-1]['S'][N-1])
    records.append({
        'date': str(dates_all[d]),
        'X': X, 'C': C, 'D': D, 'U': U, 'E': E, 'S': S,   # 各144/145维向量
        'buy': float(X.sum()), 'chg': float(C.sum()), 'dis': float(D.sum()),
        'pv_used': float(U.sum()), 'em_buy': float(E.sum()),
        'cost_plan': float((price_day*X).sum()),                       # 计划购电费=Σ电价*x
        'cost_em': float((price_day*E).sum()*EMULT),                   # 紧急购电费=5*Σ电价*e
        'c143': float(C[N-1]), 'd143': float(D[N-1]),   # 次日 [0:00,0:10) 的充/放电（块1口径）
        's0': s0_true,
        's24': float(S[N-1]),                   # 当日 24:00 = 行末区间起点（k=142区间结束于24:00）
    })
    s_init = float(S[N])                        # 滚动交接：日末状态(S[144])成为次日LP的S[0]

print('== 365 天逐日 LP 求解完成 ==')
print('母线平衡最大残差 %.2e | 储能递推最大残差 %.2e' % (max_bal, max_rec))
print('同时充放电区间数 %d | 全年紧急购电 %.6f kWh（最优解应为 0）' % (sim_cd, sum(r['em_buy'] for r in records)))
print('1/1 0:00 S=%.2f -> 12/31 24:00 S=%.2f' % (records[0]['s0'], records[-1]['s24']))

out_recs = records[31:]                          # 跳过1月预热期：2.1–12.31 共334天
assert len(out_recs) == 334
tot_buy  = sum(r['buy'] for r in out_recs)
tot_cost = sum(r['cost_plan'] + r['cost_em'] for r in out_recs)
print('输出区间 2025.2.1-12.31（334 天）：总购电量 %.2f kWh | 总购电费 %.2f 元'
      % (tot_buy, tot_cost))

# 对照基准：无储能（光伏直供 + 缺口按时刻电价直购）同期费用，用于计算储能节约率
base = 0.0
for d in range(31, 365):
    L = day_vector(load_mat, d) * H
    P = day_vector(pv_mat, d) * H
    base += float((price_day * np.maximum(L - P, 0)).sum())   # 每区间净缺口=max(负载-光伏,0)
print('对照（无储能）同期购电费 %.2f 元 | 储能套利节约 %.2f 元（%.2f%%）'
      % (base, base - tot_cost, 100*(base - tot_cost)/base))

# ----------------------------- 4. 写 result2.xlsx（模板副本填充） -----------------------------
wb = openpyxl.load_workbook(TPL)   # 打开官方模板，在副本上填，保持模板表头/格式不变

# 4.1 计划购电量：每天一行（334行）；第2~145列=144区间购电量，146列=全天合计，147列=全天购电费
ws1 = wb['计划购电量']
for m, r in enumerate(out_recs):
    row = 2 + m
    tpl = ws1.cell(row, 1).value
    assert str(tpl.date()) == r['date'], (row, tpl, r['date'])   # 行日期必须与模板严格对齐
    for k in range(N):
        ws1.cell(row, 2 + k, round(float(r['X'][k]), 4))        # 144个区间值保留4位小数
    row_sum = round(sum(round(float(r['X'][k]), 4) for k in range(N)), 4)
    ws1.cell(row, 146, row_sum)                                   # 全天购电量（与各列一致）
    ws1.cell(row, 147, round(r['cost_plan'] + r['cost_em'], 2))   # 全天购电费（元）

# 4.2 充放电量（334 天 × 6 块 = 2004 行；0:00/24:00 储电量分别落在第 1、2 块行）
# 块1 [0:00,4:00) 含当日 [0:00,0:10)（即日历前一日行的末区间），逐日精确对齐
ws2 = wb['充放电量']
if ws2.max_row >= 2:
    ws2.delete_rows(2, ws2.max_row - 1)   # 清掉模板示例行
prev_recs = [records[30]] + out_recs[:-1]       # 2/1 的前一日为 1/31（预热期最后一天）
for m, r in enumerate(out_recs):
    r0 = 2 + 6*m                                 # 每天占6行，首行行号
    dval = dt.datetime.strptime(r['date'], '%Y-%m-%d')
    pv_rec = prev_recs[m]                        # 日历前一日记录（用于块0借位）
    for bi in range(6):
        rr = r0 + bi
        if bi == 0:                              # 第1块行写日期与0:00储电量
            ws2.cell(rr, 1, dval).number_format = 'mm-dd-yy'
            ws2.cell(rr, 5, dt.time(0, 0))
            ws2.cell(rr, 6, round(r['s0'], 4))
        elif bi == 1:                            # 第2块行写24:00储电量
            ws2.cell(rr, 5, '24:00')
            ws2.cell(rr, 6, round(r['s24'], 4))
        ws2.cell(rr, 2, BLOCK_NAMES[bi])
        chg = float(r['C'][BLOCK_K[bi][0]].sum())   # 本块对应LP区间的充电量合计
        dis = float(r['D'][BLOCK_K[bi][0]].sum())   # 本块对应LP区间的放电量合计
        if bi == 0:
            chg += float(pv_rec['C'][143])      # 块0再补前一日行末区间 [0:00,0:10) 的充电
            dis += float(pv_rec['D'][143])      # 同上补放电
        ws2.cell(rr, 3, round(chg, 4))
        ws2.cell(rr, 4, round(dis, 4))

# 4.3 紧急购电量（334 天 × 3 行；最优解无紧急购电，时段与电量留空）
ws3 = wb['紧急购电量']
if ws3.max_row >= 2:
    ws3.delete_rows(2, ws3.max_row - 1)
for m, r in enumerate(out_recs):
    r0 = 2 + 3*m
    dval = dt.datetime.strptime(r['date'], '%Y-%m-%d')
    ws3.cell(r0, 1, dval).number_format = 'mm-dd-yy'   # 只写日期，时段/购电量保持空白

try:
    wb.save(OUT_XLSX)
    print('\n已保存:', OUT_XLSX)
except PermissionError:
    alt = OUT_XLSX.replace('.xlsx', '_副本.xlsx')   # 文件被Excel占用时另存，避免崩溃丢结果
    wb.save(alt)
    print('\n原路径被占用，已另存:', alt)

# ----------------------------- 5. 导出 JSON（供论文表格/可视化） -----------------------------
focus_full = {}                                   # 四指定日保留完整144/145维数组
for f in FOCUS:
    r = next(x for x in records if x['date'] == f)
    focus_full[f] = {k: (v.tolist() if isinstance(v, np.ndarray) else v)
                     for k, v in r.items()}
json.dump({
    'price_day': price_day.tolist(),
    'daily': [{k: v for k, v in r.items() if not isinstance(v, np.ndarray)} for r in records],
    'focus_full': focus_full,
}, open(OUT_JSON, 'w', encoding='utf-8'), ensure_ascii=False)
print('逐日结果已导出:', OUT_JSON)

# ----------------------------- 6. 论文表格数据（表1/表2/表3） -----------------------------
def block_cd(r, bi, prev=None):
    """计算某日第 bi 个4小时块的充/放电量合计；块0需借前一日末区间。"""
    c = float(r['C'][BLOCK_K[bi][0]].sum())
    d = float(r['D'][BLOCK_K[bi][0]].sum())
    if bi == 0 and prev is not None:
        c += float(prev['C'][143]); d += float(prev['D'][143])
    return c, d

lines = []
lines.append('# 问题2 论文表格数据（指定日期）\n')
for f in FOCUS:
    r = next(x for x in records if x['date'] == f)
    prev = records[records.index(r) - 1] if records.index(r) > 0 else None
    lines.append(f'\n## {f}\n')
    # ---- 表1：6个指定10分钟区间购电量 + 全天合计
    lines.append('### 表1 指定时间段购电量及全天购电量、购电费\n')
    lines.append('| 时间段 | 购电量(kWh) | 时间段 | 购电量(kWh) |')
    lines.append('|---|---|---|---|')
    for i in range(0, 6, 2):
        n1, k1 = T1_SPECS[i]; n2, k2 = T1_SPECS[i+1]
        lines.append(f'| {n1} | {r["X"][k1]:.4f} | {n2} | {r["X"][k2]:.4f} |')
    lines.append(f'\n全天购电量：**{r["buy"]:.2f} kWh**；全天购电费：**{r["cost_plan"]+r["cost_em"]:.2f} 元**\n')
    # ---- 表2：6个时间块充放电量 + 0:00/24:00 储电量
    lines.append('### 表2 储能设备在指定时间段的充放电量及 0:00/24:00 储电量\n')
    lines.append('| 时间段 | 充电量(kWh) | 放电量(kWh) | 时间段 | 充电量(kWh) | 放电量(kWh) |')
    lines.append('|---|---|---|---|---|---|')
    for i in range(0, 6, 2):
        c1, d1 = block_cd(r, i, prev); c2, d2 = block_cd(r, i+1, prev)
        lines.append(f'| {BLOCK_NAMES[i]} | {c1:.2f} | {d1:.2f} | {BLOCK_NAMES[i+1]} | {c2:.2f} | {d2:.2f} |')
    lines.append(f'\n0:00 储电量：**{r["s0"]:.2f} kWh**；24:00 储电量：**{r["s24"]:.2f} kWh**\n')
    # ---- 表3：紧急购电量（确定性最优解为0）
    lines.append('### 表3 紧急购电量\n')
    lines.append('| 时间段 | 购电量(kWh) |')
    lines.append('|---|---|')
    lines.append('| （无） | 0 |')
    lines.append('\n> 说明：问题2为全信息确定性规划，5 倍电价紧急购电恒劣于计划购电，最优解不发生紧急购电。\n')

open(OUT_MD, 'w', encoding='utf-8').write('\n'.join(lines))
print('论文表格数据已导出:', OUT_MD)

# ----------------------------- 7. 结果回读校验（写完文件再读回来核对） -----------------------------
chk = openpyxl.load_workbook(OUT_XLSX, data_only=True)
c1, c2, c3 = chk['计划购电量'], chk['充放电量'], chk['紧急购电量']
assert c1.max_row == 335, c1.max_row                 # 表头+334天
assert c2.max_row == 2005, c2.max_row               # 表头+334×6行
assert c3.max_row == 1001, c3.max_row        # 每天 3 行、仅首行写日期 → 末日期行 2+333*3
d1 = [c1.cell(r, 1).value.date() for r in range(2, 336)]
assert d1[0] == dt.date(2025, 2, 1) and d1[-1] == dt.date(2025, 12, 31) and len(d1) == 334
vals = [c1.cell(2, 2+k).value for k in range(N)]
assert abs(sum(vals) - c1.cell(2, 146).value) < 0.01   # 首日144列之和=全天购电量列
d2 = [c2.cell(r, 1).value for r in range(2, 2006) if c2.cell(r, 1).value is not None]
assert len(d2) == 334, len(d2)                          # 充放电表恰好334个日期锚点
d3 = [c3.cell(r, 1).value for r in range(2, 1004) if c3.cell(r, 1).value is not None]
assert len(d3) == 334, len(d3)
em = [c3.cell(r, c).value for r in range(2, 1004) for c in (2, 3)
      if c3.cell(r, c).value not in (None, '')]
assert em == [], em[:5]                                # 紧急购电时段/电量必须全空
for ws in (c1, c2, c3):
    for row in ws.iter_rows(values_only=True):
        assert '⁝' not in row, '仍残留省略行'          # 不允许模板省略符残留
print('\n回读校验通过：计划购电量 334 天 / 充放电量 2004 行 / 紧急购电量 334 天全空 / 无省略符')
