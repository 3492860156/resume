# -*- coding: utf-8 -*-
"""金标准（层3）：独立重解365天LP（仅内存，不写文件），逐格比对 result2.xlsx。
与主求解器 solve_q2_fresh.py 完全独立地再写一遍模型，若两份结果逐格一致，
即可排除“写出环节/口径拼接”错误，证明结果文件确实是该LP的最优解。"""
import os, sys, io, datetime
import numpy as np, pandas as pd, openpyxl
from scipy.optimize import linprog
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')
XLSX = os.path.join(ROOT, '问题二', 'result2.xlsx')
H, ETA, P_MAX = 1/6, 0.9, 5000.0
E_MAX = P_MAX*H                              # 单区间充/放上界
S_MIN, S_MAX, S_INIT = 1200.0, 10800.0, 6000.0
N, EMULT = 144, 5.0

# 读取电价（结束时刻口径循环移位）与全年负载/光伏功率矩阵
att1 = pd.read_excel(ATT1)
price_raw = att1['电价'].to_numpy(float)
price_day = np.concatenate([price_raw[1:], price_raw[:1]])
load_mat = pd.read_excel(ATT2, sheet_name='小区负载').iloc[:, 1:].to_numpy(float)
pv_mat = pd.read_excel(ATT2, sheet_name='光伏发电实际功率').iloc[:, 1:].to_numpy(float)

def day_vector(mat, d):
    """跨天日向量：k=0..142取当天1:144列，k=143取下一天第0列（年末退回本列）。"""
    v = np.empty(N); v[:N-1] = mat[d, 1:N]
    v[N-1] = mat[d+1, 0] if d+1 < 365 else mat[d, N-1]
    return v

def solve_day(load_kW, pv_kW, price, s_init):
    """独立实现的单日LP（含紧急购电e）。s_init 为当日0:00初始SOC（由前一日末滚动传入）。"""
    L = load_kW*H; PV = pv_kW*H
    nv = 5*N + N+1                           # x,c,d,u,e 各144 + S 145
    off = {'x':0,'c':N,'d':2*N,'u':3*N,'e':4*N,'S':5*N}
    vid = lambda i,k: off[k]+i
    obj = np.zeros(nv)
    obj[off['x']:off['x']+N] = price         # 购电单价 p
    obj[off['e']:off['e']+N] = EMULT*price   # 紧急购电单价 5p
    A = np.zeros((2*N, nv)); b = np.zeros(2*N)
    for i in range(N):
        # 母线平衡 x+u+ηd+e−c = L
        A[i,vid(i,'x')]=1; A[i,vid(i,'u')]=1; A[i,vid(i,'d')]=ETA
        A[i,vid(i,'e')]=1; A[i,vid(i,'c')]=-1; b[i]=L[i]
        # 储能递推 S_{i+1}−S_i−ηc+d = 0
        A[N+i,vid(i+1,'S')]=1; A[N+i,vid(i,'S')]=-1
        A[N+i,vid(i,'c')]=-ETA; A[N+i,vid(i,'d')]=1
    bounds = [(0.0,None)]*nv
    for i in range(N):
        bounds[vid(i,'c')]=(0,E_MAX); bounds[vid(i,'d')]=(0,E_MAX)
        bounds[vid(i,'u')]=(0,PV[i])
    for i in range(N+1): bounds[vid(i,'S')]=(S_MIN,S_MAX)
    bounds[vid(0,'S')]=(s_init,s_init)       # 当日S0固定为滚动传入值
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success: raise RuntimeError(res.message)
    g = lambda k: res.x[off[k]:off[k]+N]
    return g('x'), g('c'), g('d'), g('u'), g('e'), res.x[off['S']:off['S']+N+1]

# ---- 逐日滚动重解365天（1月预热不输出，仅用于把SOC滚动到2/1），同时统计违规 ----
recs = []
s_init = S_INIT
viol = {'soc':0,'pwr':0,'em':0.0,'bal':0.0,'rec':0.0}
for d in range(365):
    X,C,D,U,E,S = solve_day(day_vector(load_mat,d), day_vector(pv_mat,d), price_day, s_init)
    viol['soc'] += int(((S<S_MIN-1e-6)|(S>S_MAX+1e-6)).sum())       # SOC越界计数
    viol['pwr'] += int((C>E_MAX+1e-6).sum()+(D>E_MAX+1e-6).sum())   # 功率越界计数
    viol['em'] += float(E.sum())                                    # 紧急购电总量（应≈0）
    viol['bal'] = max(viol['bal'], float(np.abs(X+U+ETA*D+E-C-day_vector(load_mat,d)*H).max()))  # 平衡残差
    viol['rec'] = max(viol['rec'], float(np.abs(S[1:]-S[:-1]-ETA*C+D).max()))                     # 递推残差
    recs.append((X,C,D,S))
    s_init = float(S[N])                        # 日末SOC → 次日S0，实现时间滚动
print('独立重解365天完成: SOC越界%d 功率越界%d 紧急购电%.2e 平衡残差%.1e 递推残差%.1e'
      % (viol['soc'],viol['pwr'],viol['em'],viol['bal'],viol['rec']))

# ---- 与 xlsx 逐格比对（输出区间 2.1-12.31 = recs[31:]）----
wb = openpyxl.load_workbook(XLSX, read_only=True, data_only=True)
ws1 = wb['计划购电量']; ws2 = wb['充放电量']
rows1 = [r for r in ws1.iter_rows(values_only=True)][1:]
rows2 = [r for r in ws2.iter_rows(values_only=True)][1:]
# 六个4小时块对应的区间下标（块1=0..22，块2=23..46，…；143区间归次日块1）
BLOCK_K = [(list(range(0,23)),),(list(range(23,47)),),(list(range(47,71)),),
           (list(range(71,95)),),(list(range(95,119)),),(list(range(119,143)),)]
max_x = max_cost = max_blk_c = max_blk_d = max_soc = 0.0
tot_cost_check = 0.0
for m in range(334):
    d = 31+m                                  # 输出第m天对应全年第d天（前31天为1月预热）
    X,C,D,S = recs[d]
    pX,pC,pD,pS = recs[d-1]                   # 前一天（块1跨天口径需要其143区间）
    r1 = rows1[m]
    for k in range(N):                        # 144个区间购电量逐格比对
        max_x = max(max_x, abs(round(float(X[k]),4) - (r1[1+k] or 0)))
    cost = float((price_day*X).sum())         # 当日购电费
    tot_cost_check += cost
    max_cost = max(max_cost, abs(round(cost,2) - r1[-1]))   # 与表末全天费用列比对
    for bi in range(6):
        ks = BLOCK_K[bi][0]
        c = float(C[ks].sum()); dis = float(D[ks].sum())
        if bi == 0:                           # 块1还要加上前一日143区间
            c += float(pC[143]); dis += float(pD[143])
        rr = rows2[6*m+bi]
        max_blk_c = max(max_blk_c, abs(round(c,4) - (rr[2] or 0)))
        max_blk_d = max(max_blk_d, abs(round(dis,4) - (rr[3] or 0)))
    # s0=前日S143、s24=当日S143，与表内时刻行比对
    rr0, rr1 = rows2[6*m], rows2[6*m+1]
    s0 = float(pS[143]); s24 = float(S[143])
    max_soc = max(max_soc, abs(round(s0,4)-rr0[5]), abs(round(s24,4)-rr1[5]))
print('\n逐格比对（重解 vs xlsx）:')
print('  计划购电量单格最大偏差 %.2e kWh' % max_x)
print('  全天购电费最大偏差 %.2e 元' % max_cost)
print('  块充电量最大偏差 %.2e | 块放电量最大偏差 %.2e kWh' % (max_blk_c, max_blk_d))
print('  0:00/24:00储电量最大偏差 %.2e kWh' % max_soc)
print('  重算输出区间总购电费 %.2f 元（表内合计 %.2f 元）' % (tot_cost_check, sum(r[-1] for r in rows1)))
wb.close()
