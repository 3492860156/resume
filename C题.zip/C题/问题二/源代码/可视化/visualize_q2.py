# -*- coding: utf-8 -*-
"""
问题2 计划购电策略可视化（保存 PNG，可直接插入论文）
==================================================================
数据来源：
  - q2_fresh_results.json （solve_q2_fresh.py 生成：电价、全年逐日结果、4 个指定日完整解）
  - 附件2.xlsx（指定日负载/光伏曲线）
  - result2.xlsx（读取前一日行末区间购电量，用于拼出自然日 [0:00,24:00) 曲线）

输出（问题二/可视化/ 目录，matplotlib 200dpi PNG）：
  1. 问题2_电价曲线.png        全天电价曲线 + 峰/谷标注
  2. 问题2_四指定日购电策略.png  4 个指定日期：购电量柱 + 储电量线 + 电价线（双轴，同问题1风格）
  3. 问题2_四指定日负载与光伏.png 4 个指定日期：负载 / 光伏实际功率
  4. 问题2_全年购电统计.png    334 天逐日购电费（柱）+ 购电量（线，双轴）
  5. 问题2_储能效益对照.png    月度购电费：无储能基准 vs 本策略（含储能）

依赖：numpy / pandas / openpyxl / matplotlib
"""
import os
import json
import datetime as dt

import numpy as np
import pandas as pd
import openpyxl
import matplotlib
matplotlib.use('Agg')                 # 无显示环境，直接存文件
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
JSON_PATH = os.path.join(ROOT, '问题二', '数据', 'q2_fresh_results.json')
XLSX_PATH = os.path.join(ROOT, '问题二', 'result2.xlsx')
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')
OUTDIR = os.path.join(ROOT, '问题二', '可视化')
os.makedirs(OUTDIR, exist_ok=True)

C_BUY, C_STORE, C_PRICE = '#A8C5E0', '#6C8EBF', '#E2A76F'   # 统一配色
FOCUS = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']   # 春分/夏至/秋分/冬至

# ---------------- 读取数据 ----------------
j = json.load(open(JSON_PATH, encoding='utf-8'))
price_day = np.array(j['price_day'])                 # 模板列序电价（结束时刻口径）
daily = j['daily']                                   # 365 天逐日标量
focus = j['focus_full']                              # 4 个指定日完整解
# 模板列序还原为自然日序：把第143个(次日0:00-0:10)挪到最前，得到 0:10..0:00+1
price_raw = np.concatenate([price_day[143:], price_day[:143]])

load_mat = pd.read_excel(ATT2, sheet_name='小区负载').iloc[:, 1:].to_numpy(float)
pv_mat   = pd.read_excel(ATT2, sheet_name='光伏发电实际功率').iloc[:, 1:].to_numpy(float)
dates_all = pd.to_datetime(pd.read_excel(ATT2, sheet_name='小区负载').iloc[:, 0]).dt.date
d_index = {str(d): i for i, d in enumerate(dates_all)}     # 日期字符串→全年行号

def day_vector(mat, d):
    """模板列序日向量：k=0..142 取当日列 k+1；k=143 取次日 0:10 列（与求解脚本一致）。"""
    v = np.empty(144)
    v[:143] = mat[d, 1:144]
    v[143] = mat[d+1, 0] if d+1 < 365 else mat[d, 143]
    return v

wb = openpyxl.load_workbook(XLSX_PATH, data_only=True)
ws_plan = wb['计划购电量']                            # 行 2..335 = 2025-02-01..12-31
row_of = {}                                          # 日期→xlsx行号
for r in range(2, ws_plan.max_row + 1):
    row_of[str(ws_plan.cell(r, 1).value.date())] = r

def day_of(fdate):
    """返回自然日 [0:00,24:00) 的 144 区间数组（购电/负载/光伏/电价）与储电边界。
    关键点：自然日首个区间[0:00,0:10)在模板里属于“前一日的最后一列”，需从前一日行取。"""
    d = d_index[fdate]
    X = np.empty(144)
    if d > 0:
        X[0] = ws_plan.cell(row_of[str(dates_all[d-1])], 145).value  # 前一日行末 [0:00,0:10)
    else:
        X[0] = 0.0
    X[1:] = np.array(focus[fdate]['X'])[:143]        # 当日0:10..24:00共143个区间
    # S：0:00取daily记录的s0，其后取focus的前144个状态点
    S = np.concatenate([[daily[d_index[fdate]]['s0']], np.array(focus[fdate]['S'])[:144]])
    return X, S, load_mat[d].copy(), pv_mat[d].copy(), price_raw

# ---------------- 图1：电价曲线（标注峰、谷时刻） ----------------
fig, ax = plt.subplots(figsize=(13, 5.2), dpi=200)
x = np.arange(144) * 10 / 60.0 + 1/6            # 结束时刻 0:10..24:00
ax.plot(x, price_raw, color=C_PRICE, linewidth=2.2)
ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 2))
ax.set_xticklabels(['%02d:00' % h for h in range(0, 25, 2)])
ax.set_xlabel('时间', fontsize=12); ax.set_ylabel('电价 (元/kWh)', fontsize=12)
ax.grid(axis='y', linestyle='--', alpha=0.4); ax.tick_params(labelsize=11)
imax, imin = int(price_raw.argmax()), int(price_raw.argmin())
ax.annotate('峰  %.4f 元/kWh @ %02d:%02d' % (price_raw[imax], (imax+1)*10//60, (imax+1)*10%60),
            xy=(x[imax], price_raw[imax]), xytext=(x[imax]-3.2, price_raw[imax]+0.08),
            fontsize=11, color='#B26A2E',
            arrowprops=dict(arrowstyle='->', color='#B26A2E'))
ax.annotate('谷  %.4f 元/kWh @ %02d:%02d' % (price_raw[imin], (imin+1)*10//60, (imin+1)*10%60),
            xy=(x[imin], price_raw[imin]), xytext=(x[imin]-0.4, price_raw[imin]-0.14),
            fontsize=11, color='#4A7A4A',
            arrowprops=dict(arrowstyle='->', color='#4A7A4A'))
ax.set_title('问题2 电价曲线（附件1，每天相同；峰谷价差 %.3f 元/kWh）' % (price_raw.max()-price_raw.min()),
             fontsize=14, pad=10)
fig.tight_layout(); fig.savefig(os.path.join(OUTDIR, '问题2_电价曲线.png'), bbox_inches='tight'); plt.close(fig)
print('已保存: 问题2_电价曲线.png')

# ---------------- 图2：四指定日购电策略（2×2，购电柱+储电线 左轴，电价线 右轴） ----------------
fig, axes = plt.subplots(2, 2, figsize=(15, 10), dpi=200)
for ax, fdate in zip(axes.flat, FOCUS):
    X, S, _, _, pr = day_of(fdate)
    ax.bar(x, X, width=(1/6)*0.78, color=C_BUY, label='购电量(kWh/10min)', edgecolor='none')
    ax.plot(x, S[:144], color=C_STORE, linewidth=2.0, label='储能设备电量(kWh)')
    ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 4))
    ax.set_xticklabels(['%02d:00' % h for h in range(0, 25, 4)])
    ax.set_ylim(0, 12500)
    ax.tick_params(labelsize=10); ax.grid(axis='y', linestyle='--', alpha=0.4)
    ax2 = ax.twinx()
    ax2.plot(x, pr, color=C_PRICE, linewidth=2.0, label='电价(元/kWh)')
    ax2.set_ylim(0, 1.6); ax2.tick_params(axis='y', labelcolor='#B26A2E', labelsize=10)
    r = daily[d_index[fdate]]
    ax.set_title('%s ｜ 购电 %.0f kWh ｜ 购电费 %.0f 元' % (fdate, r['buy'], r['cost_plan']+r['cost_em']),
                 fontsize=13, pad=8)
    if ax in (axes[0, 0],):                        # 只在左上子图放图例，避免重复
        h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1+h2, l1+l2, loc='upper left', fontsize=10, framealpha=0.9)
fig.suptitle('问题2 四个指定日期的计划购电策略（购电+储能+电价）', fontsize=15, y=0.99)
fig.tight_layout(rect=[0, 0, 1, 0.97])
fig.savefig(os.path.join(OUTDIR, '问题2_四指定日购电策略.png'), bbox_inches='tight'); plt.close(fig)
print('已保存: 问题2_四指定日购电策略.png')

# ---------------- 图3：四指定日负载与光伏（光伏≥负载区间填色表示盈余） ----------------
fig, axes = plt.subplots(2, 2, figsize=(15, 9), dpi=200)
for ax, fdate in zip(axes.flat, FOCUS):
    _, _, L, P, _ = day_of(fdate)
    ax.plot(x, L, color='#6C8EBF', linewidth=2.0, label='小区负载(kW)')
    ax.plot(x, P, color='#E2A76F', linewidth=2.0, label='光伏实际功率(kW)')
    ax.fill_between(x, L, P, where=(P >= L), color='#A8C5E0', alpha=0.35, label='光伏盈余时段')
    ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 4))
    ax.set_xticklabels(['%02d:00' % h for h in range(0, 25, 4)])
    ax.tick_params(labelsize=10); ax.grid(axis='y', linestyle='--', alpha=0.4)
    ax.set_title(fdate, fontsize=13, pad=8)
    if ax in (axes[0, 0],):
        ax.legend(loc='upper left', fontsize=10, framealpha=0.9)
fig.suptitle('问题2 四个指定日期的小区负载与光伏实际功率（附件2）', fontsize=15, y=0.99)
fig.tight_layout(rect=[0, 0, 1, 0.97])
fig.savefig(os.path.join(OUTDIR, '问题2_四指定日负载与光伏.png'), bbox_inches='tight'); plt.close(fig)
print('已保存: 问题2_四指定日负载与光伏.png')

# ---------------- 图4：全年逐日购电统计（柱=费用 左轴，线=电量 右轴） ----------------
out = [r for r in daily if r['date'] >= '2025-02-01']     # 输出区间334天
dates = [dt.date.fromisoformat(r['date']) for r in out]
xd = np.arange(len(out))
cost = np.array([r['cost_plan'] + r['cost_em'] for r in out])
buy  = np.array([r['buy'] for r in out])
fig, ax1 = plt.subplots(figsize=(13, 5.4), dpi=200)
ax1.bar(xd, cost, width=0.8, color=C_BUY, label='每日购电费(元)')
ax1.set_xlabel('日期', fontsize=12); ax1.set_ylabel('购电费 (元)', fontsize=12)
ax1.set_xticks(range(0, len(out), 30))
ax1.set_xticklabels([dates[i].strftime('%m-%d') for i in range(0, len(out), 30)], fontsize=10)
ax1.grid(axis='y', linestyle='--', alpha=0.4); ax1.tick_params(labelsize=11)
ax2 = ax1.twinx()
ax2.plot(xd, buy/1000.0, color='#6C8EBF', linewidth=1.6, label='每日购电量(千kWh)')
ax2.set_ylabel('购电量 (千kWh)', fontsize=12, color='#4A6A9A'); ax2.tick_params(axis='y', labelcolor='#4A6A9A')
h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1+h2, l1+l2, loc='upper left', fontsize=11, framealpha=0.9)
ax1.set_title('问题2 2025.2.1–12.31 逐日购电费与购电量（总购电费 %.0f 元，总购电量 %.0f kWh）'
              % (cost.sum(), buy.sum()), fontsize=13, pad=10)
fig.tight_layout(); fig.savefig(os.path.join(OUTDIR, '问题2_全年购电统计.png'), bbox_inches='tight'); plt.close(fig)
print('已保存: 问题2_全年购电统计.png')

# ---------------- 图5：储能效益对照（月度：无储能基准 vs 本策略） ----------------
H = 1/6
months = ['2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
base_m, mine_m = [], []
for mi, m in enumerate(range(2, 13)):
    base_c = mine_c = 0.0
    for r in out:
        if dt.date.fromisoformat(r['date']).month != m:
            continue
        mine_c += r['cost_plan'] + r['cost_em']          # 本策略（含储能套利）
        d = d_index[r['date']]
        L = day_vector(load_mat, d) * H                  # 当日负载电量
        P = day_vector(pv_mat, d) * H                    # 当日光伏电量
        base_c += float((price_day * np.maximum(L - P, 0)).sum())  # 无储能：缺口按时价直购
    base_m.append(base_c / 1e4); mine_m.append(mine_c / 1e4)       # 换算万元
x = np.arange(len(months)); w = 0.36
fig, ax = plt.subplots(figsize=(13, 5.6), dpi=200)
b1 = ax.bar(x - w/2, base_m, w, color='#D9C9A3', label='无储能基准购电费(万元)')
b2 = ax.bar(x + w/2, mine_m, w, color=C_BUY, label='本策略购电费(万元，含储能)')
for b in list(b1) + list(b2):
    ax.text(b.get_x() + b.get_width()/2, b.get_height() + 60, '%.0f' % b.get_height(),
            ha='center', fontsize=8.5, color='#555555')
ax.set_xticks(x); ax.set_xticklabels(months, fontsize=11)
ax.set_ylabel('购电费 (万元)', fontsize=12)
ax.grid(axis='y', linestyle='--', alpha=0.4); ax.tick_params(labelsize=11)
ax.legend(fontsize=11, framealpha=0.9)
tot_base = sum(base_m); tot_mine = sum(mine_m)
ax.set_title('问题2 储能套利效益（2025.2–12 月度购电费；合计节约 %.0f 万元 = %.1f%%）'
             % (tot_base - tot_mine, 100*(tot_base - tot_mine)/tot_base), fontsize=13, pad=10)
fig.tight_layout(); fig.savefig(os.path.join(OUTDIR, '问题2_储能效益对照.png'), bbox_inches='tight'); plt.close(fig)
print('已保存: 问题2_储能效益对照.png')

print('\n全部可视化图片已保存到:', OUTDIR)
