# -*- coding: utf-8 -*-
"""
问题二/三/四 解题流程图（与问题一参考图同一视觉体系：纵向六步、圆角框、暖色→蓝绿）
重点：建模框写清目标函数，并显式体现紧急购电量 e 的费用系数(5倍)与触发关系。
"""
import sys, io, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

# 与问题一参考图成套的配色（填充, 边框, 标题字色, 正文字色）
PALETTE = [
    ('#F8CBAD', '#E08A5E', '#7A3E1D', '#5E3A22'),
    ('#FDE9A8', '#E6C85C', '#7A5A12', '#5C4A1E'),
    ('#FBD783', '#E8B341', '#7A4E0A', '#573D12'),
    ('#B4CDE8', '#6E97C9', '#1F3E63', '#243B56'),
    ('#A9D18E', '#6FAE5B', '#27541A', '#234A19'),
    ('#5B7FC4', '#3F5FA0', '#FFFFFF', '#EAF0FB'),
]


def draw_flow(steps, outpath, fig_h=12.6):
    """steps: [(标题, [正文行...])] 共6步，纵向排列。"""
    fig, ax = plt.subplots(figsize=(12.2, fig_h), dpi=200)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis('off')
    n = len(steps)
    top, bottom = 98.0, 1.5
    gap = (top - bottom) / n
    # 按正文行数给框高：行数越多框越高，保证文字不贴边、箭头不穿字
    h_by_lines = {1: 0.62, 2: 0.78, 3: 0.85}
    box_hs = [gap * h_by_lines[len(lines)] for _, lines in steps]
    for k, (title, lines) in enumerate(steps):
        yc = top - gap * (k + 0.5)
        box_h = box_hs[k]
        fill, edge, tcol, bcol = PALETTE[k]
        x0, w = 7.0, 86.0
        box = FancyBboxPatch((x0, yc - box_h / 2), w, box_h,
                             boxstyle='round,pad=0.6,rounding_size=1.6',
                             linewidth=1.6, edgecolor=edge, facecolor=fill,
                             mutation_aspect=0.62)
        ax.add_patch(box)
        nlines = len(lines)
        # 标题
        ty = yc + box_h * (0.30 if nlines == 3 else 0.27)
        ax.text(50, ty, title, ha='center', va='center', fontsize=14.5,
                fontweight='bold', color=tcol)
        # 正文 1~3 行（相对框中心均匀分布于标题下方）
        if nlines == 1:
            ys = [yc - box_h * 0.17]
        elif nlines == 2:
            ys = [yc - box_h * 0.12, yc - box_h * 0.37]
        else:
            ys = [yc - box_h * 0.05, yc - box_h * 0.255, yc - box_h * 0.46]
        for ly, txt in zip(ys, lines):
            ax.text(50, ly, txt, ha='center', va='center', fontsize=10.6,
                    color=bcol, linespacing=1.3)
        # 箭头：从上一框底边到下一框顶边
        if k < n - 1:
            y_bottom = yc - box_h / 2
            y_next_top = (top - gap * (k + 1.5)) + box_hs[k + 1] / 2
            arr = FancyArrowPatch((50, y_bottom - 0.15),
                                  (50, y_next_top + 0.15),
                                  arrowstyle='-|>', mutation_scale=20,
                                  linewidth=2.2, color='#4A4A4A')
            ax.add_patch(arr)
    plt.subplots_adjust(left=0.01, right=0.99, top=0.995, bottom=0.005)
    fig.savefig(outpath, dpi=200, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print('saved', outpath)


# =============== 问题二 ===============
q2 = [
    ('① 输入数据（附件1电价 + 附件2全年实际负载与光伏）',
     ['全年365天×144个10分钟区间；负载、光伏逐日不同（全信息、日前已知），日电价向量每天重复']),
    ('② 数据预处理与跨天衔接',
     ['功率×(1/6 h)换算为电量(kWh)；结束时刻口径循环移位对齐；当日24:00储电量直接作为次日0:00初值，1月为预热期']),
    ('③ 建立逐日滚动线性规划模型（单日LP）',
     ['决策变量：购电量 $x$、充电 $c$、放电 $d$、光伏利用 $u$、紧急购电 $e$、储电量 $S$',
      r'目标：购电费最小  $min\ \sum p_i(x_i+5e_i)$——正常购电1倍电价、紧急购电5倍电价',
      r'约束：母线平衡 $x+u+0.9d+e-c=L$；递推 $S_{i+1}=S_i+0.9c_i-d_i$；储电1200~10800、单段充放≤833.33kWh']),
    ('④ 逐日滚动求解（HiGHS全局最优）',
     ['每天0:00以继承的储电量为初值解当日LP，365天按储电状态链式递推；凸LP保证全局最优、可复现']),
    ('⑤ 输出结果（result2.xlsx）',
     ['334天逐日144段购电与充放电策略、储电轨迹；全年购电费1226.22万元、购电量2018.93万kWh']),
    ('⑥ 结果分析与校验',
     [r'全信息下正常购电+储能放电总可覆盖负载，5倍价的紧急购电严格更贵，故最优解 $e_i\equiv0$、全年紧急购电为0',
      '三层独立校验全部通过；逐日滚动较全年全局LP仅高0.237%；储能相对无储能直购节约25.26%']),
]

# =============== 问题三 ===============
q3 = [
    ('① 输入数据（附件1电价 + 附件2实测 + 附件3光伏预报）',
     ['每天仅0:00/6:00/12:00/18:00四次获得未来光伏预报，实际出力事后才知，电价仍为固定日向量']),
    ('② 数据预处理',
     ['整点小时预报零阶保持展开到144个10分钟段（不插值以保持无偏）；严格对齐“第k小时”口径；跨午夜拼接与预热']),
    ('③ 0:00全天计划LP',
     [r'以0点光伏预报 $PV^{(0)}$ 为光伏上限，解 $min\ \sum p_i(x_i+5e_i)$，约束同问题二，得到上报的全天计划购电曲线 $x_i$']),
    ('④ 6/12/18点滚动调整LP（核心）',
     [r'新增上调 $up$、下调 $dn$，偏差等式 $g_i=x_i+up_i-dn_i$（$g$ 为最终购电量）',
      r'增量目标 $min\ \sum p_i(1.5\,up_i-0.5\,dn_i+5e_i)$：多买1.5倍、少买退0.5倍、缺口5倍紧急',
      '因 0.5P<P<1.5P<5P，总以1.5倍可控上调替代5倍紧急购电；已执行段冻结，仅重优化剩余窗口']),
    ('⑤ 实际核验、结算与输出（result3.xlsx）',
     [r'用实测光伏逐段核验，缺口 $E^*=max(L+c-g-0.9d-PV,0)$ 触发5倍紧急购电；总费用 $F$=购电侧结算+$5\sum p_iE^*$=1591.05万元']),
    ('⑥ 结果分析',
     ['全年紧急购电76.06万kWh、全部源于光伏预报误差且集中在5—18时光伏段、夜间为0',
      '滚动调整共省51.28万元、紧急量降20.8%；LP与MILP目标差1.7e-16，纯线性规划无损']),
]

# =============== 问题四 ===============
q4 = [
    ('① 输入数据（附件4实时波动电价 + 附件1/2/3）',
     ['附件4为365×144实时电价矩阵，逐段不同、逐日不同；0:00做计划时看不到当日尚未发生的价格']),
    ('② 电价结构分解与因果预测',
     [r'分解 $P(d,t)=g(t)\cdot a(d)\cdot\varepsilon(d,t)$：典型形状g(附件1)×当日水平因子a×随机毛刺；剔除毛刺，按周周期(lag7)预测决策价 $\hat P=\hat a\cdot g$，只用历史数据']),
    ('③ 双价格框架建模（物理内核不变）',
     ['母线平衡、储能递推与容量功率约束与问题二、三完全相同，只把目标中的已知电价换成预测价',
      r'决策目标 $min\ \sum \hat P_i(x_i+5e_i)$：用预测价排序定策略；紧急购电关系不变，缺口仍按当时真实电价5倍计']),
    ('④ 双滚动求解（HiGHS）',
     [r'4-2重算问题二：负载光伏全信息、0点一次LP，$e\equiv0$；4-3重算问题三：光伏+电价双滚动，$up/dn$ 调整同问题三']),
    ('⑤ 实际价结算与输出（result4-2 / result4-3）',
     ['决策一律用预测价、结算一律用附件4真实价P；全年费用分别为1297.36万元、1671.31万元']),
    ('⑥ 结果分析与一致性校验',
     ['fixed情景精确复现问题二（相对差1.5e-7）；电价预测价值仅0.19万元、光伏不确定性代价为其5倍以上',
      '储能套利价值405.33万元依旧主导；电价误差只使套利时机次优、不造成物理缺电，e仅由光伏误差触发']),
]

OUT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
targets = [
    (q2, os.path.join(OUT, r'问题二\可视化\问题2_解题流程图.png'), 12.6),
    (q3, os.path.join(OUT, r'问题三\可视化\问题3_解题流程图.png'), 13.4),
    (q4, os.path.join(OUT, r'问题四\可视化\问题4_解题流程图.png'), 13.4),
]
for steps, path, h in targets:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    draw_flow(steps, path, h)
print('ALL DONE')
