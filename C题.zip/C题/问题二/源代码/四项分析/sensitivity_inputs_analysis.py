# -*- coding: utf-8 -*-
"""
问题2 敏感性分析（输入侧实际参数版）
=====================================================================
选取模型中实际存在的三类输入参数做扰动，每场景全年 365 个 LP 重新滚动求解：
  1) 购电价格系数 a：整条电价曲线等比缩放（±5%、±10%），水平 [0.90,0.95,1,1.05,1.10]
  2) 光伏发电率系数 b：附件2 光伏实际功率整体缩放（±10%、±20%），[0.80,0.90,1,1.10,1.20]
  3) 小区用电量系数 g：附件2 负载功率整体缩放（±5%、±10%），[0.90,0.95,1,1.05,1.10]
观测输出：全年总购电费、总购电量、紧急购电、弃光量/率、储能节约率，以及相对基线的变化率、
         弧弹性（费用变化率/参数扰动率）。基线解直接复用 cache_baseline.npz。
输出：
  sensitivity_inputs_results.json
  可视化/问题2_敏感输入_龙卷风图.png
  可视化/问题2_敏感输入_响应曲线.png
  可视化/问题2_敏感输入_弹性斜率.png
"""
import os, sys, json, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.append(os.path.dirname(__file__))
from q2_common import (load_inputs, solve_year, summarize, get_baseline,
                      FIGDIR, OUT_SLICE)

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

ANADIR = os.path.dirname(__file__)
inp = load_inputs()
p0 = inp['price_day']

# 三个输入参数 × 5 水平（中间 1.0 即基线）
LEVELS = {
    '购电价格系数': [0.90, 0.95, 1.00, 1.05, 1.10],
    '光伏发电率系数': [0.80, 0.90, 1.00, 1.10, 1.20],
    '小区用电量系数': [0.90, 0.95, 1.00, 1.05, 1.10],
}
COLORS = {'购电价格系数': '#9BBBF4', '光伏发电率系数': '#A2DDAA', '小区用电量系数': '#E8A09A'}

# ---------- 基线（复用缓存，不重解） ----------
base_sol = get_baseline()
base_m = summarize(base_sol)
print('基线: 购电费 %.2f 元 | 购电量 %.1f kWh | 节约率 %.2f%%'
      % (base_m['cost'], base_m['buy'], 100*base_m['save_rate']))

def run_one(param, f):
    """按参数与扰动系数重解全年（系数1.0直接返回基线缓存）。"""
    if abs(f - 1.0) < 1e-12:
        sol = base_sol
    elif param == '购电价格系数':
        sol = solve_year(price=p0 * f)
    elif param == '光伏发电率系数':
        sol = solve_year(pv_scale=float(f))
    elif param == '小区用电量系数':
        sol = solve_year(load_scale=float(f))
    else:
        raise KeyError(param)
    m = summarize(sol)
    # 派生指标
    m['curtail'] = m['pv_avail'] - m['pv_used']                       # 弃光量
    m['curtail_rate'] = m['curtail'] / m['pv_avail'] if m['pv_avail'] > 0 else 0.0
    m['cost_pct'] = (m['cost'] / base_m['cost'] - 1) * 100            # 费用变化率%
    m['buy_pct'] = (m['buy'] / base_m['buy'] - 1) * 100               # 购电量变化率%
    m['perturb_pct'] = (f - 1) * 100                                  # 参数扰动率%
    m['arc_elasticity'] = (m['cost_pct'] / m['perturb_pct']) if abs(f-1) > 1e-12 else 1.0
    return {k: (round(float(v), 6) if isinstance(v, (int, float, np.floating)) else v)
            for k, v in m.items()}

# ---------- 逐场景重解 ----------
results = {}
t0 = time.time()
for pi, (param, levels) in enumerate(LEVELS.items()):
    results[param] = {}
    for f in levels:
        results[param][str(f)] = run_one(param, f)
        mm = results[param][str(f)]
        print('[%d/3] %s=%.2f  费用 %.1f 万 (%+.2f%%)  购电量 %.1f 万kWh (%+.2f%%)  弹性 %.3f'
              % (pi+1, param, f, mm['cost']/1e4, mm['cost_pct'],
                 mm['buy']/1e4, mm['buy_pct'], mm['arc_elasticity']), flush=True)
print('全部场景耗时 %.1fs' % (time.time()-t0))

json.dump({'baseline': {k: round(float(v), 6) if isinstance(v, (int, float, np.floating)) else v
                        for k, v in base_m.items()},
           'scenarios': results},
          open(os.path.join(ANADIR, '..', '..', '数据', 'sensitivity_inputs_results.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

params = list(LEVELS.keys())

# ---------- 图1：龙卷风图（最低/最高水平相对基线的费用变化率） ----------
lo_pct, hi_pct, lo_lab, hi_lab = [], [], [], []
for param in params:
    levels = LEVELS[param]
    lo_pct.append(results[param][str(levels[0])]['cost_pct'])
    hi_pct.append(results[param][str(levels[-1])]['cost_pct'])
    lo_lab.append('%.2f' % levels[0]); hi_lab.append('%.2f' % levels[-1])
order = np.argsort([max(abs(a), abs(b)) for a, b in zip(lo_pct, hi_pct)])
params_o = [params[i] for i in order]
lo = [lo_pct[i] for i in order]; hi = [hi_pct[i] for i in order]
ll = [lo_lab[i] for i in order]; hl = [hi_lab[i] for i in order]
y = np.arange(len(params_o))
fig, ax = plt.subplots(figsize=(12, 4.8), dpi=200)
ax.barh(y-0.2, lo, 0.4, color='#9BBBF4', label='低端水平')
ax.barh(y+0.2, hi, 0.4, color='#E8A09A', label='高端水平')
for i in range(len(y)):
    ax.text(lo[i], y[i]-0.2, '%+.2f%% (系数%s)' % (lo[i], ll[i]),
            ha='right' if lo[i] < 0 else 'left', va='center', fontsize=10)
    ax.text(hi[i], y[i]+0.2, '%+.2f%% (系数%s)' % (hi[i], hl[i]),
            ha='left' if hi[i] > 0 else 'right', va='center', fontsize=10)
ax.axvline(0, color='#333', lw=1)
ax.set_yticks(y); ax.set_yticklabels(params_o, fontsize=11.5)
ax.set_xlabel('全年总购电费相对基线的变化率 (%)', fontsize=12)
ax.set_title('问题2 输入参数敏感性①：购电价格/光伏/负载两端扰动对总购电费的影响（基线 1226.22 万元）', fontsize=12.5)
ax.grid(axis='x', ls='--', alpha=0.4); ax.legend(fontsize=11, loc='lower right')
lim = max(abs(np.array(lo+hi)).max()*1.6, 1)
ax.set_xlim(-lim, lim)
fig.tight_layout()
p = os.path.join(FIGDIR, '问题2_敏感输入_龙卷风图.png')
fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图2：1×3 响应曲线（左轴购电费万元实线，右轴购电量万kWh虚线） ----------
fig, axes = plt.subplots(1, 3, figsize=(16.5, 4.6), dpi=200)
for ax, param in zip(axes, params):
    levels = LEVELS[param]
    costs = [results[param][str(f)]['cost']/1e4 for f in levels]
    buys  = [results[param][str(f)]['buy']/1e4 for f in levels]
    ax.plot(levels, costs, '-o', color='#6C8EBF', lw=2, label='总购电费(万元)')
    ax.axhline(base_m['cost']/1e4, color='#999', ls=':', lw=1)
    axb = ax.twinx()
    axb.plot(levels, buys, '--s', color='#E2A76F', ms=5, lw=1.6, label='总购电量(万kWh)')
    axb.axhline(base_m['buy']/1e4, color='#D8B98F', ls=':', lw=1)
    ax.set_title(param, fontsize=12)
    ax.set_xlabel('扰动系数（1.00=基线）', fontsize=10.5)
    ax.grid(ls='--', alpha=0.4)
    ax.tick_params(labelsize=9.5); axb.tick_params(labelsize=9.5)
    if ax is axes[0]:
        ax.set_ylabel('总购电费 (万元)', fontsize=10.5, color='#4A6A9A')
    if ax is axes[-1]:
        axb.set_ylabel('总购电量 (万kWh)', fontsize=10.5, color='#B26A2E')
fig.suptitle('问题2 输入参数敏感性②：三参数逐水平全年重解（实线=购电费，虚线=购电量）', fontsize=13)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题2_敏感输入_响应曲线.png')
fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图3：扰动率→费用变化率 弹性斜率对比 ----------
fig, ax = plt.subplots(figsize=(11, 5.2), dpi=200)
for param in params:
    xs = [results[param][str(f)]['perturb_pct'] for f in LEVELS[param]]
    ys = [results[param][str(f)]['cost_pct'] for f in LEVELS[param]]
    ax.plot(xs, ys, '-o', lw=2, color=COLORS[param], label=param)
    for x, y in zip(xs, ys):
        ax.annotate('%+.2f%%' % y, (x, y), textcoords='offset points', xytext=(0, 7),
                    ha='center', fontsize=8.5)
ax.plot([-20, 20], [-20, 20], ls=':', color='#999', lw=1.2, label='y=x（等比例线）')
ax.axhline(0, color='#333', lw=0.8); ax.axvline(0, color='#333', lw=0.8)
ax.set_xlabel('参数扰动幅度 (%)', fontsize=12)
ax.set_ylabel('全年总购电费变化率 (%)', fontsize=12)
ax.set_title('问题2 输入参数敏感性③：参数扰动率→购电费变化率响应（斜率≈弧弹性）', fontsize=12.5)
ax.grid(ls='--', alpha=0.4); ax.legend(fontsize=10.5)
fig.tight_layout()
p = os.path.join(FIGDIR, '问题2_敏感输入_弹性斜率.png')
fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 控制台打印汇总表 ----------
print('\n==== 汇总（费用单位:万元，电量:万kWh）====')
print('%-14s %-6s %-10s %-9s %-10s %-9s %-8s' % ('参数', '系数', '购电费', '费用变化%', '购电量', '电量变化%', '弃光率%'))
for param in params:
    for f in LEVELS[param]:
        m = results[param][str(f)]
        print('%-14s %-6.2f %-10.2f %+-9.2f %-10.2f %+-9.2f %-8.2f'
              % (param, f, m['cost']/1e4, m['cost_pct'], m['buy']/1e4, m['buy_pct'], 100*m['curtail_rate']))
print('\n输入侧敏感性分析完成。')
