# -*- coding: utf-8 -*-
"""
问题2 敏感性分析：5 个关键参数 × 5 水平，逐场景全年重解（365 LP/场景）
参数：储能总容量E、充放功率P、转换效率η、峰谷价差系数k、日初始电量S0
输出：
  sensitivity_results.json
  问题2_敏感_龙卷风图.png     各参数在两端水平时总购电费相对基线的变化
  问题2_敏感_参数曲线.png     各参数-总购电费/节约率曲线
"""
import os, sys, json, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(__file__))
from q2_common import (load_inputs, solve_year, summarize, ETA0, PMAX0,
                       SMIN0, SMAX0, SINIT0, FIGDIR, OUT_SLICE, DAYS)

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

inp = load_inputs()
p0 = inp['price_day']; pmean = p0.mean()    # 原始日电价与其日均值（用于价差缩放）

def metrics_of(sol, price_use):
    """给定一个全年解与计价电价，返回输出区间的购电费/购电量/无储能基准/节约率。"""
    sl = OUT_SLICE
    cost = float((price_use[None, :]*sol['X'][sl]).sum())
    buy = float(sol['X'][sl].sum())
    base = float((price_use[None, :]*np.maximum(sol['L'][sl]-sol['PV'][sl], 0)).sum())
    return dict(cost=cost, buy=buy, base=base, save_rate=(base-cost)/base)

# 五参数×五水平（中间水平即基线值）
LEVELS = {
    '储能总容量(kWh)': [8000, 10000, 12000, 14000, 16000],
    '充放功率(kW)':    [3000, 4000, 5000, 6000, 7000],
    '转换效率η':       [0.80, 0.85, 0.90, 0.95, 1.00],
    '峰谷价差系数k':   [0.6, 0.8, 1.0, 1.2, 1.4],
    '日初始电量(kWh)': [1200, 3000, 6000, 9000, 10800],
}
BASE_LEVEL = {'储能总容量(kWh)': 12000, '充放功率(kW)': 5000, '转换效率η': 0.90,
              '峰谷价差系数k': 1.0, '日初始电量(kWh)': 6000}

def run_one(param, lv):
    """把某参数的一个水平翻译成 solve_year 的入参并重解全年，返回汇总指标。"""
    kw = dict()
    price_use = p0
    if param == '储能总容量(kWh)':
        kw.update(s_min=0.1*lv, s_max=0.9*lv)     # SOC区间始终为容量的10%~90%
    elif param == '充放功率(kW)':
        kw.update(p_max=float(lv))
    elif param == '转换效率η':
        kw.update(eta=float(lv))
    elif param == '峰谷价差系数k':
        price_use = pmean + lv*(p0-pmean)         # 以均值为中心拉伸/压缩峰谷价差
        kw.update(price=price_use)
    elif param == '日初始电量(kWh)':
        kw.update(s_init0=float(lv))              # 只改年初1/1的初始SOC
    sol = solve_year(**kw)
    return metrics_of(sol, price_use)

# 逐场景重解（5参数×5水平=25次全年滚动，每次365个LP）
results = {}
t0 = time.time()
for pi, (param, levels) in enumerate(LEVELS.items()):
    results[param] = {}
    for lv in levels:
        m = run_one(param, lv)
        results[param][str(lv)] = m
        print('[%d/5] %s=%s  cost=%.0f  save=%.2f%%' % (pi+1, param, lv, m['cost'], 100*m['save_rate']), flush=True)
print('全部场景耗时 %.1fs' % (time.time()-t0))

base_cost = results['峰谷价差系数k']['1.0']['cost']   # 基线费用（k=1即原始电价）
json.dump(results, open(os.path.join(os.path.dirname(__file__), '..', '..', '数据', 'sensitivity_results.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

# ---------- 图S1：龙卷风图（各参数最低/最高水平相对基线的费用变化率，按影响排序） ----------
params = list(LEVELS.keys())
low_pct, high_pct, low_lab, high_lab = [], [], [], []
for param in params:
    levels = LEVELS[param]
    cl = results[param][str(levels[0])]['cost']
    ch = results[param][str(levels[-1])]['cost']
    cb = results[param][str(BASE_LEVEL[param])]['cost']
    low_pct.append(100*(cl-cb)/cb); high_pct.append(100*(ch-cb)/cb)
    low_lab.append('%g' % levels[0]); high_lab.append('%g' % levels[-1])
order = np.argsort([max(abs(a), abs(b)) for a, b in zip(low_pct, high_pct)])  # 按影响幅度升序（图上自下而上增大）
params_o = [params[i] for i in order]
lo = [low_pct[i] for i in order]; hi = [high_pct[i] for i in order]
ll = [low_lab[i] for i in order]; hl = [high_lab[i] for i in order]
y = np.arange(len(params_o))
fig, ax = plt.subplots(figsize=(12.5, 5.6), dpi=200)
ax.barh(y-0.2, lo, 0.4, color='#9BBBF4', label='低端水平')
ax.barh(y+0.2, hi, 0.4, color='#E8A09A', label='高端水平')
for i in range(len(y)):
    ax.text(lo[i], y[i]-0.2, '%+.2f%% (%s)' % (lo[i], ll[i]),
            ha='right' if lo[i] < 0 else 'left', va='center', fontsize=9.5)
    ax.text(hi[i], y[i]+0.2, '%+.2f%% (%s)' % (hi[i], hl[i]),
            ha='left' if hi[i] > 0 else 'right', va='center', fontsize=9.5)
ax.axvline(0, color='#333', lw=1)
ax.set_yticks(y); ax.set_yticklabels(params_o, fontsize=11)
ax.set_xlabel('全年总购电费相对基线的变化率 (%)', fontsize=12)
ax.set_title('问题2 敏感性分析①：参数两端扰动对总购电费的影响（龙卷风图，基线 1226.2 万元）', fontsize=13)
ax.grid(axis='x', ls='--', alpha=0.4); ax.legend(fontsize=11, loc='lower right')
lim = max(abs(np.array(lo+hi)).max()*1.25, 1)
ax.set_xlim(-lim, lim)
fig.tight_layout()
p = os.path.join(FIGDIR, '问题2_敏感_龙卷风图.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图S2：参数曲线（5子图，左轴费用实线、右轴节约率虚线） ----------
fig, axes = plt.subplots(1, 5, figsize=(18.5, 4.2), dpi=200)
for ax, param in zip(axes, params):
    levels = LEVELS[param]
    costs = [results[param][str(lv)]['cost']/1e4 for lv in levels]
    rates = [100*results[param][str(lv)]['save_rate'] for lv in levels]
    ax.plot(levels, costs, '-o', color='#6C8EBF', lw=2, label='总购电费(万元)')
    bl = results[param][str(BASE_LEVEL[param])]['cost']/1e4
    ax.axhline(bl, color='#999', ls=':', lw=1)                    # 基线费用点线
    axb = ax.twinx()
    axb.plot(levels, rates, '--s', color='#E2A76F', ms=4, lw=1.6, label='储能节约率(%)')
    ax.set_title(param, fontsize=11.5)
    ax.grid(ls='--', alpha=0.4)
    ax.tick_params(labelsize=9); axb.tick_params(labelsize=9)
    if param == params[0]:
        ax.set_ylabel('总购电费 (万元)', fontsize=10.5, color='#4A6A9A')
    if param == params[-1]:
        axb.set_ylabel('节约率 (%)', fontsize=10.5, color='#B26A2E')
fig.suptitle('问题2 敏感性分析②：五参数逐水平全年重解结果（实线=总购电费，虚线=储能节约率）', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题2_敏感_参数曲线.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)
print('\n敏感性分析完成。')
