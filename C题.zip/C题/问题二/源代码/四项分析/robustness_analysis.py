# -*- coding: utf-8 -*-
"""
问题2 稳健性分析
=====================================================================
情景：日前计划（x,c,d）在实际负载/光伏偏离预测时被"冻结执行"，
偏差只能由紧急购电 e（5 倍电价）兜底，超出光伏的缺额：
  needed = L' + c − x − 0.9d,  e = max(0, needed − PV')
三部分：
  A. 系统偏差网格 dL,dP ∈ {-10,-5,0,5,10}%：年紧急购电量/费热力图
  B. 单因素曲线：dL、dP 分别在 ±15% 扫描
  C. 蒙特卡洛（500 次，日内共同偏差因子，负载σ=5%、光伏σ=10%，截断±15%）
  另对网格 9 点重算"日内可再调度"的自适应最优成本作为对照下界。
输出：robustness_results.json + 3 张图
"""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(__file__))
from q2_common import (get_baseline, solve_year, OUT_SLICE, FIGDIR, ETA0, EMULT)

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

sol = get_baseline()
X, C, D = sol['X'], sol['C'], sol['D']
L, PV, pr = sol['L'], sol['PV'], sol['price']
sl = OUT_SLICE
# 只保留输出区间（2.1-12.31）的冻结计划与对应负载/光伏
Xo, Co, Do, Lo, PVo = X[sl], C[sl], D[sl], L[sl], PV[sl]
plan_cost = float((pr[None, :]*Xo).sum())      # 基线计划购电费

def frozen_outcome(dl, dp):
    """冻结计划下，给定系统偏差(dl负载,dP光伏)，返回(紧急电量kWh, 紧急费用元, 弃光电量kWh)。"""
    Lp, Pp = Lo*(1+dl), PVo*(1+dp)
    need = Lp + Co - Xo - ETA0*Do             # 扣除外网购电与储能放电后仍需覆盖的能量
    e = np.maximum(need - Pp, 0)              # 光伏仍不够的部分→紧急购电
    u = np.minimum(Pp, np.maximum(need, 0))   # 实际被利用的光伏
    curt = np.maximum(Pp - np.maximum(need, 0), 0)   # 冻结计划下被迫弃掉的光伏
    return float(e.sum()), float((EMULT*pr[None, :]*e).sum()), float(curt.sum())

# ---------- A. 偏差网格（5×5） ----------
grid = [-0.10, -0.05, 0.0, 0.05, 0.10]
E_grid = np.zeros((5, 5)); C_grid = np.zeros_like(E_grid); adapt_grid = np.zeros_like(E_grid)
adapt_cache = {}
for i, dl in enumerate(grid):
    for j, dp in enumerate(grid):
        e_kwh, e_cost, _ = frozen_outcome(dl, dp)
        E_grid[i, j] = e_kwh/1000.0           # MWh
        C_grid[i, j] = (plan_cost+e_cost)/1e4  # 万元（计划费+紧急费）
        key = (round(dl, 2), round(dp, 2))
        sa = solve_year(load_scale=1+dl, pv_scale=1+dp)   # 自适应：允许按真实数据重排计划
        m_cost = float((pr[None, :]*sa['X'][sl]).sum())
        adapt_cache[key] = m_cost/1e4
        adapt_grid[i, j] = m_cost/1e4
        print('dL=%+.0f%% dP=%+.0f%%: 紧急%.1f MWh / 冻结总费用%.1f万元 / 自适应%.1f万元'
              % (100*dl, 100*dp, E_grid[i, j], C_grid[i, j], adapt_grid[i, j]), flush=True)

# ---------- B. 单因素曲线（-15%~+15% 共31点，另一因素固定0） ----------
sweep = np.linspace(-0.15, 0.15, 31)
cur_L = np.array([frozen_outcome(v, 0)[1] for v in sweep])   # 只偏负载时的紧急费
cur_P = np.array([frozen_outcome(0, v)[1] for v in sweep])   # 只偏光伏时的紧急费

# ---------- C. 蒙特卡洛：每天抽一个共同偏差因子（日内144区间相同），共500次 ----------
rng = np.random.default_rng(20250911)          # 固定种子保证可复现
N_MC = 500
ndays = 365-31
mc_em, mc_total, mc_curt = [], [], []
for rep in range(N_MC):
    dL_day = np.clip(rng.normal(0, 0.05, 365), -0.15, 0.15)   # 负载日偏差 σ=5%，截断±15%
    dP_day = np.clip(rng.normal(0, 0.10, 365), -0.15, 0.15)   # 光伏日偏差 σ=10%，截断±15%
    dlm = np.repeat(dL_day[:, None], 144, axis=1)[sl]         # 广播到144区间并截取输出段
    dpm = np.repeat(dP_day[:, None], 144, axis=1)[sl]
    Lp, Pp = Lo*(1+dlm), PVo*(1+dpm)
    need = Lp + Co - Xo - ETA0*Do
    e = np.maximum(need - Pp, 0)
    em_cost = float((EMULT*pr[None, :]*e).sum())
    mc_em.append(float(e.sum())/1000.0)       # MWh
    mc_total.append((plan_cost+em_cost)/1e4)  # 万元
mc_em, mc_total = np.array(mc_em), np.array(mc_total)
q = lambda a, p: float(np.quantile(a, p))     # 分位数简写
mc_stat = dict(P5_em=q(mc_em, .05), P50_em=q(mc_em, .5), P95_em=q(mc_em, .95),
               mean_em=float(mc_em.mean()),
               P5_tot=q(mc_total, .05), P50_tot=q(mc_total, .5), P95_tot=q(mc_total, .95),
               mean_tot=float(mc_total.mean()))
print('MC:', {k: round(v, 2) for k, v in mc_stat.items()})

out = dict(plan_cost_wan=plan_cost/1e4,
           grid_pct=[int(100*g) for g in grid],
           frozen_total_wan=C_grid.tolist(), emergency_MWh=E_grid.tolist(),
           adaptive_total_wan=adapt_grid.tolist(),
           sweep_pct=[100*v for v in sweep],
           curve_L_emcost_wan=(cur_L/1e4).tolist(), curve_P_emcost_wan=(cur_P/1e4).tolist(),
           mc=mc_stat)
json.dump(out, open(os.path.join(os.path.dirname(__file__), '..', '..', '数据', 'robustness_results.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

# ---------- 图R1：双热力图（紧急电量 / 冻结总费用） ----------
fig, axes = plt.subplots(1, 2, figsize=(14.5, 5.6), dpi=200)
for ax, mat, ttl, fmt in zip(axes,
        [E_grid, C_grid],
        ['年紧急购电量 (MWh)', '冻结计划下年总购电费 (万元)'],
        ['%.1f', '%.0f']):
    im = ax.imshow(mat, cmap='YlOrRd', aspect='auto')
    ax.set_xticks(range(5)); ax.set_xticklabels(['%+d%%' % g for g in out['grid_pct']])
    ax.set_yticks(range(5)); ax.set_yticklabels(['%+d%%' % g for g in out['grid_pct']])
    ax.set_xlabel('光伏预测偏差 dP', fontsize=11); ax.set_ylabel('负载预测偏差 dL', fontsize=11)
    for i in range(5):
        for j in range(5):
            ax.text(j, i, fmt % mat[i, j], ha='center', va='center', fontsize=9,
                    color='black' if mat[i, j] < mat.max()*0.6 else 'white')   # 深底白字
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    ax.set_title(ttl, fontsize=12.5)
fig.suptitle('问题2 稳健性分析①：负载/光伏系统偏差网格（计划冻结，缺额按5倍电价紧急购电）', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题2_稳健_偏差热力图.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图R2：单因素曲线 ----------
fig, axes = plt.subplots(1, 2, figsize=(13.5, 4.8), dpi=200)
for ax, cur, ttl in zip(axes, [cur_L/1e4, cur_P/1e4], ['负载单因素（dP=0）', '光伏单因素（dL=0）']):
    ax.plot(100*sweep, plan_cost/1e4 + cur, '-o', color='#C0504D', ms=3, label='冻结计划总费用')
    ax.axhline(plan_cost/1e4, color='#888', ls=':', label='基线总费用 %.0f 万元' % (plan_cost/1e4))
    ax.set_xlabel('预测偏差 (%)', fontsize=11); ax.set_ylabel('年总购电费 (万元)', fontsize=11)
    ax.set_title(ttl, fontsize=12.5); ax.grid(ls='--', alpha=0.4); ax.legend(fontsize=10)
fig.suptitle('问题2 稳健性分析②：单因素偏差下的费用响应（负载上偏/光伏下偏触发非线性紧急购电）', fontsize=13)
fig.tight_layout(rect=[0, 0, 1, 0.93])
p = os.path.join(FIGDIR, '问题2_稳健_单因素曲线.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图R3：蒙特卡洛分布（紧急电量/总费用直方图 + P5/P50/P95 竖线） ----------
fig, axes = plt.subplots(1, 2, figsize=(13.5, 4.8), dpi=200)
for ax, data, ttl, qs in zip(axes,
        [mc_em, mc_total],
        ['年紧急购电量分布 (MWh)', '年总购电费分布 (万元)'],
        [('P5', q(mc_em, .05), 'P50', q(mc_em, .5), 'P95', q(mc_em, .95)),
         ('P5', q(mc_total, .05), 'P50', q(mc_total, .5), 'P95', q(mc_total, .95))]):
    ax.hist(data, bins=35, color='#6C8EBF', edgecolor='white', alpha=0.88)
    for lab, qv, col in [(qs[0], qs[1], '#E2A76F'), (qs[2], qs[3], '#333'), (qs[4], qs[5], '#C0504D')]:
        ax.axvline(qv, color=col, ls='--', lw=1.8, label='%s=%.1f' % (lab, qv))
    ax.set_xlabel(ttl.split('(')[-1].rstrip(')'), fontsize=11); ax.set_ylabel('频次', fontsize=11)
    ax.set_title(ttl, fontsize=12.5); ax.grid(axis='y', ls='--', alpha=0.4); ax.legend(fontsize=10)
fig.suptitle('问题2 稳健性分析③：500 次蒙特卡洛（日内共同偏差：负载σ=5%、光伏σ=10%，截断±15%）', fontsize=13)
fig.tight_layout(rect=[0, 0, 1, 0.93])
p = os.path.join(FIGDIR, '问题2_稳健_蒙特卡洛.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)
print('\n稳健性分析完成。')
