# -*- coding: utf-8 -*-
"""
问题2 误差分析（约束可行性 / 数值误差 / 计划满足度）
输出：
  问题2_误差_残差分布.png      母线平衡残差、储能递推残差（全年334×144区间）
  问题2_误差_SOC边界裕度.png   日内SOC包络（min/均值/max）与[1200,10800]边界
  问题2_误差_典型日供需平衡.png 3/20逐时段供电构成 vs 需求（缺口=0）
  error_metrics.json           量化指标
"""
import os, sys, io, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(__file__))     # 保证能 import 同目录的 q2_common
from q2_common import (load_inputs, get_baseline, natural_order, OUT_SLICE,
                       FIGDIR, ETA0, FOCUS, N, DAYS)

# 统一中文字体与配色（与其它图一致）
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
C_BUY, C_STORE, C_PV, C_LINE = '#A8C5E0', '#6C8EBF', '#E2A76F', '#C0504D'

sol = get_baseline()                 # 基线全年解（走缓存）
inp = load_inputs()
X, C, D, U, E, S = sol['X'], sol['C'], sol['D'], sol['U'], sol['E'], sol['S']
L, PV, pr = sol['L'], sol['PV'], sol['price']
sl = OUT_SLICE
hours = np.arange(144)/6.0 + 1/6     # 自然日结束时刻 0:10..24:00（横轴）

def natural_day(arr2d, d):
    """自然日[0:00,24:00)序列：[前一日slot143, 当日slot0..142]（还原跨天取数）。"""
    return np.concatenate([arr2d[d-1, [143]], arr2d[d, :143]])

def natural_soc(d):
    return np.concatenate([[S[d-1, 143]], S[d, 0:144]])   # 145点，0:00..24:00

# ---------- 量化指标 ----------
bal = X[sl] + U[sl] + ETA0*D[sl] + E[sl] - C[sl] - L[sl]  # 母线平衡残差
rec = S[sl, 1:] - S[sl, :-1] - ETA0*C[sl] + D[sl]         # 储能递推残差
deficit = np.maximum(L[sl] - (X[sl] + U[sl] + ETA0*D[sl] - C[sl]), 0)  # 欠供缺口（应0）
metrics = {
    '平衡残差_max': float(np.abs(bal).max()), '平衡残差_meanabs': float(np.abs(bal).mean()),
    '递推残差_max': float(np.abs(rec).max()), '递推残差_meanabs': float(np.abs(rec).mean()),
    '欠供缺口_kWh': float(deficit.sum()), '欠供区间数': int((deficit > 1e-7).sum()),
    '紧急购电_kWh': float(E[sl].sum()),
    'SOC最小值': float(S[sl].min()), 'SOC最大值': float(S[sl].max()),
    '距下界最小裕度_kWh': float(S[sl].min()-1200), '距上界最小裕度_kWh': float(10800-S[sl].max()),
    '单区间充电最大_kWh': float(C[sl].max()), '单区间放电最大_kWh': float(D[sl].max()),
    '功率上界_kWh每10min': 5000/6,
    '同时充放区间数': int(((C[sl] > 1e-6) & (D[sl] > 1e-6)).sum()),
    '弃光电量_kWh': float((PV[sl]-U[sl]).sum()), '弃光率': float((PV[sl]-U[sl]).sum()/PV[sl].sum()),
}
json.dump(metrics, open(os.path.join(os.path.dirname(__file__), '..', '..', '数据', 'error_metrics.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)
print('误差指标:'); [print('  %-22s %.4g' % (k, v)) for k, v in metrics.items()]

# ---------- 图E1：残差分布（双子图，对数纵轴看求解器精度量级） ----------
fig, axes = plt.subplots(1, 2, figsize=(13, 4.6), dpi=200)
for ax, data, name in zip(axes,
                          [np.abs(bal).ravel(), np.abs(rec).ravel()],
                          ['母线平衡残差 |x+u+0.9d+e−c−L|', '储能递推残差 |S(i+1)−S(i)−0.9c+d|']):
    ax.hist(data, bins=40, color=C_STORE, edgecolor='white', alpha=0.85)
    ax.set_yscale('log')
    ax.set_xlabel('残差绝对值 (kWh)', fontsize=11)
    ax.set_ylabel('区间数（对数轴）', fontsize=11)
    ax.set_title(name + '\n最大 %.2e kWh' % data.max(), fontsize=12)
    ax.grid(axis='y', linestyle='--', alpha=0.4)
fig.suptitle('问题2 误差分析①：全年 334 天 × 144 区间数值残差分布（求解器精度量级）', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p1 = os.path.join(FIGDIR, '问题2_误差_残差分布.png')
fig.savefig(p1, bbox_inches='tight'); plt.close(fig); print('saved', p1)

# ---------- 图E2：SOC日内包络（334天逐时刻的min/均值/max 与上下界） ----------
out_days = list(range(31, 365))
soc_nat = np.array([natural_soc(d) for d in out_days])     # (334,145)
t145 = np.arange(145)*10/60.0
smin, smean, smax = soc_nat.min(0), soc_nat.mean(0), soc_nat.max(0)
fig, ax = plt.subplots(figsize=(13, 5.2), dpi=200)
ax.fill_between(t145, smin, smax, color=C_BUY, alpha=0.45, label='334天SOC最小–最大包络')
ax.plot(t145, smean, color=C_STORE, lw=2.0, label='SOC均值')
ax.axhline(1200, color=C_LINE, ls='--', lw=1.5, label='下界 1200')
ax.axhline(10800, color=C_LINE, ls='--', lw=1.5, label='上界 10800')
ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 2))
ax.set_xticklabels(['%02d:00' % h for h in range(0, 25, 2)])
ax.set_xlabel('时间', fontsize=12); ax.set_ylabel('储能电量 (kWh)', fontsize=12)
ax.set_title('问题2 误差分析②：日内储电量包络与边界裕度（全程无越界，最小裕度 %.0f kWh）'
             % min(metrics['距下界最小裕度_kWh'], metrics['距上界最小裕度_kWh']), fontsize=13)
ax.grid(axis='y', linestyle='--', alpha=0.4); ax.legend(loc='upper right', fontsize=10, ncol=2)
fig.tight_layout()
p2 = os.path.join(FIGDIR, '问题2_误差_SOC边界裕度.png')
fig.savefig(p2, bbox_inches='tight'); plt.close(fig); print('saved', p2)

# ---------- 图E3：典型日供需平衡（堆叠供给 x/u/0.9d vs 需求 L+c 曲线） ----------
d = list(inp['dates']).index(FOCUS[0])
Xn, Cn, Dn, Un, Ln = (natural_day(a, d) for a in (X, C, D, U, L))
fig, ax = plt.subplots(figsize=(13, 5.4), dpi=200)
ax.stackplot(hours, Xn, Un, ETA0*Dn,
             labels=['外网购电 x（含转充）', '光伏直供 u', '储能放电 0.9d'],
             colors=[C_BUY, C_PV, '#9BBBF4'], alpha=0.92)
ax.plot(hours, Ln + Cn, color='#333333', lw=2.0, label='母线总需求 L+c')
ax.plot(hours, Ln, color=C_LINE, lw=1.8, ls='--', label='小区负载 L')
ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 2))
ax.set_xticklabels(['%02d:00' % h for h in range(0, 25, 2)])
ax.set_xlabel('时间', fontsize=12); ax.set_ylabel('能量 (kWh/10min)', fontsize=12)
gap = (Xn + Un + ETA0*Dn) - (Ln + Cn)
ax.set_title('问题2 误差分析③：%s 逐时段供电构成 vs 母线需求（供给=需求，最大偏差 %.2e kWh）'
             % (FOCUS[0], np.abs(gap).max()), fontsize=13)
ax.grid(axis='y', linestyle='--', alpha=0.4); ax.legend(loc='upper left', fontsize=10, ncol=2)
fig.tight_layout()
p3 = os.path.join(FIGDIR, '问题2_误差_典型日供需平衡.png')
fig.savefig(p3, bbox_inches='tight'); plt.close(fig); print('saved', p3)
print('\n误差分析完成。')
