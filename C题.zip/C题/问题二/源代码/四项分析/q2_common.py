# -*- coding: utf-8 -*-
"""
问题2 四项分析公共模块
=====================================================================
- load_inputs(): 读取附件1电价、附件2全年负载/光伏（模板列序，与 solve_q2_fresh 一致）
- solve_day(): 单日 LP（参数可覆盖，供敏感性分析）
- solve_year(): 逐天滚动求解 365 天，返回全年逐区间数组
- get_baseline(): 基线参数全年解，带 npz 缓存
口径：母线 x+u+ηd+e = L+c；储能 S(i+1)=S(i)+ηc(i)-d(i)；双侧效率 η=0.9
"""
import os, sys, io
import numpy as np, pandas as pd
from scipy.optimize import linprog

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')
Q2DIR = os.path.join(ROOT, '问题二')
ANADIR = os.path.join(Q2DIR, '源代码', '四项分析')   # 本模块与各分析脚本所在目录
FIGDIR = os.path.join(Q2DIR, '可视化')              # 图片统一输出目录
CACHE = os.path.join(ANADIR, 'cache_baseline.npz')  # 基线全年解缓存（避免每次重解365个LP）
os.makedirs(ANADIR, exist_ok=True)

H = 1/6                    # 区间时长 10 分钟
N = 144                    # 每天区间数
DAYS = 365
OUT_SLICE = slice(31, 365)          # 输出区间 2025.2.1-12.31（前31天1月为预热）
ETA0, PMAX0, SMIN0, SMAX0, SINIT0 = 0.9, 5000.0, 1200.0, 10800.0, 6000.0  # 基线硬件参数（附录1）
EMULT = 5.0                         # 紧急购电单价倍数
FOCUS = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']          # 春分/夏至/秋分/冬至

# 峰谷平阈值（元/kWh，按电价曲线数据分布划定：谷<0.55，峰≥0.95，其余为平）
V_THR, P_THR = 0.55, 0.95

_inputs = None                       # 输入数据单例缓存（只从磁盘读一次）
def load_inputs():
    global _inputs
    if _inputs is not None:
        return _inputs
    att1 = pd.read_excel(ATT1)
    price_raw = att1['电价'].to_numpy(float)
    price_day = np.concatenate([price_raw[1:], price_raw[:1]])     # 模板列序（结束时刻口径循环移位）
    load = pd.read_excel(ATT2, sheet_name='小区负载')
    pv = pd.read_excel(ATT2, sheet_name='光伏发电实际功率')
    dates = pd.to_datetime(load.iloc[:, 0]).dt.strftime('%Y-%m-%d').to_numpy()
    load_mat = load.iloc[:, 1:].to_numpy(float)    # 365×144 功率矩阵
    pv_mat = pv.iloc[:, 1:].to_numpy(float)
    _inputs = dict(price_day=price_day, load=load_mat, pv=pv_mat, dates=dates)
    return _inputs

def day_vector(mat, d):
    """第d天日向量：k=0..142取当天第1..143列，k=143跨天取下一天第0列（年末退回本列）。"""
    v = np.empty(N)
    v[:N-1] = mat[d, 1:N]
    v[N-1] = mat[d+1, 0] if d+1 < DAYS else mat[d, N-1]
    return v

def solve_day(load_kW, pv_kW, price, s_init, eta=ETA0, p_max=PMAX0,
              s_min=SMIN0, s_max=SMAX0, emult=EMULT):
    """单日 LP（硬件参数均可覆盖，供敏感性分析改 η/功率/SOC 区间）。
    变量 x购电 c充电 d放电 u光伏利用 e紧急购电 各144 + S 145。"""
    L = load_kW * H; PV = pv_kW * H          # 功率×H→电量
    e_max = p_max * H                        # 单区间充/放上界
    nv = 5*N + N+1
    off = {'x': 0, 'c': N, 'd': 2*N, 'u': 3*N, 'e': 4*N, 'S': 5*N}
    vid = lambda i, k: off[k]+i
    obj = np.zeros(nv)
    obj[off['x']:off['x']+N] = price         # 购电单价 p
    obj[off['e']:off['e']+N] = emult*price   # 紧急购电 5p（确定性最优下不会被使用）
    A = np.zeros((2*N, nv)); b = np.zeros(2*N)
    for i in range(N):
        # 母线平衡 x+u+ηd+e−c = L
        A[i, vid(i,'x')] = 1; A[i, vid(i,'u')] = 1; A[i, vid(i,'d')] = eta
        A[i, vid(i,'e')] = 1; A[i, vid(i,'c')] = -1; b[i] = L[i]
        # 储能递推 S_{i+1}−S_i−ηc+d = 0
        A[N+i, vid(i+1,'S')] = 1; A[N+i, vid(i,'S')] = -1
        A[N+i, vid(i,'c')] = -eta; A[N+i, vid(i,'d')] = 1
    bounds = [(0.0, None)]*nv
    for i in range(N):
        bounds[vid(i,'c')] = (0, e_max); bounds[vid(i,'d')] = (0, e_max)
        bounds[vid(i,'u')] = (0, PV[i])          # 光伏利用不超过可发电量
    for i in range(N+1):
        bounds[vid(i,'S')] = (s_min, s_max)      # SOC 区间
    bounds[vid(0,'S')] = (s_init, s_init)        # 当日0:00 SOC 固定为滚动传入值
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError(res.message)
    g = lambda k: res.x[off[k]:off[k]+N]
    return g('x'), g('c'), g('d'), g('u'), g('e'), res.x[off['S']:off['S']+N+1]

def solve_year(price=None, eta=ETA0, p_max=PMAX0, s_min=SMIN0, s_max=SMAX0,
               s_init0=SINIT0, load_scale=1.0, pv_scale=1.0, verbose=False):
    """逐日滚动求解365天：每天解一个单日LP，日末S[N]作为次日初始SOC。
    load_scale/pv_scale 供稳健性整体缩放负载/光伏；返回各变量的 365×144 全年数组。"""
    inp = load_inputs()
    price_day = inp['price_day'] if price is None else price
    X = np.zeros((DAYS, N)); C = np.zeros_like(X); D = np.zeros_like(X)
    U = np.zeros_like(X); E = np.zeros_like(X); S = np.zeros((DAYS, N+1))
    Lall = np.zeros_like(X); Pall = np.zeros_like(X)
    s_init = s_init0                       # 年初 2025-01-01 0:00 = 6000
    for d in range(DAYS):
        lv = day_vector(inp['load'], d)*load_scale
        pvv = day_vector(inp['pv'], d)*pv_scale
        x, c, dd, u, e, s = solve_day(lv, pvv, price_day, s_init,
                                      eta=eta, p_max=p_max, s_min=s_min, s_max=s_max)
        X[d], C[d], D[d], U[d], E[d], S[d] = x, c, dd, u, e, s
        Lall[d] = lv*H; Pall[d] = pvv*H    # 记录当日负载/光伏电量（供汇总）
        s_init = float(s[N])               # 时间滚动：日末SOC→次日S0
        if verbose and (d+1) % 60 == 0:
            print('  solved %d/365' % (d+1))
    return dict(X=X, C=C, D=D, U=U, E=E, S=S, L=Lall, PV=Pall, price=price_day)

def summarize(sol):
    """输出区间(2.1-12.31)汇总指标：购电量/费、紧急购电、充放、光伏、无储能基准、节约率、残差。"""
    sl = OUT_SLICE
    X, C, D, U, E, S = sol['X'], sol['C'], sol['D'], sol['U'], sol['E'], sol['S']
    L, PV, pr = sol['L'], sol['PV'], sol['price']
    m = {}
    m['buy'] = float(X[sl].sum())
    m['cost'] = float((pr[None, :]*X[sl]).sum())
    m['em_kwh'] = float(E[sl].sum())
    m['em_cost'] = float((EMULT*pr[None, :]*E[sl]).sum())
    m['chg'] = float(C[sl].sum()); m['dis'] = float(D[sl].sum())
    m['pv_used'] = float(U[sl].sum()); m['load'] = float(L[sl].sum())
    m['pv_avail'] = float(PV[sl].sum())
    m['base_nostore'] = float((pr[None, :]*np.maximum(L[sl]-PV[sl], 0)).sum())  # 无储能基准费
    m['save'] = m['base_nostore'] - m['cost']
    m['save_rate'] = m['save']/m['base_nostore']
    # 残差（应在求解器浮点精度 1e-13 量级）
    bal = X[sl] + U[sl] + ETA0*D[sl] + E[sl] - C[sl] - L[sl]
    rec = S[sl, 1:] - S[sl, :-1] - ETA0*C[sl] + D[sl]
    m['bal_resid_max'] = float(np.abs(bal).max())
    m['rec_resid_max'] = float(np.abs(rec).max())
    return m

def get_baseline(force=False):
    """取基线全年解：优先读 npz 缓存；force=True 或无缓存时重解并落盘。"""
    if (not force) and os.path.exists(CACHE):
        z = np.load(CACHE)
        return {k: z[k] for k in z.files}
    sol = solve_year(verbose=True)
    np.savez(CACHE, **sol)
    return sol

def natural_order(v):
    """模板列序 -> 自然日 [0:00,24:00) 序：[143] 提到最前。v 最后一维=144。"""
    return np.concatenate([v[..., [143]], v[..., :143]], axis=-1)

if __name__ == '__main__':
    import time
    t0 = time.time()
    sol = get_baseline(force=True)
    print('baseline solved in %.1fs' % (time.time()-t0))
    m = summarize(sol)
    for k, v in m.items():
        print('%-14s %.6g' % (k, v))
