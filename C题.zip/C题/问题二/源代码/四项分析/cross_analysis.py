# -*- coding: utf-8 -*-
"""
问题2 交叉分析（时间维度 × 策略维度 × 资源维度）
输出：
  问题2_交叉_月度指标.png        月度购电量/购电费/平均购电单价
  问题2_交叉_峰谷平结构.png      峰/谷/平 × 月份 购电量结构 + 储能充放
  问题2_交叉_四指定日对比.png    四指定日多指标对比
  问题2_交叉_负载率散点.png      日负载能量 vs 光伏自用率/储能循环/购电策略
  cross_metrics.json
"""
import os, sys, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.append(os.path.dirname(__file__))
from q2_common import (load_inputs, get_baseline, OUT_SLICE, FIGDIR,
                       V_THR, P_THR, FOCUS)

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
C_BUY, C_STORE, C_PV, C_BASE = '#A8C5E0', '#6C8EBF', '#E2A76F', '#D9C9A3'

sol = get_baseline(); inp = load_inputs()
X, C, D, U, E, S = sol['X'], sol['C'], sol['D'], sol['U'], sol['E'], sol['S']
L, PV, pr = sol['L'], sol['PV'], sol['price']
dates = pd.to_datetime(pd.Series(inp['dates']))
month = dates.dt.month.to_numpy()
# 按阈值把144个区间分为谷/平/峰三段（电价每天相同，故对144维向量打标）
is_valley = pr < V_THR
is_peak = pr >= P_THR
is_flat = ~(is_valley | is_peak)
seg = np.where(is_valley, 0, np.where(is_flat, 1, 2))   # 0谷 1平 2峰
seg_name = ['谷段', '平段', '峰段']
seg_color = ['#9BBBF4', '#D9C9A3', '#E8A09A']

# ---------- 月度汇总（2-12月，1月为预热不输出） ----------
months = list(range(2, 13))
rows = []
for m in months:
    idx = np.where((month == m) & (np.arange(365) >= 31))[0]
    buy = X[idx].sum(); cost = (pr[None, :]*X[idx]).sum()
    rows.append(dict(month=m, days=len(idx), buy=buy, cost=cost,
                     avg_price=cost/buy, load=L[idx].sum(), pv=PV[idx].sum(),
                     pv_used=U[idx].sum(), chg=C[idx].sum(), dis=D[idx].sum(),
                     base=(pr[None, :]*np.maximum(L[idx]-PV[idx], 0)).sum()))
mon = pd.DataFrame(rows)
mon['save_rate'] = (mon.base - mon.cost)/mon.base       # 各月相对无储能的节约率
# 峰谷平×月购电量/充电/放电三张 3×11 矩阵
seg_buy = np.zeros((3, len(months)))
seg_chg = np.zeros_like(seg_buy); seg_dis = np.zeros_like(seg_buy)
for j, m in enumerate(months):
    idx = np.where((month == m) & (np.arange(365) >= 31))[0]
    for s in range(3):
        k = seg == s
        seg_buy[s, j] = X[idx][:, k].sum()
        seg_chg[s, j] = C[idx][:, k].sum()
        seg_dis[s, j] = D[idx][:, k].sum()

cross_out = {r['month']: {kk: round(vv, 3) for kk, vv in r.items()} for r in rows}
json.dump(cross_out, open(os.path.join(os.path.dirname(__file__), '..', '..', '数据', 'cross_metrics.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)
print(mon.round(2).to_string(index=False))

# ---------- 图C1：月度指标（柱：购电量/负载；双轴折线：平均购电单价） ----------
fig, ax1 = plt.subplots(figsize=(13, 5.4), dpi=200)
xl = np.arange(len(months)); w = 0.42
ax1.bar(xl-w/2, mon.buy/1e4, w, color=C_BUY, label='月购电量(万kWh)')
ax1.bar(xl+w/2, mon.load/1e4, w, color='#E4E4E4', label='月负载电量(万kWh)')
ax1.set_xticks(xl); ax1.set_xticklabels(['%d月' % m for m in months])
ax1.set_ylabel('电量 (万kWh)', fontsize=12); ax1.grid(axis='y', ls='--', alpha=0.4)
ax2 = ax1.twinx()
ax2.plot(xl, mon.avg_price, color='#B26A2E', marker='o', lw=2, label='平均购电单价(元/kWh)')
ax2.set_ylabel('平均购电单价 (元/kWh)', fontsize=12, color='#B26A2E')
ax2.set_ylim(0.5, 0.8); ax2.tick_params(axis='y', labelcolor='#B26A2E')
h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1+h2, l1+l2, loc='upper left', fontsize=10, ncol=3)
ax1.set_title('问题2 交叉分析①：月度购电量、负载电量与平均购电单价（单价冬高夏低，与负载季节同步）', fontsize=12.5)
fig.tight_layout()
p = os.path.join(FIGDIR, '问题2_交叉_月度指标.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图C2：峰谷平结构（左：分段购电堆叠柱；右：谷充/峰放对照柱） ----------
fig, axes = plt.subplots(1, 2, figsize=(14.5, 5.4), dpi=200)
ax = axes[0]
bottom = np.zeros(len(months))
for s in range(3):
    ax.bar(xl, seg_buy[s]/1e4, 0.62, bottom=bottom/1e4, color=seg_color[s], label=seg_name[s]+'购电')
    bottom += seg_buy[s]
ax.set_xticks(xl); ax.set_xticklabels(['%d月' % m for m in months])
ax.set_ylabel('购电量 (万kWh)', fontsize=12); ax.grid(axis='y', ls='--', alpha=0.4)
ax.legend(fontsize=10); ax.set_title('各月分时段购电量结构', fontsize=12.5)
ax = axes[1]
w2 = 0.38
ax.bar(xl-w2/2, seg_chg[0]/1e4, w2, color=C_STORE, label='谷段充电量')
ax.bar(xl+w2/2, seg_dis[2]/1e4, w2, color=C_PV, label='峰段放电量')
ax.set_xticks(xl); ax.set_xticklabels(['%d月' % m for m in months])
ax.set_ylabel('电量 (万kWh)', fontsize=12); ax.grid(axis='y', ls='--', alpha=0.4)
ax.legend(fontsize=10); ax.set_title('各月储能充放电量（低充高放）', fontsize=12.5)
fig.suptitle('问题2 交叉分析②：峰谷平时段 × 月份的购电与储能行为', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题2_交叉_峰谷平结构.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图C3：四指定日对比（2行3列，每子图一个指标的4日柱状对比） ----------
labels = ['购电量\nkWh', '购电费\n元', '负载电量\nkWh', '光伏电量\nkWh', '充电量\nkWh', '放电量\nkWh']
focus_idx = [list(inp['dates']).index(f) for f in FOCUS]
data = []
for d in focus_idx:
    data.append([X[d].sum(), (pr*X[d]).sum(), L[d].sum(), PV[d].sum(), C[d].sum(), D[d].sum()])
data = np.array(data)
fig, axes = plt.subplots(2, 3, figsize=(15, 8), dpi=200)
for k, ax in enumerate(axes.flat):
    vals = data[:, k]
    bars = ax.bar(range(4), vals, color=['#9BBBF4', '#A2DDAA', '#E4B48A', '#C9A7E8'])
    for b, v in zip(bars, vals):
        ax.text(b.get_x()+b.get_width()/2, b.get_height(), '%.0f' % v,
                ha='center', va='bottom', fontsize=9)     # 柱顶数值标注
    ax.set_xticks(range(4)); ax.set_xticklabels([f[5:] for f in FOCUS], fontsize=10)
    ax.set_title(labels[k], fontsize=12); ax.grid(axis='y', ls='--', alpha=0.4)
    ax.set_ylim(0, vals.max()*1.18)
fig.suptitle('问题2 交叉分析③：四个指定日（春分/夏至/秋分/冬至）策略指标对比', fontsize=14)
fig.tight_layout(rect=[0, 0, 1, 0.96])
p = os.path.join(FIGDIR, '问题2_交叉_四指定日对比.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ---------- 图C4：日负载能量 vs 策略指标散点（颜色=月份，含线性趋势与相关系数） ----------
idx = np.arange(31, 365)
day_load = L[idx].sum(1); day_pv = PV[idx].sum(1)
day_buy = X[idx].sum(1); day_chg = C[idx].sum(1)
self_rate = U[idx].sum(1)/np.maximum(day_pv, 1e-9)          # 光伏自用率
cycle = day_chg/9600.0                                     # 日等效循环次数（可用容量=10800-1200=9600）
buy_ratio = day_buy/np.maximum(day_load, 1e-9)             # 单位负载购电
fig, axes = plt.subplots(1, 3, figsize=(15.8, 4.8), dpi=200)
sc_kw = dict(c=month[idx], cmap='viridis', s=22, alpha=0.8)
titles = ['光伏自用率 (%)', '储能日等效循环 (次)', '购电/负载比']
ylims = [(68, 103), None, None]
for ax, yy, ttl, yn, j in zip(axes,
                           [self_rate*100, cycle, buy_ratio],
                           titles,
                           ['%', '次', ''], range(3)):
    z = ax.scatter(day_load/1e3, yy, **sc_kw)
    # 线性趋势
    coef = np.polyfit(day_load/1e3, yy, 1)
    xx = np.linspace((day_load/1e3).min(), (day_load/1e3).max(), 50)
    ax.plot(xx, np.polyval(coef, xx), color='#C0504D', lw=1.8, label='线性趋势')
    r = np.corrcoef(day_load, yy)[0, 1]                    # 皮尔逊相关系数
    ax.set_title(ttl + '  r=%.2f' % r, fontsize=12)
    ax.set_xlabel('日负载电量 (千kWh)', fontsize=11); ax.set_ylabel(yn, fontsize=11)
    if ylims[j]: ax.set_ylim(*ylims[j])
    ax.grid(ls='--', alpha=0.4); ax.legend(fontsize=9, loc='upper left')
fig.subplots_adjust(right=0.93)
cax = fig.add_axes([0.94, 0.16, 0.012, 0.7])
cb = fig.colorbar(z, cax=cax)
cb.set_label('月份', fontsize=11)
fig.suptitle('问题2 交叉分析④：日负载水平与光伏自用、储能循环、外购电的关系（颜色=月份）', fontsize=13.5, y=1.02)
fig.savefig(os.path.join(FIGDIR, '问题2_交叉_负载率散点.png'), bbox_inches='tight'); plt.close(fig)
print('saved 问题2_交叉_负载率散点.png')
print('\n交叉分析完成。')
