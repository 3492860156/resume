# -*- coding: utf-8 -*-
"""
轻量 Markdown -> Word(.docx) 转换器（问题二材料用）
支持：# 标题、| 表格、> 引用、- / 数字 列表、**加粗**、`行内代码`、--- 分隔线
正文宋体小四，标题黑体，表格 Table Grid 带边框。
用法: python md2docx.py a.md b.md ...
注意：本脚本是“命令行传 md 路径列表”的通用转换器；问题一 文档工具 下另有一个
      硬编码路径、带动态目录的 md_to_docx.py，两者不是同一个文件。
"""
import re, sys, io, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')   # 控制台强制UTF-8
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

BOLD_RE = re.compile(r'(\*\*.+?\*\*|`.+?`)')    # 匹配 **加粗** 或 `代码`

def add_runs(p, text, base_size=11, cn='宋体', en='Times New Roman'):
    """把一行文本按 **bold** / `code` 标记切分后写入段落 p，并设置中英文字体。"""
    for tok in BOLD_RE.split(text):
        if not tok:
            continue
        if tok.startswith('**') and tok.endswith('**'):
            r = p.add_run(tok[2:-2]); r.bold = True
            fcn, fen, fsz = cn, en, base_size
        elif tok.startswith('`') and tok.endswith('`'):
            r = p.add_run(tok[1:-1])
            fcn, fen, fsz = 'Consolas', 'Consolas', base_size - 0.5   # 代码用等宽字体、略小
        else:
            r = p.add_run(tok); fcn, fen, fsz = cn, en, base_size
        r.font.name = fen
        r._element.rPr.rFonts.set(qn('w:eastAsia'), fcn)   # 中文字体必须写 eastAsia
        r.font.size = Pt(fsz)

def set_style_font(doc, name, cn, en, size, bold=False, color=None):
    """统一设置某个 Word 样式的中英文字体、字号、加粗、颜色。"""
    st = doc.styles[name]
    st.font.name = en; st.font.size = Pt(size); st.font.bold = bold
    st._element.rPr.rFonts.set(qn('w:eastAsia'), cn)
    if color:
        st.font.color.rgb = RGBColor(*color)

def is_sep(line):
    """判断是否为 Markdown 表格的对齐分隔行（如 |---|:--:|）。"""
    return bool(re.fullmatch(r'\s*\|?[\s:\-\|]+\|?\s*', line)) and '-' in line

def split_row(line):
    """拆分一行表格为单元格字符串列表（去掉首尾竖线后按 | 切）。"""
    line = line.strip()
    if line.startswith('|'):
        line = line[1:]
    if line.endswith('|'):
        line = line[:-1]
    return [c.strip() for c in line.split('|')]

def convert(md_path, docx_path):
    """把单个 md 文件转换为同名 docx，返回 Document 对象（供外层统计）。"""
    lines = io.open(md_path, encoding='utf-8').read().splitlines()
    doc = Document()
    # 页面与默认样式
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Cm(2.5)
    set_style_font(doc, 'Normal', '宋体', 'Times New Roman', 11)
    doc.styles['Normal'].paragraph_format.line_spacing = 1.4
    for name, sz in [('Heading 1', 16), ('Heading 2', 14), ('Heading 3', 12.5), ('Heading 4', 11.5)]:
        set_style_font(doc, name, '黑体', 'Arial', sz, bold=True, color=(0, 0, 0))

    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1; continue
        # 分隔线（---/***）：Word中不渲染，直接跳过
        if re.fullmatch(r'-{3,}|\*{3,}', line.strip()):
            i += 1; continue
        # 标题（1~4个#）
        m = re.match(r'(#{1,4})\s+(.*)', line)
        if m:
            p = doc.add_heading(level=len(m.group(1)))
            add_runs(p, m.group(2), base_size={1:16,2:14,3:12.5,4:11.5}[len(m.group(1))], cn='黑体', en='Arial')
            for r in p.runs: r.bold = True
            i += 1; continue
        # 表格：连续若干 | 开头的行组成一张表（第1行表头、第2行分隔、其余数据行）
        if line.lstrip().startswith('|'):
            block = []
            while i < len(lines) and lines[i].lstrip().startswith('|'):
                block.append(lines[i]); i += 1
            header = split_row(block[0])
            body = [split_row(r) for r in block[2:] if not is_sep(r)] if len(block) > 1 else []
            ncol = len(header)
            tb = doc.add_table(rows=1+len(body), cols=ncol)
            tb.style = 'Table Grid'                          # 自带全边框
            tb.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for j, h in enumerate(header):                  # 表头加粗
                cell = tb.rows[0].cells[j]
                cell.paragraphs[0].text = ''
                add_runs(cell.paragraphs[0], h, base_size=10.5)
                for r in cell.paragraphs[0].runs: r.bold = True
            for ri, row in enumerate(body):                 # 数据行（缺列补空）
                for j in range(ncol):
                    txt = row[j] if j < len(row) else ''
                    cell = tb.rows[ri+1].cells[j]
                    cell.paragraphs[0].text = ''
                    add_runs(cell.paragraphs[0], txt, base_size=10.5)
            doc.add_paragraph()
            continue
        # 引用块（> 开头）：缩进、斜体、灰色
        if line.lstrip().startswith('>'):
            txt = re.sub(r'^\s*>\s?', '', line)
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.75)
            add_runs(p, txt, base_size=10.5)
            for r in p.runs:
                r.italic = True; r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
            i += 1; continue
        # 无序列表（- 或 *）：转成文本符号 •，缩进按原始空格层级
        mb = re.match(r'^(\s*)[-*]\s+(.*)', line)
        if mb:
            indent = len(mb.group(1))
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.75 + 0.5*(indent//3))
            add_runs(p, '• ' + mb.group(2))
            i += 1; continue
        # 有序列表（数字.）：保留原编号文本
        mo = re.match(r'^(\s*)(\d+)\.\s+(.*)', line)
        if mo:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.75 + 0.5*(len(mo.group(1))//3))
            add_runs(p, mo.group(2) + '. ' + mo.group(3))
            i += 1; continue
        # 普通段落
        p = doc.add_paragraph()
        add_runs(p, line)
        i += 1
    doc.save(docx_path)
    return doc

if __name__ == '__main__':
    for md in sys.argv[1:]:                       # 支持一次传多个 md 路径
        out = os.path.splitext(md)[0] + '.docx'  # 同名 .docx
        d = convert(md, out)
        print('转换完成: %s （段落 %d，表格 %d）' % (out, len(d.paragraphs), len(d.tables)))
