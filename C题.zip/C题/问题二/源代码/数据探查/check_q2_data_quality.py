# -*- coding: utf-8 -*-
"""
附件2 数据清洗检验（完整性 / 缺失 / 合法性 / 时间对齐 / 异常形态）
==================================================================
检查项：
  1) 结构完整性：sheet、行列数、日期 365 天连续/无重复/升序
  2) 缺失值：负载、光伏 NaN 计数
  3) 数值合法性：负载<=0、光伏<0 计数
  4) 时间标签：144 列与模板 0:10..0:00+1 对齐
  5) 光伏夜间非零（结束时刻 21:00–04:00 应为 0）
  6) 相邻 10 分钟负载异常跳变（>2500 kW）
  7) 跨日边界连续性（23:50-24:00 与次日 0:00-0:10）
只读检查，不修改任何文件。
"""
import os
import numpy as np
import pandas as pd
import openpyxl

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')
TPL  = os.path.join(ROOT, '附件', '附件5', 'result2.xlsx')

L = pd.read_excel(ATT2, sheet_name='小区负载')
P = pd.read_excel(ATT2, sheet_name='光伏发电实际功率')
dates = pd.to_datetime(L.iloc[:, 0]).to_numpy().astype('datetime64[D]')   # 365天日期
ld = L.iloc[:, 1:].to_numpy(float)     # 负载功率矩阵 365×144
pv = P.iloc[:, 1:].to_numpy(float)     # 光伏功率矩阵 365×144
cols = [str(c) for c in L.columns[1:]] # 144个时间列名

print('=' * 62)
print('附件2 数据清洗检验报告')
print('=' * 62)

# ---------- 1) 结构完整性 ----------
print('\n[1] 结构完整性')
print('  负载 sheet 行列: %d x %d | 光伏 sheet 行列: %d x %d'
      % (L.shape[0], L.shape[1], P.shape[0], P.shape[1]))
print('  负载/光伏行数一致: %s' % ('✓' if L.shape[0] == P.shape[0] else '✗'))
print('  日期范围: %s .. %s' % (dates[0], dates[-1]))
d_arr = dates
diff = np.diff(d_arr)    # 相邻日期差
print('  日期连续(间隔恰为1天): %s' % ('✓ 365 天无缺失' if (len(diff) == 364 and (diff == np.timedelta64(1, 'D')).all()) else '✗ 有缺失/重复'))
print('  重复日期: %d 个 | 乱序: %s' % (len(d_arr) - len(set(d_arr)), '无' if (diff > np.timedelta64(0, 'D')).all() else '有'))

# ---------- 2) 缺失值 ----------
print('\n[2] 缺失值')
print('  负载 NaN: %d | 光伏 NaN: %d' % (int(np.isnan(ld).sum()), int(np.isnan(pv).sum())))

# ---------- 3) 数值合法性 ----------
print('\n[3] 数值合法性')
print('  负载 <=0: %d 个 | 光伏 <0: %d 个' % (int((ld <= 0).sum()), int((pv < 0).sum())))
print('  负载 min/max: %.1f / %.1f kW | 光伏 min/max: %.1f / %.1f kW'
      % (ld.min(), ld.max(), pv.min(), pv.max()))

# ---------- 4) 时间标签对齐 ----------
print('\n[4] 时间标签对齐（与模板 0:10..0:00+1 比对）')
def norm(c):
    """附件2列名归一化为 'H:MM'，跨日列统一为 '0:00+1'。"""
    s = str(c).strip()
    if s.endswith('+1'):
        return '0:00+1'
    if ':' in s:
        p = s.split(':')
        return '%d:%02d' % (int(p[0]), int(p[1]))
    return s

def norm_t2(c):
    """模板区间表头 't1-t2' → 取 t2 归一化；'+1' 表示次日时刻。"""
    s = str(c).strip()
    if '-' in s:
        s = s.split('-')[1].strip()
    plus1 = s.endswith('+1')
    if plus1:
        s = s[:-2]
    if ':' not in s:
        return s
    p = s.split(':')
    m = int(p[0]) * 60 + int(p[1]) + (1440 if plus1 else 0)   # 换算成分钟（次日+1440）
    if m == 1440:
        return '0:00+1'
    if m > 1440:
        m -= 1440
    return '%d:%02d' % (m // 60, m % 60)

# 附件2标准列序：0:10,0:20,...,24:00,0:00+1（结束时刻，共144列）
std = ['%d:%02d' % ((i + 1) * 10 // 60, (i + 1) * 10 % 60) for i in range(143)] + ['0:00+1']
cols_n = [norm(c) for c in cols]
print('  实际列名 前3: %s 后3: %s' % (cols[:3], cols[-3:]))
print('  附件2 144 列与标准标签一致（归一化后）: %s' % ('✓' if cols_n == std else '✗ 不一致: %s' % [c for c, s in zip(cols, std) if c != s][:5]))
wb = openpyxl.load_workbook(TPL, read_only=True, data_only=True)
ws = wb['计划购电量']
hdr = [norm_t2(ws.cell(1, c).value) for c in range(2, 146)]
print('  模板表头 前3: %s 后3: %s' % ([str(ws.cell(1, c).value) for c in range(2, 5)], [str(ws.cell(1, c).value) for c in range(143, 146)]))
expect = std[1:] + ['0:10']   # 模板列 = 当日 0:20..0:00+1 + 次日 0:10
print('  模板表头 t2 序列与预期一致（0:20..0:00+1, 次日0:10）: %s' % ('✓' if hdr == expect else '✗ 差异: %s' % [c for c, s in zip(hdr, expect) if c != s][:5]))

# ---------- 5) 光伏夜间非零 ----------
print('\n[5] 光伏夜间非零检查（结束时刻 21:00–04:00，理论上应恒为 0）')
# 结束分钟=(i+1)*10；≥21:00 或 ≤04:00 的列视为夜间
night_idx = [i for i, c in enumerate(cols) if (21 * 60 <= (i + 1) * 10) or ((i + 1) * 10 <= 4 * 60)]
night_pv = pv[:, night_idx]
n_nonzero = int((night_pv > 0).sum())
print('  夜间时段总数: %d | 非零值: %d (%.3f%%)' % (night_pv.size, n_nonzero, 100 * n_nonzero / night_pv.size))
if n_nonzero:
    d_idx, c_idx = np.where(night_pv > 0)
    rows = {}
    night_cols = np.array(night_idx)
    for dd, cc in zip(d_arr[d_idx], night_cols[c_idx]):
        rows.setdefault(str(dd), []).append(cols[cc])
    print('  涉及天数: %d 天（示例: %s）' % (len(rows), list(rows.items())[:3]))
    print('  夜间光伏最大值: %.1f kW' % night_pv.max())

# ---------- 6) 相邻 10 分钟负载跳变 ----------
print('\n[6] 相邻 10 分钟负载跳变（>2500 kW 视为可疑突变）')
dj = np.abs(np.diff(ld, axis=1))     # 沿时间轴一阶差分绝对值
big = np.where(dj > 2500)
print('  可疑突变计数: %d | 涉及天数: %d | 最大跳变: %.1f kW' % (len(big[0]), len(set(big[0])), dj.max()))
for dd, cc in list(zip(big[0], big[1]))[:5]:
    print('    %s  区间[%s→%s] 负载 %.0f→%.0f kW' % (d_arr[dd], cols[cc], cols[cc + 1], ld[dd, cc], ld[dd, cc + 1]))

# ---------- 7) 跨日边界连续性 ----------
print('\n[7] 跨日边界连续性（当日 23:50-24:00 与次日 0:00-0:10 负载差）')
bound = np.abs(ld[1:, -1] - ld[:-1, 0])    # 当天最后一列 vs 次日第一列
print('  365 天边界最大跳变: %.1f kW | 平均: %.1f kW | 超过 1000 kW 的天数: %d'
      % (bound.max(), bound.mean(), int((bound > 1000).sum())))

print('\n' + '=' * 62)
print('检验完成（只读，未修改任何数据文件）')
print('=' * 62)
