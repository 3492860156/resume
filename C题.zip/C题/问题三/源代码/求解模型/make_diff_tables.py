# -*- coding: utf-8 -*-
"""
差值表：最终购电量 - 计划购电量（>0 上调1.5P，<0 下调0.5P退款）
 1) 论文差值表（4指定日：6指定时段 + 全天汇总）-> 追加到 论文表格数据_Q3
 2) 购电量差值明细.xlsx：逐日汇总(334天) + 四指定日逐段差值
"""
import os
import json
import datetime as dt
import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from q3_common import FOCUS, T1_SPECS, OUTDIR


def seg_label(i):
    s, e = (i+1)*10, (i+2)*10

    def f(m):
        return '%d:%02d' % ((m % 1440)//60, (m % 1440) % 60) + ('+1' if m >= 1440 else '')
    return f(s) + '-' + f(e)


def main():
    j = json.load(open(os.path.join(OUTDIR, '数据', 'q3_full_results.json'), encoding='utf-8'))
    daily = j['daily']; focus = j['focus_full']; out = daily[31:]

    # ---------- 1. 论文差值表 Markdown ----------
    L = ['# 购电量调整差值表（最终-计划，正=上调1.5P，负=下调0.5P退款）']
    for f in FOCUS:
        r = focus[f]
        Xp, Xf = np.array(r['Xp']), np.array(r['Xf'])
        diff = Xf - Xp
        L.append('\n## %s 指定时段差值（kWh）\n' % f)
        L.append('| 时间段 | 计划购电量 | 最终购电量 | 差值 | 方向 |')
        L.append('|---|---|---|---|---|')
        for name, idx in T1_SPECS:
            d = diff[idx]
            way = '上调' if d > 1e-6 else ('下调' if d < -1e-6 else '不变')
            L.append('| %s | %.4f | %.4f | %+.4f | %s |'
                     % (name, Xp[idx], Xf[idx], d, way))
        L.append('\n**全天汇总**：计划 %.2f、最终 %.2f、上调合计 %.2f、下调合计 %.2f、净差值 %+.2f kWh；调整结算 %+.2f 元。\n'
                 % (r['plan_buy'], r['final_buy'], r['up'], r['dn'],
                    r['final_buy']-r['plan_buy'], r['cost_adj']))

    md_path = os.path.join(OUTDIR, '文档资料', '购电量差值表_Q3.md')
    open(md_path, 'w', encoding='utf-8').write('\n'.join(L))
    print('saved', md_path)

    # ---------- 2. Excel 差值明细 ----------
    wb = openpyxl.Workbook()
    hf = Font(bold=True, color='FFFFFF'); hfill = PatternFill('solid', fgColor='4E79A7')
    up_fill = PatternFill('solid', fgColor='FCE4E4'); dn_fill = PatternFill('solid', fgColor='E4F0FC')
    thin = Side(style='thin', color='BFBFBF'); bd = Border(thin, thin, thin, thin)

    ws = wb.active; ws.title = '逐日差值汇总'
    head = ['日期', '计划全天购电量', '最终全天购电量', '上调量', '下调量',
            '净差值(最终-计划)', '调整结算费(元)', '紧急购电量', '全天总费用(元)']
    ws.append(head)
    for c in range(1, len(head)+1):
        cell = ws.cell(1, c); cell.font = hf; cell.fill = hfill
        cell.alignment = Alignment(horizontal='center'); cell.border = bd
    for r in out:
        row = [dt.datetime.strptime(r['date'], '%Y-%m-%d'),
               round(r['plan_buy'], 4), round(r['final_buy'], 4),
               round(r['up'], 4), round(r['dn'], 4),
               round(r['final_buy']-r['plan_buy'], 4),
               round(r['cost_adj'], 2), round(r['em_buy'], 4), round(r['cost_tot'], 2)]
        ws.append(row)
        rr = ws.max_row
        for c in range(1, len(head)+1):
            ws.cell(rr, c).border = bd
        ws.cell(rr, 1).number_format = 'yyyy-mm-dd'
        ws.cell(rr, 6).fill = up_fill if row[5] > 1e-6 else (dn_fill if row[5] < -1e-6 else PatternFill())
    # 合计行
    ws.append(['合计', round(sum(r['plan_buy'] for r in out), 2),
               round(sum(r['final_buy'] for r in out), 2),
               round(sum(r['up'] for r in out), 2), round(sum(r['dn'] for r in out), 2),
               round(sum(r['final_buy']-r['plan_buy'] for r in out), 2),
               round(sum(r['cost_adj'] for r in out), 2),
               round(sum(r['em_buy'] for r in out), 2), round(sum(r['cost_tot'] for r in out), 2)])
    for c in range(1, len(head)+1):
        ws.cell(ws.max_row, c).font = Font(bold=True); ws.cell(ws.max_row, c).border = bd
    widths = [12, 16, 16, 12, 12, 16, 14, 12, 14]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w
    ws.freeze_panes = 'A2'

    # 四指定日逐段差值
    for f in FOCUS:
        r = focus[f]
        Xp, Xf = np.array(r['Xp']), np.array(r['Xf']); diff = Xf-Xp
        ws2 = wb.create_sheet(f[5:].replace('-', ''))
        h2 = ['时间段', '计划购电量', '最终购电量', '差值', '方向']
        ws2.append(h2)
        for c in range(1, 6):
            cell = ws2.cell(1, c); cell.font = hf; cell.fill = hfill
            cell.alignment = Alignment(horizontal='center'); cell.border = bd
        for i in range(144):
            d = diff[i]
            way = '上调' if d > 1e-6 else ('下调' if d < -1e-6 else '不变')
            ws2.append([seg_label(i), round(Xp[i], 4), round(Xf[i], 4), round(d, 4), way])
            rr = ws2.max_row
            for c in range(1, 6):
                ws2.cell(rr, c).border = bd
            if d > 1e-6:
                ws2.cell(rr, 4).fill = up_fill
            elif d < -1e-6:
                ws2.cell(rr, 4).fill = dn_fill
        ws2.append(['合计', round(Xp.sum(), 4), round(Xf.sum(), 4), round(diff.sum(), 4), ''])
        for c in range(1, 6):
            ws2.cell(ws2.max_row, c).font = Font(bold=True)
        for col, w in zip('ABCDE', [14, 14, 14, 12, 8]):
            ws2.column_dimensions[col].width = w
        ws2.freeze_panes = 'A2'

    xlsx_path = os.path.join(OUTDIR, '购电量差值明细_Q3.xlsx')
    wb.save(xlsx_path)
    print('saved', xlsx_path)

    # 控制台打印四指定日全天差值
    print('\n四指定日全天差值（最终-计划）:')
    for f in FOCUS:
        r = focus[f]
        print('%s 计划%.1f 最终%.1f 上调%.1f 下调%.1f 净差%+.1f kWh 结算%+.1f元'
              % (f, r['plan_buy'], r['final_buy'], r['up'], r['dn'],
                 r['final_buy']-r['plan_buy'], r['cost_adj']))
    print('全年: 上调%.1f 下调%.1f 净差%+.1f kWh, 调整结算%+.1f元'
          % (sum(r['up'] for r in out), sum(r['dn'] for r in out),
             sum(r['final_buy']-r['plan_buy'] for r in out),
             sum(r['cost_adj'] for r in out)))


if __name__ == '__main__':
    main()
