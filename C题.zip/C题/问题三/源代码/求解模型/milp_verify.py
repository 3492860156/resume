# -*- coding: utf-8 -*-
"""
MILP 等价性验证：在 LP 中加入充放电互斥二进制 zc,zd∈{0,1}：
  c≤Emax·zc, d≤Emax·zd, zc+zd≤1
对 4 个指定日比较 LP 与 MILP 目标值，验证 LP 松弛无损（η=0.9 使 LP 解自然互斥）。
"""
import json
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds

from q3_common import (H, ETA, E_MAX, S_MIN, S_MAX, N, EMULT, DN_RATE, UP_RATE,
                       FOCUS, load_all, day_vector)
from solve_q3 import solve_plan, solve_adjust


def milp_plan(L, PV, price, s_init):
    """计划模型的 MILP 版本，返回目标值"""
    n = N
    nv = 7 * n + (n + 1)
    off = {'x': 0, 'c': n, 'd': 2 * n, 'u': 3 * n, 'e': 4 * n,
           'zc': 5 * n, 'zd': 6 * n, 'S': 7 * n}
    vid = lambda i, k: off[k] + i
    c_obj = np.zeros(nv)
    c_obj[off['x']:off['x'] + n] = price
    c_obj[off['e']:off['e'] + n] = EMULT * price
    rows, lb, ub = [], [], []
    for i in range(n):
        row = np.zeros(nv)
        row[vid(i, 'x')] = 1; row[vid(i, 'u')] = 1; row[vid(i, 'd')] = ETA
        row[vid(i, 'e')] = 1; row[vid(i, 'c')] = -1
        rows.append(row); lb.append(L[i]); ub.append(L[i])
    for i in range(n):
        row = np.zeros(nv)
        row[vid(i + 1, 'S')] = 1; row[vid(i, 'S')] = -1
        row[vid(i, 'c')] = -ETA; row[vid(i, 'd')] = 1
        rows.append(row); lb.append(0); ub.append(0)
    for i in range(n):                       # 互斥约束
        r1 = np.zeros(nv); r1[vid(i, 'c')] = 1; r1[vid(i, 'zc')] = -E_MAX
        rows.append(r1); lb.append(-np.inf); ub.append(0)
        r2 = np.zeros(nv); r2[vid(i, 'd')] = 1; r2[vid(i, 'zd')] = -E_MAX
        rows.append(r2); lb.append(-np.inf); ub.append(0)
        r3 = np.zeros(nv); r3[vid(i, 'zc')] = 1; r3[vid(i, 'zd')] = 1
        rows.append(r3); lb.append(-np.inf); ub.append(1)
    A = np.array(rows)
    lbb = np.zeros(nv); ubb = np.full(nv, np.inf)
    for i in range(n):
        lbb[vid(i, 'c')] = 0; ubb[vid(i, 'c')] = E_MAX
        lbb[vid(i, 'd')] = 0; ubb[vid(i, 'd')] = E_MAX
        lbb[vid(i, 'u')] = 0; ubb[vid(i, 'u')] = PV[i]
        lbb[vid(i, 'zc')] = 0; ubb[vid(i, 'zc')] = 1
        lbb[vid(i, 'zd')] = 0; ubb[vid(i, 'zd')] = 1
    for i in range(n + 1):
        lbb[vid(i, 'S')] = S_MIN; ubb[vid(i, 'S')] = S_MAX
    lbb[vid(0, 'S')] = ubb[vid(0, 'S')] = s_init
    integ = np.zeros(nv); integ[off['zc']:off['zc'] + n] = 1
    integ[off['zd']:off['zd'] + n] = 1
    res = milp(c_obj, constraints=LinearConstraint(A, np.array(lb), np.array(ub)),
               integrality=integ, bounds=Bounds(lbb, ubb))
    assert res.success, res.message
    return float(res.fun)


def lp_plan_obj(L, PV, price, s_init):
    X, C, D, U, E, S = solve_plan(L, PV, price, s_init)
    return float((price * (X + EMULT * E)).sum())


def main():
    data = load_all()
    price, load_m, pv_m, fc_m, dates = data
    j = json.load(open(r'D:\my\数学建模大赛\2026\2026国赛赛题\C题\问题三\数据\q3_full_results.json',
                       encoding='utf-8'))
    s0_map = {r['date']: r['s0'] for r in j['daily']}
    print('%-12s %-10s %-12s %-12s %s' % ('指定日', '模型', 'LP目标', 'MILP目标', '相对差'))
    max_gap = 0.0
    for f in FOCUS:
        d = list(str(x) for x in dates).index(f)
        L = day_vector(load_m, d) * H
        PVfc = fc_m[0, d] * H
        s0 = s0_map[f]
        lpv = lp_plan_obj(L, PVfc, price, s0)
        miv = milp_plan(L, PVfc, price, s0)
        gap = abs(lpv - miv) / max(abs(lpv), 1e-9)
        max_gap = max(max_gap, gap)
        print('%-12s %-10s %12.4f %12.4f %.2e' % (f, '0:00计划', lpv, miv, gap))
    print('\n最大相对差 %.2e（<1e-6 即 LP 松弛无损、无需 MILP）' % max_gap)


if __name__ == '__main__':
    main()
