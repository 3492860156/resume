# -*- coding: utf-8 -*-
"""
问题3 主求解：完整滚动模式跑全年 -> 缓存 JSON -> 填充 result3.xlsx -> 回读校验
"""
import os
import json
import datetime as dt
import numpy as np
import openpyxl

from q3_common import (H, ETA, N, FOCUS, BLOCK_NAMES, BLOCK_K, TPL3, OUTDIR,
                       load_all, day_vector)
from solve_q3 import simulate_day

OUT_XLSX = os.path.join(OUTDIR, 'result3.xlsx')
OUT_JSON = os.path.join(OUTDIR, '数据', 'q3_full_results.json')


def seg_time_label(a, b):
    """连续紧急购电段[a..b] -> 'HH:MM-HH:MM'；段i区间[(i+1)*10,(i+2)*10) 分钟"""
    s = (a + 1) * 10
    e = (b + 2) * 10

    def f(m):
        tag = '+1' if m >= 1440 else ''
        m = m % 1440
        return '%d:%02d%s' % (m // 60, m % 60, tag)
    return f(s) + '-' + f(e)


def merge_emergency(Eact, thr=1e-6):
    """把 e>thr 的连续段合并为 (时间段, 电量kWh) 列表，每段电量=e_i（已是kWh）"""
    out = []
    i = 0
    while i < N:
        if Eact[i] > thr:
            a = i
            while i + 1 < N and Eact[i + 1] > thr:
                i += 1
            b = i
            out.append((seg_time_label(a, b), float(Eact[a:b + 1].sum())))
        i += 1
    return out


def main():
    data = load_all()
    price, load_m, pv_m, fc_m, dates = data

    # ---------- 1. 完整模式全年求解 ----------
    recs = []
    s_init = 6000.0
    for d in range(365):
        L = day_vector(load_m, d) * H
        PVact = day_vector(pv_m, d) * H
        fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
        r = simulate_day(L, PVact, fc_day, price, s_init, stages=(36, 72, 108))
        r['date'] = str(dates[d]); r['d'] = d
        r['em_segs'] = merge_emergency(r['Eact'])
        recs.append(r)
        s_init = r['s24']
    out = recs[31:]
    print('完整模式 334 天：总费用 %.0f 元 | 紧急购电 %.1f kWh | 紧急费 %.0f 元'
          % (sum(r['cost_tot'] for r in out), sum(r['em_buy'] for r in out),
             sum(r['cost_em'] for r in out)))

    # ---------- 2. 缓存 JSON（标量+四指定日完整数组） ----------
    focus_full = {}
    for f in FOCUS:
        r = next(x for x in recs if x['date'] == f)
        focus_full[f] = {k: (v.tolist() if isinstance(v, np.ndarray) else v)
                         for k, v in r.items()}
    json.dump({
        'price_day': price.tolist(),
        'daily': [{k: v for k, v in r.items()
                   if not isinstance(v, np.ndarray) and k != 'em_segs'}
                  for r in recs],
        'em_segs': {r['date']: r['em_segs'] for r in recs},
        'focus_full': focus_full,
    }, open(OUT_JSON, 'w', encoding='utf-8'), ensure_ascii=False)
    print('已缓存', OUT_JSON)

    # ---------- 3. 填充 result3.xlsx ----------
    wb = openpyxl.load_workbook(TPL3)

    # 3.1 计划购电量 / 调整购电量
    for sheet, key_buy, key_cost in [
        ('计划购电量', 'Xp', 'cost_plan_paid'),
        ('调整购电量', 'Xf', 'cost_tot')]:
        ws = wb[sheet]
        for m, r in enumerate(out):
            row = 2 + m
            vec = r[key_buy]
            for k in range(N):
                ws.cell(row, 2 + k, round(float(vec[k]), 4))
            ws.cell(row, 146, round(float(vec.sum()), 4))
            ws.cell(row, 147, round(float(r[key_cost]), 2))

    # 3.2 充放电量（334×6=2004 行；块0 含前一日末段）
    ws2 = wb['充放电量']
    if ws2.max_row >= 2:
        ws2.delete_rows(2, ws2.max_row - 1)
    prev_recs = [recs[30]] + out[:-1]
    for m, r in enumerate(out):
        r0 = 2 + 6 * m
        dval = dt.datetime.strptime(r['date'], '%Y-%m-%d')
        prev = prev_recs[m]
        for bi in range(6):
            rr = r0 + bi
            ks, extra = BLOCK_K[bi]
            chg = float(r['Cf'][ks].sum())
            dis = float(r['Df'][ks].sum())
            if bi == 0:
                ws2.cell(rr, 1, dval).number_format = 'mm-dd-yy'
                ws2.cell(rr, 5, dt.time(0, 0))
                ws2.cell(rr, 6, round(r['s0'], 4))
                chg += float(prev['Cf'][extra]); dis += float(prev['Df'][extra])
            elif bi == 1:
                ws2.cell(rr, 5, '24:00')
                ws2.cell(rr, 6, round(r['s24'], 4))
            ws2.cell(rr, 2, BLOCK_NAMES[bi])
            ws2.cell(rr, 3, round(chg, 4)); ws2.cell(rr, 4, round(dis, 4))

    # 3.3 紧急购电量（按实际连续段动态展开，每天首行写日期）
    ws3 = wb['紧急购电量']
    if ws3.max_row >= 2:
        ws3.delete_rows(2, ws3.max_row - 1)
    rr = 2
    n_em_seg = 0
    for m, r in enumerate(out):
        dval = dt.datetime.strptime(r['date'], '%Y-%m-%d')
        segs = r['em_segs']
        if not segs:                          # 无紧急购电也保留日期行
            ws3.cell(rr, 1, dval).number_format = 'mm-dd-yy'
            rr += 1
            continue
        for si, (lab, q) in enumerate(segs):
            if si == 0:
                ws3.cell(rr, 1, dval).number_format = 'mm-dd-yy'
            ws3.cell(rr, 2, lab)
            ws3.cell(rr, 3, round(q, 4))
            rr += 1; n_em_seg += 1

    try:
        wb.save(OUT_XLSX)
        print('已保存', OUT_XLSX)
    except PermissionError:
        alt = OUT_XLSX.replace('.xlsx', '_副本.xlsx')
        wb.save(alt)
        print('原文件被占用，另存', alt)

    # ---------- 4. 回读校验 ----------
    chk = openpyxl.load_workbook(OUT_XLSX, data_only=True)
    c1, c2, c3, c4 = (chk['计划购电量'], chk['调整购电量'],
                      chk['充放电量'], chk['紧急购电量'])
    assert c1.max_row == 335 and c2.max_row == 335
    assert c3.max_row == 2005, c3.max_row
    n_dates = sum(1 for r in range(2, c4.max_row + 1) if c4.cell(r, 1).value is not None)
    assert n_dates == 334, n_dates
    n_em_expect = sum(len(r['em_segs']) for r in out)
    n_em_got = sum(1 for r in range(2, c4.max_row + 1) if c4.cell(r, 2).value)
    assert n_em_got == n_em_expect, (n_em_got, n_em_expect)
    d1 = [c1.cell(r, 1).value.date() for r in range(2, 336)]
    assert d1[0] == dt.date(2025, 2, 1) and d1[-1] == dt.date(2025, 12, 31)
    # 行和=全天购电量
    for r in range(2, 336):
        v = [c2.cell(r, 2 + k).value for k in range(N)]
        assert abs(sum(v) - c2.cell(r, 146).value) < 0.01
    # 无省略符
    for ws in (c1, c2, c3, c4):
        for row in ws.iter_rows(values_only=True):
            assert '⁝' not in row
    print('回读校验通过：计划/调整各334天、充放电2004行、紧急购电%d段全展开、无省略符' % n_em_got)


if __name__ == '__main__':
    main()
