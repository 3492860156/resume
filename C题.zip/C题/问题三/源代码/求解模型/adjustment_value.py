# -*- coding: utf-8 -*-
"""
调整必要性分析：比较 4 种调整模式全年结果
  M0 不调整（仅0:00计划） / M1 仅6点 / M2 6+12点 / M3 6+12+18点（完整）
量化每一级预报更新的边际价值，并验证 18 点预报对夜间无增量。
"""
import os
import json
import numpy as np
from q3_common import H, load_all, day_vector, OUTDIR
from solve_q3 import simulate_day

MODES = [('M0_不调整', ()), ('M1_仅6点', (36,)),
         ('M2_6+12点', (36, 72)), ('M3_6+12+18点', (36, 72, 108))]


def main():
    data = load_all()
    price, load_m, pv_m, fc_m, dates = data
    summary = {}
    for name, stages in MODES:
        s_init = 6000.0
        rows = []
        for d in range(365):
            L = day_vector(load_m, d) * H
            PVact = day_vector(pv_m, d) * H
            fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
            r = simulate_day(L, PVact, fc_day, price, s_init, stages=stages)
            r['date'] = str(dates[d])
            rows.append(r); s_init = r['s24']
        out = rows[31:]
        summary[name] = {
            '总费用': sum(r['cost_tot'] for r in out),
            '购电侧费用': sum(r['cost_buy'] for r in out),
            '紧急购电费用': sum(r['cost_em'] for r in out),
            '计划购电量': sum(r['plan_buy'] for r in out),
            '最终购电量': sum(r['final_buy'] for r in out),
            '上调量': sum(r['up'] for r in out),
            '下调量': sum(r['dn'] for r in out),
            '紧急购电量': sum(r['em_buy'] for r in out),
            '紧急购电天数': sum(1 for r in out if r['em_buy'] > 1e-6),
        }

    # 逐级边际节约
    names = [m[0] for m in MODES]
    base = summary[names[0]]['总费用']
    for i, name in enumerate(names):
        s = summary[name]
        s['相对不调整节约'] = base - s['总费用']
        s['节约比例%'] = 100 * (base - s['总费用']) / base
        if i > 0:
            prev = summary[names[i - 1]]['总费用']
            s['本级边际节约'] = prev - s['总费用']
        else:
            s['本级边际节约'] = 0.0

    out_json = os.path.join(OUTDIR, '数据', 'q3_mode_compare.json')
    json.dump(summary, open(out_json, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)

    print('%-16s %12s %12s %12s %12s %10s' %
          ('模式', '总费用(元)', '购电侧', '紧急费', '紧急电量', '节约%'))
    for name in names:
        s = summary[name]
        print('%-16s %12.0f %12.0f %12.0f %12.0f %9.2f%%'
              % (name, s['总费用'], s['购电侧费用'], s['紧急购电费用'],
                 s['紧急购电量'], s['节约比例%']))
    print('\n逐级边际节约（元）：')
    for name in names:
        print('  %-16s %.0f' % (name, summary[name]['本级边际节约']))
    print('\n已保存', out_json)


if __name__ == '__main__':
    main()
