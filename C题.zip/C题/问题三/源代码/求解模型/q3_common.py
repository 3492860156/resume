# -*- coding: utf-8 -*-
"""
2026 国赛 C 题 · 问题 3 —— 公共数据模块
=========================================
职责：
  1) 读取附件1电价、附件2负载/实际光伏、附件3光伏预报；
  2) 统一时间口径（沿用问题2）：列时间 t 代表 10 分钟区间 [t-10min, t)（结束时刻标注）；
     当日行向量 v[0..142] 取当日第 2..144 列，v[143] 取次日首列（跨午夜）；
  3) 附件3预报展开：每天 0/6/12/18 点发布，每次给未来24个“整点小时”预报，
     预报 k 小时 = 发布时刻起第 k 个小时段 [m+k-1:00, m+k:00)（全年对齐 MAE 验证最优），
     按 hold（零阶保持）展开到 144 个 10 分钟段：同一小时内 6 段共用该小时预报值。
"""
import os
import numpy as np
import pandas as pd

# ----------------------------- 路径 -----------------------------
ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
ATT1 = os.path.join(ROOT, '附件', '附件1.xlsx')
ATT2 = os.path.join(ROOT, '附件', '附件2.xlsx')
ATT3 = os.path.join(ROOT, '附件', '附件3.xlsx')
TPL3 = os.path.join(ROOT, '附件', '附件5', 'result3.xlsx')
OUTDIR = os.path.join(ROOT, '问题三')

# ----------------------------- 物理常量（附录1） -----------------------------
H = 1.0 / 6.0        # 10 分钟 = 1/6 小时
ETA = 0.9            # 充/放电效率
P_MAX = 5000.0       # 最大充放电功率 kW
E_MAX = P_MAX * H    # 每段最大充/放电量 kWh = 833.3333
S_MIN, S_MAX = 1200.0, 10800.0
S_INIT = 6000.0      # 2025-01-01 0:00 储电量
N = 144
EMULT = 5.0          # 紧急购电倍数
PUB_HOURS = [0, 6, 12, 18]          # 预报发布时刻（小时）
PUB_IDX = [h * 6 for h in PUB_HOURS]  # 对应段下标 0/36/72/108
DN_RATE, UP_RATE = 0.5, 1.5         # 下调违约 0.5P、上调溢价 1.5P

FOCUS = ['2025-03-20', '2025-06-21', '2025-09-23', '2025-12-21']
BLOCK_NAMES = ['0:00-4:00', '4:00-8:00', '8:00-12:00', '12:00-16:00',
               '16:00-20:00', '20:00-24:00']
# 块 b 在当日行向量中的段下标（块0 特殊：含前一日末段 i=143 + 当日 0..22）
BLOCK_K = [(list(range(0, 23)), 143), (list(range(23, 47)), None),
           (list(range(47, 71)), None), (list(range(71, 95)), None),
           (list(range(95, 119)), None), (list(range(119, 143)), None)]
T1_SPECS = [('10:00-10:10', 59), ('12:00-12:10', 71), ('14:00-14:10', 83),
            ('16:00-16:10', 95), ('18:00-18:10', 107), ('20:00-20:10', 119)]


# ----------------------------- 数据读取 -----------------------------
def load_all():
    """返回 price_day(144,), load_mat(365,144), pv_mat(365,144), fc_mat(4,365,144), dates"""
    att1 = pd.read_excel(ATT1)
    assert len(att1) == 144
    price_raw = att1['电价'].to_numpy(float)
    price_day = np.concatenate([price_raw[1:], price_raw[:1]])  # 与模板列序对齐

    load_df = pd.read_excel(ATT2, sheet_name='小区负载')
    pv_df = pd.read_excel(ATT2, sheet_name='光伏发电实际功率')
    load_mat = load_df.iloc[:, 1:].to_numpy(float)
    pv_mat = pv_df.iloc[:, 1:].to_numpy(float)
    assert load_mat.shape == (365, 144) and pv_mat.shape == (365, 144)
    dates = pd.to_datetime(load_df.iloc[:, 0]).dt.date.to_numpy()

    fc_mat = build_forecast_matrix()
    return price_day, load_mat, pv_mat, fc_mat, dates


def day_vector(mat, d):
    """当日行向量：v[0..142]=当日第2..144列；v[143]=次日首列（12/31 用当日末列近似）"""
    v = np.empty(N)
    v[:N - 1] = mat[d, 1:N]
    v[N - 1] = mat[d + 1, 0] if d + 1 < 365 else mat[d, N - 1]
    return v


def build_forecast_matrix():
    """
    解析附件3，返回 fc_mat shape=(4, 365, 144)：
      fc_mat[j, d, i] = 第 d 天、第 j 个发布时刻(0/6/12/18点)的预报
                        在当日第 i 个 10 分钟段上的光伏功率(kW, hold 展开)
    段 i 的绝对小时 ah = i//6（i=143 -> 24，即次日 0:00）；
    发布小时 m，对应预报列序号 = ah - m（预报k小时 k=ah-m+1 -> 数组下标 ah-m），
    越界（历史段 / 超出24h）取 0（均为夜间无光伏时段）。
    """
    a3 = pd.read_excel(ATT3)
    a3['日期'] = a3['日期'].ffill()
    fc_cols = [f'预报{i}小时' for i in range(1, 25)]
    a3['d'] = pd.to_datetime(a3['日期']).dt.dayofyear - 1
    fc_mat = np.zeros((4, 365, N))
    for j, m in enumerate(PUB_HOURS):
        sub = a3[a3['预报时刻'] == f'{m}:00']
        for _, r in sub.iterrows():
            d = int(r['d'])
            fv = r[fc_cols].to_numpy(float)          # 24 个小时预报
            for i in range(N):
                ah = i // 6 if i < N - 1 else 24     # 段 i 对应绝对小时
                idx = ah - m                         # = k-1
                if 0 <= idx <= 23:
                    # 次日小时需要次日发布行；当天发布行只覆盖到 m+23，越界置 0
                    if ah >= 24 and idx > 23:
                        continue
                    fc_mat[j, d, i] = fv[idx]
    return fc_mat


if __name__ == '__main__':
    price, load_m, pv_m, fc_m, dates = load_all()
    print('电价(144):', price.shape, '负载/实际光伏:', load_m.shape, pv_m.shape)
    print('预报矩阵 (4发布,365天,144段):', fc_m.shape)
    # 校验 1月1日 0:00 发布：8:00-9:00 六段应=预报9小时=3409.0929
    v = fc_m[0, 0, 48:54]
    print('1/1 0点发布 8:00-9:00 六段:', np.round(v, 3), '(应全为 3409.093)')
    # 6:00 发布覆盖 6:00-24:00，0:00-6:00 应为 0
    print('1/1 6点发布 0-6点段和(应0):', fc_m[1, 0, :36].sum())
    print('1/1 6点发布 6-7点段:', np.round(fc_m[1, 0, 36:42], 2), '(应=预报1小时3.09)')
    # 与实际光伏对比形状（1/1 白天）
    actual_h = pv_m[0].reshape(24, 6).mean(axis=1)
    fc_h = fc_m[0, 0].reshape(24, 6).mean(axis=1)
    cmp = np.c_[np.arange(24), actual_h.round(1), fc_h.round(1)][7:17]
    print('小时  实际  0点预报 (7-16时):')
    print(cmp)
