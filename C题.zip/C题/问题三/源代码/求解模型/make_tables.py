# -*- coding: utf-8 -*-
"""生成问题3指定日期论文表格（表1购电量 / 表2充放电量 / 表3紧急购电量），输出 Markdown。"""
import os
import json
import numpy as np
from q3_common import (H, ETA, FOCUS, BLOCK_NAMES, BLOCK_K, T1_SPECS,
                       OUTDIR, load_all, day_vector)
from solve_q3 import simulate_day


def block_cd(Cf, Df, bi, prev_cd=None):
    ks, extra = BLOCK_K[bi]
    c = float(Cf[ks].sum()); d = float(Df[ks].sum())
    if bi == 0 and prev_cd is not None:
        c += float(prev_cd[0]); d += float(prev_cd[1])
    return c, d


def main():
    data = load_all()
    price, load_m, pv_m, fc_m, dates = data
    j = json.load(open(os.path.join(OUTDIR, '数据', 'q3_full_results.json'), encoding='utf-8'))
    s0_map = {r['date']: r['s0'] for r in j['daily']}
    em_map = j['em_segs']
    dstr = [str(x) for x in dates]

    lines = ['# 问题3 论文表格数据（4 个指定日期）\n']
    for f in FOCUS:
        di = dstr.index(f)
        s0 = s0_map[f]
        L = day_vector(load_m, di) * H
        PVact = day_vector(pv_m, di) * H
        fc_day = np.stack([fc_m[jj, di] * H for jj in range(4)])
        r = simulate_day(L, PVact, fc_day, price, s0, stages=(36, 72, 108))
        # 前一日末段（块0口径）
        prev = day_vector(load_m, di - 1) * H
        pv_prev = day_vector(pv_m, di - 1) * H
        fc_prev = np.stack([fc_m[jj, di - 1] * H for jj in range(4)])
        rp = simulate_day(prev, pv_prev, fc_prev, price,
                          j['daily'][di - 1]['s0'], stages=(36, 72, 108))
        prev_cd = (rp['Cf'][143], rp['Df'][143])

        lines.append('\n## %s\n' % f)
        # 表1：指定时间段 计划 vs 最终购电量
        lines.append('### 表1 指定时间段购电量（计划 / 最终调整，kWh）\n')
        lines.append('| 时间段 | 计划购电量 | 最终购电量 | 时间段 | 计划购电量 | 最终购电量 |')
        lines.append('|---|---|---|---|---|---|')
        for i in range(0, 6, 2):
            n1, k1 = T1_SPECS[i]; n2, k2 = T1_SPECS[i + 1]
            lines.append('| %s | %.4f | %.4f | %s | %.4f | %.4f |'
                         % (n1, r['Xp'][k1], r['Xf'][k1], n2, r['Xp'][k2], r['Xf'][k2]))
        lines.append('\n- 计划全天购电量 **%.2f kWh**；最终全天购电量 **%.2f kWh**'
                     % (r['plan_buy'], r['final_buy']))
        lines.append('- 全天购电费：计划 **%.2f 元**；最终（含调整结算与紧急购电）**%.2f 元**'
                     % (r['cost_plan_paid'], r['cost_tot']))
        lines.append('  - 其中 调整结算 %.2f 元、紧急购电费 %.2f 元（紧急购电 %.2f kWh）\n'
                     % (r['cost_adj'], r['cost_em'], r['em_buy']))

        # 表2：充放电量
        lines.append('### 表2 储能指定时间段充放电量（最终，kWh）\n')
        lines.append('| 时间段 | 充电量 | 放电量 | 时间段 | 充电量 | 放电量 |')
        lines.append('|---|---|---|---|---|---|')
        for i in range(0, 6, 2):
            c1, d1 = block_cd(r['Cf'], r['Df'], i, prev_cd)
            c2, d2 = block_cd(r['Cf'], r['Df'], i + 1, prev_cd)
            lines.append('| %s | %.2f | %.2f | %s | %.2f | %.2f |'
                         % (BLOCK_NAMES[i], c1, d1, BLOCK_NAMES[i + 1], c2, d2))
        lines.append('\n0:00 储电量 **%.2f kWh**；24:00 储电量 **%.2f kWh**\n'
                     % (r['s0'], r['s24']))

        # 表3：紧急购电
        lines.append('### 表3 紧急购电量（时间段 / kWh）\n')
        segs = em_map[f]
        lines.append('| 时间段 | 购电量 |')
        lines.append('|---|---|')
        for lab, q in segs:
            lines.append('| %s | %.2f |' % (lab, q))
        lines.append('\n> 共 %d 段，合计 %.2f kWh\n' % (len(segs), r['em_buy']))

    out_md = os.path.join(OUTDIR, '文档资料', '论文表格数据_Q3.md')
    os.makedirs(os.path.dirname(out_md), exist_ok=True)
    open(out_md, 'w', encoding='utf-8').write('\n'.join(lines))
    print('已生成', out_md)
    print('\n'.join(lines[:40]))


if __name__ == '__main__':
    main()
