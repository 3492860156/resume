# -*- coding: utf-8 -*-
"""问题3 全年结果汇总统计：输出报告所需全部数字，并存 JSON。"""
import os
import json
import numpy as np
from q3_common import H, ETA, OUTDIR, load_all, day_vector
from solve_q3 import simulate_day

data = load_all()
price, load_m, pv_m, fc_m, dates = data
j = json.load(open(os.path.join(OUTDIR, '数据', 'q3_full_results.json'), encoding='utf-8'))
daily = j['daily']; out = daily[31:]; focus = j['focus_full']

S = {}
# 全年总量
S['全年总费用'] = sum(r['cost_tot'] for r in out)
S['购电侧费用'] = sum(r['cost_buy'] for r in out)
S['紧急购电费用'] = sum(r['cost_em'] for r in out)
S['计划购电量'] = sum(r['plan_buy'] for r in out)
S['最终购电量'] = sum(r['final_buy'] for r in out)
S['上调总量'] = sum(r['up'] for r in out)
S['下调总量'] = sum(r['dn'] for r in out)
S['紧急购电量'] = sum(r['em_buy'] for r in out)
S['紧急购电天数'] = sum(1 for r in out if r['em_buy'] > 1e-6)
S['天数'] = len(out)
# 负载与光伏实际总量（能量平衡核对）
load_E = sum(day_vector(load_m, d).sum() * H for d in range(31, 365))
pv_E = sum(day_vector(pv_m, d).sum() * H for d in range(31, 365))
S['小区负载总量'] = load_E
S['实际光伏总量'] = pv_E
# 充放电全年
# 可行性：重算收集 SOC/同时充放/互斥/母线残差
s_init = 6000.0; soc_min, soc_max = 1e9, -1e9
n_cd = n_ud = 0; maxbal = 0
for d in range(365):
    L = day_vector(load_m, d) * H; PVact = day_vector(pv_m, d) * H
    fc_day = np.stack([fc_m[k, d] * H for k in range(4)])
    r = simulate_day(L, PVact, fc_day, price, s_init, stages=(36, 72, 108)); s_init = r['s24']
    if d >= 31:
        soc_min = min(soc_min, r['Sf'].min()); soc_max = max(soc_max, r['Sf'].max())
        n_cd += int(((r['Cf'] > 1e-6) & (r['Df'] > 1e-6)).sum())
        upm = np.maximum(r['Xf'] - r['Xp'], 0); dnm = np.maximum(r['Xp'] - r['Xf'], 0)
        n_ud += int(((upm > 1e-6) & (dnm > 1e-6)).sum())
        bal = L + r['Cf'] - r['Xf'] - ETA * r['Df'] - r['Uact'] - r['Eact']
        maxbal = max(maxbal, abs(bal).max())
S['SOC_min'] = soc_min; S['SOC_max'] = soc_max; S['年末SOC'] = s_init
S['同时充放段数'] = n_cd; S['上下调同正段数'] = n_ud; S['母线最大残差'] = maxbal
# 四指定日
S['指定日'] = {}
for f, r in focus.items():
    S['指定日'][f] = {k: r[k] for k in
        ['s0', 's24', 'plan_buy', 'final_buy', 'up', 'dn', 'em_buy',
         'cost_plan_paid', 'cost_buy', 'cost_adj', 'cost_em', 'cost_tot']}
# 月度
S['月度'] = {}
for m in range(2, 13):
    rs = [r for r in out if int(r['date'][5:7]) == m]
    S['月度']['%d月' % m] = {
        '总费用': sum(r['cost_tot'] for r in rs),
        '紧急电量': sum(r['em_buy'] for r in rs),
        '紧急费': sum(r['cost_em'] for r in rs)}

json.dump(S, open(os.path.join(OUTDIR, '数据', 'q3_stats_summary.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

print('===== 全年（334天）=====')
for k in ['全年总费用', '购电侧费用', '紧急购电费用', '计划购电量', '最终购电量',
          '上调总量', '下调总量', '紧急购电量', '小区负载总量', '实际光伏总量']:
    print('%-12s %.2f' % (k, S[k]))
print('紧急购电天数 %d/%d' % (S['紧急购电天数'], S['天数']))
print('SOC [%.2f, %.2f], 年末 %.2f' % (S['SOC_min'], S['SOC_max'], S['年末SOC']))
print('同时充放 %d, 上下调同正 %d, 母线残差 %.2e'
      % (S['同时充放段数'], S['上下调同正段数'], S['母线最大残差']))
print('\n===== 四指定日 =====')
for f, v in S['指定日'].items():
    print(f, '计划购%.1f 最终购%.1f 紧急%.1f 总费%.1f'
          % (v['plan_buy'], v['final_buy'], v['em_buy'], v['cost_tot']))
