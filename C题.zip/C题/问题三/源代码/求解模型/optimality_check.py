# -*- coding: utf-8 -*-
"""
最优性严格验证
A. 全年 365 天 × (1 计划 + 3 调整) = 1460 个 LP 的求解状态（必须全部 optimal）+ 可行性残差
B. 4 指定日：highs(默认) / highs-ds(对偶单纯形) / highs-ipm(内点) 三种独立算法目标值交叉比对
C. 多最优检测：不同算法目标相同但调度不同 → 费用最优值仍唯一
"""
import numpy as np
from scipy.optimize import linprog
from q3_common import (H, ETA, E_MAX, S_MIN, S_MAX, N, EMULT, DN_RATE, UP_RATE,
                       FOCUS, load_all, day_vector)
from solve_q3 import solve_plan


def build_lp(L, PV, price, s_init, Qp=None, i0=0):
    """构造计划(Qp=None,全天)或调整窗口[i0,144) LP。"""
    if Qp is None:
        n = N; nv = 5*n + (n+1)
        off = {'x': 0, 'c': n, 'd': 2*n, 'u': 3*n, 'e': 4*n, 'S': 5*n}
        Lw, PVw, Pw, Qw = L, PV, price, None
    else:
        n = N-i0; nv = 7*n + (n+1)
        off = {'x': 0, 'c': n, 'd': 2*n, 'u': 3*n, 'e': 4*n,
               'up': 5*n, 'dn': 6*n, 'S': 7*n}
        Lw, PVw, Pw, Qw = L[i0:], PV[i0:], price[i0:], Qp[i0:]
    vid = lambda i, k: off[k]+i
    c = np.zeros(nv)
    if Qw is None:
        c[off['x']:off['x']+n] = Pw
        c[off['e']:off['e']+n] = EMULT*Pw
    else:
        c[off['dn']:off['dn']+n] = -DN_RATE*Pw
        c[off['up']:off['up']+n] = UP_RATE*Pw
        c[off['e']:off['e']+n] = EMULT*Pw
    neq = 2*n if Qw is None else 3*n
    A = np.zeros((neq, nv)); b = np.zeros(neq)
    for i in range(n):
        A[i, vid(i, 'x')] = 1; A[i, vid(i, 'u')] = 1
        A[i, vid(i, 'd')] = ETA; A[i, vid(i, 'e')] = 1
        A[i, vid(i, 'c')] = -1; b[i] = Lw[i]
    for i in range(n):
        A[n+i, vid(i+1, 'S')] = 1; A[n+i, vid(i, 'S')] = -1
        A[n+i, vid(i, 'c')] = -ETA; A[n+i, vid(i, 'd')] = 1
    if Qw is not None:
        for i in range(n):
            A[2*n+i, vid(i, 'x')] = 1
            A[2*n+i, vid(i, 'up')] = -1
            A[2*n+i, vid(i, 'dn')] = 1
            b[2*n+i] = Qw[i]
    bd = [(0.0, None)]*nv
    for i in range(n):
        bd[vid(i, 'c')] = (0, E_MAX); bd[vid(i, 'd')] = (0, E_MAX)
        bd[vid(i, 'u')] = (0, PVw[i])
    for i in range(n+1):
        bd[vid(i, 'S')] = (S_MIN, S_MAX)
    bd[vid(0, 'S')] = (s_init, s_init)
    lb = np.array([x[0] for x in bd])
    ub = np.array([x[1] if x[1] is not None else np.inf for x in bd])
    return c, A, b, lb, ub


def solve_one(c, A, b, lb, ub, method):
    res = linprog(c, A_eq=A, b_eq=b, bounds=list(zip(lb, ub)), method=method)
    if not res.success:
        return None
    return {'fun': float(res.fun), 'x': res.x,
            'eq_res': float(abs(A @ res.x - b).max()),
            'bv': float(max(abs(np.minimum(res.x-lb, 0)).max(),
                           abs(np.minimum(ub-res.x, 0)).max()))}


def main():
    data = load_all()
    price, load_m, pv_m, fc_m, dates = data

    # A. 全年 1460 LP 状态 + 可行性
    print('A. 全年 LP 求解状态与可行性核查')
    s_init = 6000.0; total = 0; fail = 0; max_eq = 0.0; max_bv = 0.0
    for d in range(365):
        L = day_vector(load_m, d)*H
        c, A, b, lb, ub = build_lp(L, fc_m[0, d]*H, price, s_init)
        r = solve_one(c, A, b, lb, ub, 'highs'); total += 1
        if r is None: fail += 1; continue
        max_eq = max(max_eq, r['eq_res']); max_bv = max(max_bv, r['bv'])
        Xp = r['x'][:N]; Ccur = r['x'][N:2*N]; Dcur = r['x'][2*N:3*N]
        Sp = r['x'][5*N:]
        for k, i0 in enumerate((36, 72, 108)):
            s_i0 = s_init + float((ETA*Ccur[:i0]-Dcur[:i0]).sum())
            c, A, b, lb, ub = build_lp(L, fc_m[k+1, d]*H, price, s_i0, Xp, i0)
            rr = solve_one(c, A, b, lb, ub, 'highs'); total += 1
            if rr is None: fail += 1; continue
            max_eq = max(max_eq, rr['eq_res']); max_bv = max(max_bv, rr['bv'])
            n = N-i0
            Ccur[i0:], Dcur[i0:] = rr['x'][n:2*n], rr['x'][2*n:3*n]
        s_init = float(Sp[N])
    print('  共 %d 个 LP，失败 %d；等式最大残差 %.2e；变量界最大违反 %.2e'
          % (total, fail, max_eq, max_bv))

    # 用正式 json 的 s0（与主结果一致）
    import json, os
    from q3_common import OUTDIR
    j = json.load(open(os.path.join(OUTDIR, '数据', 'q3_full_results.json'), encoding='utf-8'))
    s0_map = {r['date']: r['s0'] for r in j['daily']}

    # B. 三算法交叉
    print('\nB. 四指定日 三种独立算法目标值交叉比对')
    methods = ['highs', 'highs-ds', 'highs-ipm']
    worst = 0.0; multi = 0
    for f in FOCUS:
        di = list(str(x) for x in dates).index(f)
        L = day_vector(load_m, di)*H
        Xp, Cp, Dp, _, _, _ = solve_plan(L, fc_m[0, di]*H, price, s0_map[f])
        cases = [('计划', fc_m[0, di]*H, s0_map[f], None, 0)]
        for k, i0 in enumerate((36, 72, 108)):
            s_i0 = s0_map[f] + float((ETA*Cp[:i0]-Dp[:i0]).sum())
            cases.append(('调整@%d' % i0, fc_m[k+1, di]*H, s_i0, Xp, i0))
        for name, PVc, s0c, Qpc, i0c in cases:
            c, A, b, lb, ub = build_lp(L, PVc, price, s0c, Qpc, i0c)
            rs = [solve_one(c, A, b, lb, ub, m) for m in methods]
            if any(x is None for x in rs):
                print('  %s %s 存在失败!' % (f, name)); continue
            objs = [x['fun'] for x in rs]
            g = max(objs)-min(objs)
            worst = max(worst, abs(g)/max(abs(min(objs)), 1e-9))
            if abs(rs[0]['x']-rs[2]['x']).max() > 1e-4 and abs(g) < 1e-6:
                multi += 1
            print('  %s %-7s highs=%12.6f ds=%12.6f ipm=%12.6f 极差%.2e'
                  % (f, name, objs[0], objs[1], objs[2], g))
    print('\n三算法目标值最大相对差 %.2e；多最优调度LP数 %d（目标值仍唯一）' % (worst, multi))


if __name__ == '__main__':
    main()
