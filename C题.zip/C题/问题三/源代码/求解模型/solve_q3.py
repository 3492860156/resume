# -*- coding: utf-8 -*-
"""
2026 国赛 C 题 · 问题 3 —— 两阶段滚动购电策略求解器
=====================================================
决策结构：
  阶段1（0:00 计划）：用 0:00 发布的 24h 光伏预报求解全天确定性 LP，得计划购电量 Qp；
  阶段2（6/12/18 点滚动调整）：用最新预报对剩余时段重解，调整惩罚分段线性化：
        令上调量 up>=0、下调量 dn>=0，满足 xa = Qp + up - dn；
        购电费用 = Qp·P - 0.5P·dn + 1.5P·up（凸分段线性，LP 自动保证 up·dn=0）；
  执行核验：最终策略下用附件2 实际光伏核验，缺口按 5P 紧急购电。
储能：η=0.9，SOC∈[1200,10800]，充放功率≤5000kW，跨天连续递推（1月预热）。
"""
import os
import json
import numpy as np
from scipy.optimize import linprog

from q3_common import (H, ETA, E_MAX, S_MIN, S_MAX, S_INIT, N, EMULT,
                       DN_RATE, UP_RATE, PUB_IDX, FOCUS,
                       load_all, day_vector)


# ------------------------- 阶段1：0:00 全天计划 LP -------------------------
def solve_plan(L, PV, price, s_init):
    """变量顺序 x|c|d|u|e|S；L/PV 已为 kWh。返回各变量(段)与 S(145 点)。"""
    nv = 5 * N + (N + 1)
    off = {'x': 0, 'c': N, 'd': 2 * N, 'u': 3 * N, 'e': 4 * N, 'S': 5 * N}
    vid = lambda i, k: off[k] + i
    c_obj = np.zeros(nv)
    c_obj[off['x']:off['x'] + N] = price
    c_obj[off['e']:off['e'] + N] = EMULT * price

    A_eq = np.zeros((2 * N, nv)); b_eq = np.zeros(2 * N)
    for i in range(N):                       # 母线：x+u+ηd+e-c = L
        A_eq[i, vid(i, 'x')] = 1; A_eq[i, vid(i, 'u')] = 1
        A_eq[i, vid(i, 'd')] = ETA; A_eq[i, vid(i, 'e')] = 1
        A_eq[i, vid(i, 'c')] = -1; b_eq[i] = L[i]
    for i in range(N):                       # 递推：S_{i+1}-S_i-ηc+d=0
        A_eq[N + i, vid(i + 1, 'S')] = 1; A_eq[N + i, vid(i, 'S')] = -1
        A_eq[N + i, vid(i, 'c')] = -ETA; A_eq[N + i, vid(i, 'd')] = 1

    bounds = [(0.0, None)] * nv
    for i in range(N):
        bounds[vid(i, 'c')] = (0, E_MAX); bounds[vid(i, 'd')] = (0, E_MAX)
        bounds[vid(i, 'u')] = (0, PV[i])
    for i in range(N + 1):
        bounds[vid(i, 'S')] = (S_MIN, S_MAX)
    bounds[vid(0, 'S')] = (s_init, s_init)

    res = linprog(c_obj, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('计划 LP 失败: %s' % res.message)
    g = lambda k: res.x[off[k]:off[k] + N]
    X, C, D, U, E = g('x'), g('c'), g('d'), g('u'), g('e')
    S = res.x[off['S']:off['S'] + N + 1]
    return X, C, D, U, E, S


# --------------------- 阶段2：窗口滚动调整 LP（i0..143） ---------------------
def solve_adjust(L, PV, price, s_start, Qp, i0):
    """
    对 [i0,144) 段重优化；历史段固定。窗口 n=144-i0。
    变量 xa|ca|da|ua|ea|up|dn 各 n，Sa(n+1)。
    """
    n = N - i0
    Lw, PVw, Pw, Qw = L[i0:], PV[i0:], price[i0:], Qp[i0:]
    nv = 7 * n + (n + 1)
    off = {'x': 0, 'c': n, 'd': 2 * n, 'u': 3 * n, 'e': 4 * n,
           'up': 5 * n, 'dn': 6 * n, 'S': 7 * n}
    vid = lambda i, k: off[k] + i
    c_obj = np.zeros(nv)
    # 常数项 Qp·P 省略；-0.5P·dn +1.5P·up +5P·e
    c_obj[off['dn']:off['dn'] + n] = -DN_RATE * Pw
    c_obj[off['up']:off['up'] + n] = UP_RATE * Pw
    c_obj[off['e']:off['e'] + n] = EMULT * Pw

    A_eq = np.zeros((3 * n, nv)); b_eq = np.zeros(3 * n)
    for i in range(n):                       # 母线
        A_eq[i, vid(i, 'x')] = 1; A_eq[i, vid(i, 'u')] = 1
        A_eq[i, vid(i, 'd')] = ETA; A_eq[i, vid(i, 'e')] = 1
        A_eq[i, vid(i, 'c')] = -1; b_eq[i] = Lw[i]
    for i in range(n):                       # 储能递推
        A_eq[n + i, vid(i + 1, 'S')] = 1; A_eq[n + i, vid(i, 'S')] = -1
        A_eq[n + i, vid(i, 'c')] = -ETA; A_eq[n + i, vid(i, 'd')] = 1
    for i in range(n):                       # xa - up + dn = Qp
        A_eq[2 * n + i, vid(i, 'x')] = 1
        A_eq[2 * n + i, vid(i, 'up')] = -1
        A_eq[2 * n + i, vid(i, 'dn')] = 1
        b_eq[2 * n + i] = Qw[i]

    bounds = [(0.0, None)] * nv
    for i in range(n):
        bounds[vid(i, 'c')] = (0, E_MAX); bounds[vid(i, 'd')] = (0, E_MAX)
        bounds[vid(i, 'u')] = (0, PVw[i])
    for i in range(n + 1):
        bounds[vid(i, 'S')] = (S_MIN, S_MAX)
    bounds[vid(0, 'S')] = (s_start, s_start)

    res = linprog(c_obj, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('调整 LP(i0=%d) 失败: %s' % (i0, res.message))
    g = lambda k: res.x[off[k]:off[k] + n]
    return g('x'), g('c'), g('d'), g('u'), g('e'), g('up'), g('dn'), \
        res.x[off['S']:off['S'] + n + 1]


# ------------------------- 单日完整滚动模拟 -------------------------
def simulate_day(L, PVact, fc_day, price, s_init, stages=(36, 72, 108)):
    """
    L/PVact: 当日负载/实际光伏能量(kWh,144)；fc_day: (4,144) 四次预报能量。
    stages: 启用的调整起点段下标集合；() 表示只用 0:00 计划不调整。
    """
    # 阶段1
    Xp, Cp, Dp, Up, Ep, Sp = solve_plan(L, fc_day[0], price, s_init)
    Xf, Cf, Df = Xp.copy(), Cp.copy(), Dp.copy()
    adj_log = []
    # 阶段2 滚动
    for j, i0 in zip((1, 2, 3), (36, 72, 108)):
        if i0 not in stages:
            continue
        s_i0 = s_init + float((ETA * Cf[:i0] - Df[:i0]).sum())
        xa, ca, da, ua, ea, upv, dnv, Sa = solve_adjust(
            L, fc_day[j], price, s_i0, Xp, i0)
        # 记录本次调整量（相对当前执行值）
        adj_log.append({
            'at': i0,
            'chg_buy': float(xa.sum() - Xf[i0:].sum()),
            'up': float(upv.sum()), 'dn': float(dnv.sum())})
        Xf[i0:], Cf[i0:], Df[i0:] = xa, ca, da

    # 执行核验（实际光伏）
    gap = L + Cf - Xf - ETA * Df                       # 需光伏/紧急填补的量(>=0)
    Uact = np.minimum(PVact, np.maximum(gap, 0.0))
    Eact = np.maximum(gap - PVact, 0.0)
    # 最终 SOC 轨迹（按最终充放电）
    Sf = np.empty(N + 1); Sf[0] = s_init
    Sf[1:] = s_init + np.cumsum(ETA * Cf - Df)
    s_next = float(Sf[N])

    # 费用核算
    dn_f = np.maximum(Xp - Xf, 0.0); up_f = np.maximum(Xf - Xp, 0.0)
    cost_plan_paid = float((price * Xp).sum())         # 计划购电费用(按计划量)
    cost_adj = float((-DN_RATE * price * dn_f + UP_RATE * price * up_f).sum())
    cost_em = float((EMULT * price * Eact).sum())
    cost_buy = cost_plan_paid + cost_adj               # 购电侧费用(含调整结算)
    cost_tot = cost_buy + cost_em

    return {
        'Xp': Xp, 'Cp': Cp, 'Dp': Dp, 'Sp': Sp,
        'Xf': Xf, 'Cf': Cf, 'Df': Df, 'Sf': Sf,
        'Uact': Uact, 'Eact': Eact,
        'plan_buy': float(Xp.sum()), 'final_buy': float(Xf.sum()),
        'up': float(up_f.sum()), 'dn': float(dn_f.sum()),
        'em_buy': float(Eact.sum()),
        'cost_plan_paid': cost_plan_paid, 'cost_adj': cost_adj,
        'cost_buy': cost_buy, 'cost_em': cost_em, 'cost_tot': cost_tot,
        's0': float(s_init), 's24': s_next, 'adj_log': adj_log,
    }


def run_year(stages=(36, 72, 108), data=None, verbose=True):
    if data is None:
        data = load_all()
    price, load_m, pv_m, fc_m, dates = data
    recs = []
    s_init = S_INIT
    for d in range(365):
        L = day_vector(load_m, d) * H
        PVact = day_vector(pv_m, d) * H
        fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
        r = simulate_day(L, PVact, fc_day, price, s_init, stages=stages)
        r['date'] = str(dates[d]); r['d'] = d
        recs.append(r)
        s_init = r['s24']
        # 可行性自检
        assert r['Sf'].min() >= S_MIN - 1e-5 and r['Sf'].max() <= S_MAX + 1e-5
        bal = L + r['Cf'] - r['Xf'] - ETA * r['Df'] - r['Uact'] - r['Eact']
        assert abs(bal).max() < 1e-5
    if verbose:
        out = recs[31:]
        print('模式 stages=%s | 输出区间334天:' % (stages,))
        print('  计划购电 %.0f kWh | 最终购电 %.0f kWh | 上调 %.0f 下调 %.0f | 紧急 %.1f kWh'
              % (sum(r['plan_buy'] for r in out), sum(r['final_buy'] for r in out),
                 sum(r['up'] for r in out), sum(r['dn'] for r in out),
                 sum(r['em_buy'] for r in out)))
        print('  购电侧费用 %.0f 元 | 紧急费用 %.0f 元 | 总费用 %.0f 元'
              % (sum(r['cost_buy'] for r in out), sum(r['cost_em'] for r in out),
                 sum(r['cost_tot'] for r in out)))
    return recs


if __name__ == '__main__':
    data = load_all()
    print('==== 四种调整模式全年对比 ====')
    for name, st in [('不调整', ()), ('仅6点', (36,)),
                     ('6+12点', (36, 72)), ('6+12+18点(完整)', (36, 72, 108))]:
        recs = run_year(stages=st, data=data, verbose=False)
        out = recs[31:]
        print('%-16s 总费用 %12.0f 元 | 紧急购电 %9.1f kWh | 最终购电 %10.0f kWh'
              % (name, sum(r['cost_tot'] for r in out),
                 sum(r['em_buy'] for r in out), sum(r['final_buy'] for r in out)))
