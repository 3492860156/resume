# -*- coding: utf-8 -*-
"""
问题3「0:00 全天计划模型」结构图 + 真实示例
=====================================================================
上半：0:00 全天计划 LP 的输入 → 决策变量/目标/约束 → 输出 → 与调整层衔接
下半：2025-03-20 真实解——左：0点预报 vs 实际光伏；右：计划购电 Xp + 计划SOC Sp
数据：q3_common.load_all()（附件1/2/3）+ q3_full_results.json（计划LP真实输出）
输出：问题三/可视化/问题3_全天计划模型结构图.png
"""
import os
import sys
import io
import json

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.gridspec import GridSpec

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '求解模型'))

from q3_common import load_all, day_vector, H, ETA, E_MAX, S_MIN, S_MAX  # noqa: E402

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
OUT = os.path.join(ROOT, '问题三', '可视化', '问题3_全天计划模型结构图.png')
C_BLUE, C_BLUE2, C_ORANGE, C_GREEN, C_RED, C_GREY = '#6C8EBF', '#A8C5E0', '#E2A76F', '#82C9A9', '#D0655A', '#B8B8B8'

# ---------------- 真实数据：2025-03-20 ----------------
price, load_m, pv_m, fc_m, dates = load_all()
jfull = json.load(open(os.path.join(ROOT, '问题三', '数据', 'q3_full_results.json'), encoding='utf-8'))
FOC = '2025-03-20'
d = next(i for i, x in enumerate(dates) if str(x) == FOC)
L = day_vector(load_m, d) * H                 # 负载电量 kWh/段（模板列序）
PVact = day_vector(pv_m, d) * H               # 实际光伏电量
PVfc0 = fc_m[0, d] * H                        # 0点预报光伏电量
rr = jfull['focus_full'][FOC]
Xp, Sp = np.array(rr['Xp']), np.array(rr['Sp'])
tt = (np.arange(144) + 0.5) / 6.0             # 段中心小时 0.125..23.875+

# ---------------- 画布 ----------------
fig = plt.figure(figsize=(16, 12), dpi=200)
gs = GridSpec(2, 2, figure=fig, height_ratios=[1.18, 1], hspace=0.30, wspace=0.22,
              left=0.03, right=0.985, top=0.93, bottom=0.105)

# ========== 上部：模型结构图（单轴手绘） ==========
ax = fig.add_subplot(gs[0, :]); ax.axis('off')
ax.set_xlim(0, 100); ax.set_ylim(0, 100)


def box(x, y, w, h, text, fc, ec, fs=11, fw='normal', tc='#222222', lw=1.4, rad=0.018):
    p = FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.3,rounding_size=%s' % rad,
                       facecolor=fc, edgecolor=ec, linewidth=lw, mutation_aspect=0.55)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha='center', va='center', fontsize=fs,
            fontweight=fw, color=tc, linespacing=1.5)


def arrow(x1, y1, x2, y2, color='#555555', lw=1.8, style='-|>'):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=16,
                                 color=color, linewidth=lw, shrinkA=2, shrinkB=2))

ax.text(50, 97.5, '问题3  0:00 全天计划模型（阶段1）：结构与输入输出',
        ha='center', va='center', fontsize=16, fontweight='bold')

# 左列：输入
box(1.5, 74, 20, 13.5, '① 0点光伏预报 $\\~u_i^{(0)}$\n附件3 · 零阶保持展开144段\n（全天唯一不确定输入）',
    '#FBEBDD', '#E2A76F', fs=11, fw='bold')
box(1.5, 56, 20, 11, '② 小区负载 $L_i$\n附件2（确定已知）\n功率×1/6h 折段电量', '#EEF3F9', C_BLUE, fs=10.5)
box(1.5, 39, 20, 11, '③ 电价 $P_i$\n附件1（144段逐段不同）\n结束时刻口径循环移位', '#EEF3F9', C_BLUE, fs=10.5)
box(1.5, 22, 20, 11, '④ 初始储电 $S_0$\n前一日24:00实测递推\n（1月预热，跨天连续）', '#EEF3F9', C_BLUE, fs=10.5)

# 中列：LP 内核大框
box(27.5, 14, 43, 76, '', '#FBFCFE', C_BLUE, lw=2.0)
ax.text(49, 85.5, '0:00 全天计划 LP（144段 · 纯连续线性规划 · 凸优化全局最优）',
        ha='center', fontsize=12.5, fontweight='bold', color='#2F4B73')
box(29.5, 73, 39, 8.5, '决策变量（每段i=0…143）：\n$x_i$购电  $c_i$充电  $d_i$放电  $u_i$光伏直供  $e_i$紧急购电  $S_{i+1}$段末储电',
    '#FFFFFF', '#9DB8D2', fs=10.5)
box(29.5, 60.5, 39, 8, '目标函数：  min  $\\sum_{i=0}^{143} P_i\\,(x_i+5e_i)$',
    '#F3F7EC', '#82A86F', fs=12, fw='bold')
box(29.5, 49, 39, 8.5, '母线平衡：$x_i+u_i+0.9d_i+e_i-c_i=L_i$\n储能递推：$S_{i+1}=S_i+0.9c_i-d_i$',
    '#FFFFFF', '#9DB8D2', fs=10.8)
box(29.5, 37.5, 39, 8.5, '光伏直供上界：$0\\leq u_i\\leq \\~u_i^{(0)}$\n（用0点预报，不是实际光伏——与问题2的唯一差异）',
    '#FDF1E7', '#E2A76F', fs=10.5)
box(29.5, 26, 39, 8.5, '功率/容量界：$0\\leq c_i,d_i\\leq %.2f$ kWh\n$1200\\leq S_i\\leq10800$；$x_i,u_i,e_i\\geq0$；$S_0$固定' % E_MAX,
    '#FFFFFF', '#9DB8D2', fs=10.5)
ax.text(49, 18.3, '求解器 HiGHS 单纯形；1460个计划/调整LP全年全部 optimal',
        ha='center', fontsize=10, color='#666666', style='italic')

# 右列：输出
box(75, 60, 23.5, 16, '计划购电曲线 $Q_i^{p}$（144段）\n全天申报基准\n3-20实例：67369.3 kWh',
    '#EEF3F9', C_BLUE, fs=11, fw='bold')
box(75, 40, 23.5, 14, '计划充放电与储电轨迹\n$C_i^{p},D_i^{p},S_i^{p}$\n（贴SOC边界套利，见右下实例）',
    '#EEF3F9', C_BLUE, fs=10.8)
box(75, 22, 23.5, 12, '计划阶段紧急购电 $e_i\\equiv0$\n（预报内自平衡，\n紧急只在执行核验层产生）',
    '#F6F6F6', C_GREY, fs=10.5)

# 箭头
for yy in (80.7, 61.5, 44.5, 27.5):
    arrow(21.8, yy, 27.2, yy)
arrow(70.8, 68, 74.7, 68); arrow(70.8, 47, 74.7, 47); arrow(70.8, 28, 74.7, 28)

# 底部衔接通栏
box(1.5, 3.5, 97, 9.5, '', '#F4F8F4', C_GREEN, lw=1.6)
ax.text(50, 10.4, '阶段2 衔接：$Q_i^{p}$ 作为申报基准 → 6:00 / 12:00 / 18:00 对未执行窗口解滚动调整 LP',
        ha='center', fontsize=11.5, fontweight='bold', color='#3F6B3F')
ax.text(50, 6.0,
        '调整式 $x_i^{a}=Q_i^{p}+up_i-dn_i$（凸分段：上调1.5$P_i$、下调0.5$P_i$，LP自动保证 $up_i\\cdot dn_i=0$）  →  '
        '执行核验：附件2实际光伏逐段比对，缺口按 5$P_i$ 紧急购电',
        ha='center', fontsize=10.5, color='#3F6B3F')

# ========== 下左：0点预报 vs 实际光伏 ==========
ax1 = fig.add_subplot(gs[1, 0])
ax1.fill_between(tt, PVfc0, color=C_ORANGE, alpha=0.35, label='0点预报光伏（计划LP输入）', step='mid')
ax1.plot(tt, PVfc0, color='#D8944F', linewidth=1.4, drawstyle='steps-mid')
ax1.fill_between(tt, PVact, color=C_BLUE, alpha=0.28, label='实际光伏（执行时才知道）', step='mid')
ax1.plot(tt, PVact, color=C_BLUE, linewidth=1.4, drawstyle='steps-mid')
ax1.set_xlim(0, 24); ax1.set_xticks(range(0, 25, 3))
ax1.set_xlabel('时刻 (h)', fontsize=11); ax1.set_ylabel('光伏电量 (kWh/10min)', fontsize=11)
ax1.set_title('实例① 计划LP只看得到0点预报（橙），看不到实际光伏（蓝）', fontsize=12, pad=8)
ax1.legend(loc='upper left', fontsize=10, framealpha=0.92)
ax1.grid(axis='y', linestyle='--', alpha=0.4)
day_mae = np.abs(PVfc0 - PVact).mean()
ax1.text(0.98, 0.96, '当日段级MAE %.1f kWh\n预报与实际的偏差\n由调整层/紧急购电弥补' % day_mae,
         transform=ax1.transAxes, ha='right', va='top', fontsize=10,
         bbox=dict(boxstyle='round,pad=0.4', fc='white', ec='#CCCCCC'))

# ========== 下右：计划购电 + 计划SOC ==========
ax2 = fig.add_subplot(gs[1, 1])
ax2.bar(tt, Xp, width=(1 / 6) * 0.8, color=C_BLUE2, label='计划购电量 $Q_i^{p}$ (kWh/10min)')
ax2.set_xlim(0, 24); ax2.set_xticks(range(0, 25, 3))
ax2.set_xlabel('时刻 (h)', fontsize=11); ax2.set_ylabel('购电量 (kWh/10min)', fontsize=11)
ax2.set_ylim(0, 1500); ax2.grid(axis='y', linestyle='--', alpha=0.4)
ax2r = ax2.twinx()
ax2r.plot(np.arange(145) / 6.0, Sp, color='#4E8C5A', linewidth=2.2, label='计划储电量 $S_i^{p}$ (kWh)')
ax2r.axhline(S_MIN, color=C_RED, linestyle=':', linewidth=1.2)
ax2r.axhline(S_MAX, color=C_RED, linestyle=':', linewidth=1.2)
ax2r.set_ylim(0, 12000); ax2r.set_ylabel('储电量 (kWh)', fontsize=11, color='#4E8C5A')
ax2r.tick_params(axis='y', labelcolor='#4E8C5A')
ax2.set_title('实例② 计划LP输出：全天购电曲线与储能轨迹（计划购电 %.0f kWh）' % rr['plan_buy'],
              fontsize=12, pad=8)
h1, l1 = ax2.get_legend_handles_labels(); h2, l2 = ax2r.get_legend_handles_labels()
ax2.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=10, framealpha=0.92)

fig.text(0.5, 0.03,
         '要点：全天计划模型与问题2同构（同一LP内核、同约束、同跨天SOC递推），唯一区别是光伏直供上界由「实际光伏」换为「0点预报」；输出 Qp 是后续三次滚动调整的申报基准。',
         ha='center', fontsize=11.5, color='#333333')

fig.savefig(OUT, bbox_inches='tight')
plt.close(fig)
print('已保存:', OUT)
print('校验：3-20 计划购电 %.2f kWh（json %.2f）｜计划SOC范围 [%.0f, %.0f]｜段级MAE %.2f'
      % (Xp.sum(), rr['plan_buy'], Sp.min(), Sp.max(), day_mae))
