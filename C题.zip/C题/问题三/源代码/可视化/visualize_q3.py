# -*- coding: utf-8 -*-
"""问题3 可视化：四指定日策略 / 四模式调整价值 / 滚动调整过程 / 全年月度统计"""
import os
import sys
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '求解模型'))

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

from q3_common import (H, ETA, FOCUS, OUTDIR, load_all, day_vector)
from solve_q3 import solve_plan, solve_adjust, simulate_day

FIGDIR = os.path.join(OUTDIR, '可视化'); os.makedirs(FIGDIR, exist_ok=True)
C_PLAN, C_FINAL, C_EM, C_PV, C_LOAD, C_SOC = \
    '#B7CCE0', '#4E79A7', '#E15759', '#F1B47A', '#8C8C8C', '#59A14F'
data = load_all()
price, load_m, pv_m, fc_m, dates = data
j = json.load(open(os.path.join(OUTDIR, '数据', 'q3_full_results.json'), encoding='utf-8'))
focus = j['focus_full']; daily = j['daily']
s0_map = {r['date']: r['s0'] for r in daily}
dstr = [str(x) for x in dates]
T = np.arange(144) / 6.0 + 1.0 / 6          # 段结束时刻（小时）


def get_day(f):
    di = dstr.index(f)
    L = day_vector(load_m, di) * H
    PVact = day_vector(pv_m, di) * H
    fc_day = np.stack([fc_m[k, di] * H for k in range(4)])
    r = simulate_day(L, PVact, fc_day, price, s0_map[f], stages=(36, 72, 108))
    # 复现滚动中间轨迹
    Xp, Cp, Dp, Up, Ep, Sp = solve_plan(L, fc_day[0], price, s0_map[f])
    X1 = Xp.copy(); C1 = Cp.copy(); D1 = Dp.copy()
    s36 = s0_map[f] + (ETA * C1[:36] - D1[:36]).sum()
    xa, ca, da, *_ = solve_adjust(L, fc_day[1], price, s36, Xp, 36)
    X1[36:], C1[36:], D1[36:] = xa, ca, da
    X2 = X1.copy(); C2 = C1.copy(); D2 = D1.copy()
    s72 = s0_map[f] + (ETA * C2[:72] - D2[:72]).sum()
    xa, ca, da, *_ = solve_adjust(L, fc_day[2], price, s72, Xp, 72)
    X2[72:], C2[72:], D2[72:] = xa, ca, da
    return L, PVact, fc_day, r, (Xp, X1, X2, r['Xf'])


# ---------- 图1：四指定日购电策略 ----------
def fig_focus():
    fig, axes = plt.subplots(2, 2, figsize=(15, 9))
    soc_line = None
    for ax, f in zip(axes.ravel(), FOCUS):
        L, PVact, fc_day, r, _ = get_day(f)
        ax.bar(T, L, width=0.14, color=C_LOAD, alpha=0.35, label='小区负载')
        ax.bar(T, PVact, width=0.14, color=C_PV, alpha=0.55, label='实际光伏')
        ax.bar(T, r['Xp'], width=0.14, color=C_PLAN, label='计划购电量')
        ax.bar(T, r['Xf'], width=0.07, color=C_FINAL, label='最终购电量')
        em = np.where(r['Eact'] > 1e-6, r['Eact'], 0)
        ax.bar(T, em, width=0.07, color=C_EM, label='紧急购电')
        for x in (6, 12, 18):
            ax.axvline(x, color='#999', ls=':', lw=1)
        ax2 = ax.twinx()
        soc_line, = ax2.plot(T, r['Sf'][:144], color=C_SOC, lw=1.8, label='储电量')
        ax2.set_ylim(0, 12500); ax2.set_ylabel('储电量(kWh)', fontsize=9, color=C_SOC)
        ax2.tick_params(axis='y', labelcolor=C_SOC, labelsize=8)
        ax.set_title('%s｜总费用%.0f元(紧急%.0f)' % (f, r['cost_tot'], r['cost_em']),
                     fontsize=11)
        ax.set_ylim(0, 1500)
        ax.set_xlim(0, 24); ax.set_xticks(range(0, 25, 3))
        ax.set_xlabel('时刻(h)', fontsize=9); ax.set_ylabel('电量(kWh)', fontsize=9)
        ax.grid(alpha=0.2)
    h1, l1 = axes[0, 0].get_legend_handles_labels()
    fig.legend(h1 + [soc_line], l1 + ['储电量'], loc='lower center', ncol=6,
               fontsize=10, frameon=False)
    fig.suptitle('问题3 四指定日：计划/最终购电量、紧急购电与储能轨迹（虚线为6/12/18调整时刻）',
                 fontsize=13, y=0.98)
    fig.tight_layout(rect=[0, 0.04, 1, 0.96])
    p = os.path.join(FIGDIR, '问题3_四指定日购电策略.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig)
    print('saved', p)


# ---------- 图2：四模式调整价值 ----------
def fig_modes():
    mc = json.load(open(os.path.join(OUTDIR, '数据', 'q3_mode_compare.json'), encoding='utf-8'))
    names = ['M0_不调整', 'M1_仅6点', 'M2_6+12点', 'M3_6+12+18点']
    lab = ['不调整\n(仅0点计划)', '仅6点调整', '6+12点调整', '6+12+18点\n(完整)']
    buy = [mc[n]['购电侧费用'] / 1e4 for n in names]
    em = [mc[n]['紧急购电费用'] / 1e4 for n in names]
    tot = [mc[n]['总费用'] / 1e4 for n in names]
    emq = [mc[n]['紧急购电量'] / 1e4 for n in names]
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.2))
    x = np.arange(4); w = 0.38
    b1 = ax1.bar(x - w/2, buy, w, color=C_FINAL, label='购电侧费用(含调整结算)')
    b2 = ax1.bar(x + w/2, em, w, color=C_EM, label='紧急购电费用(5倍电价)')
    for i, t in enumerate(tot):
        ax1.text(i, 1320, '%.0f万' % t, ha='center', fontsize=10, fontweight='bold')
    ax1.set_xticks(x); ax1.set_xticklabels(lab); ax1.set_ylabel('费用（万元）')
    ax1.set_ylim(0, 1420)
    ax1.set_title('四种调整模式全年费用构成（334天）'); ax1.grid(alpha=0.2, axis='y')
    ln1, = ax2.plot(x, emq, 'o-', color=C_EM, lw=2, markersize=8, label='紧急购电量')
    for i, v in enumerate(emq):
        ax2.text(i, v + 4.5, '%.1f万kWh' % v, ha='center', fontsize=9, color=C_EM)
    ax2.set_title('调整逐级降低紧急购电与总费用'); ax2.grid(alpha=0.2)
    save = [mc[n]['相对不调整节约'] / 1e4 for n in names]
    ax2b = ax2.twinx()
    b3 = ax2b.bar(x, save, width=0.45, color='#9BD3A6', alpha=0.6, label='相对不调整节约')
    for i, v in enumerate(save):
        ax2b.text(i, max(v - 7, 1.5), '省%.1f万' % v, ha='center', fontsize=9, color='#2F6B37')
    ax2.set_xticks(x); ax2.set_xticklabels(lab)
    ax2.set_ylabel('紧急购电量（万kWh）', color=C_EM); ax2.set_ylim(0, 108)
    ax2b.set_ylabel('费用节约（万元）', color='#3C7A43'); ax2b.set_ylim(0, 75)
    fig.legend([b1, b2, ln1, b3],
               ['购电侧费用(含调整结算)', '紧急购电费用(5倍电价)', '紧急购电量', '相对不调整节约'],
               loc='lower center', ncol=4, fontsize=10, frameon=False)
    fig.tight_layout(rect=[0, 0.06, 1, 1])
    p = os.path.join(FIGDIR, '问题3_四模式调整价值.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig)
    print('saved', p)


# ---------- 图3：单日滚动调整过程（3.20） ----------
def fig_rolling(f='2025-03-20'):
    L, PVact, fc_day, r, traj = get_day(f)
    Xp, X1, X2, Xf = traj
    fig, axes = plt.subplots(4, 1, figsize=(13, 10), sharex=True)
    series = [('0:00 计划（基于0点预报）', Xp, C_PLAN),
              ('6:00 调整后', X1, '#9BBBF4'),
              ('12:00 调整后', X2, '#E1B98F'),
              ('18:00 最终执行', Xf, C_FINAL)]
    for ax, (title, vec, col) in zip(axes, series):
        ax.bar(T, L, width=0.14, color=C_LOAD, alpha=0.3, label='负载')
        ax.bar(T, PVact, width=0.14, color=C_PV, alpha=0.5, label='实际光伏')
        ax.bar(T, vec, width=0.09, color=col, label='购电量')
        em = np.where(r['Eact'] > 1e-6, r['Eact'], 0)
        ax.bar(T, em, width=0.09, color=C_EM, label='实际紧急购电')
        for x in (6, 12, 18):
            ax.axvline(x, color='#999', ls=':', lw=1)
        ax.set_ylabel('kWh'); ax.set_title(title, fontsize=10.5, loc='left')
        ax.legend(fontsize=8, ncol=4, loc='upper right', frameon=False)
        ax.grid(alpha=0.2); ax.set_xlim(0, 24)
    axes[-1].set_xlabel('时刻(h)'); axes[-1].set_xticks(range(0, 25, 2))
    fig.suptitle('%s 滚动调整过程：预报更新如何逐段修正购电策略' % f, fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    p = os.path.join(FIGDIR, '问题3_单日滚动调整过程.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig)
    print('saved', p)


# ---------- 图4：全年月度统计 ----------
def fig_monthly():
    out = daily[31:]
    months = list(range(2, 13))
    mcost, mem, madj = [], [], []
    for m in months:
        rs = [r for r in out if int(r['date'][5:7]) == m]
        mcost.append(sum(r['cost_tot'] for r in rs) / 1e4)
        mem.append(sum(r['em_buy'] for r in rs) / 1e4)
        madj.append(sum(abs(r['cost_adj']) for r in rs) / 1e4)
    fig, ax1 = plt.subplots(figsize=(13, 5.2))
    x = np.arange(len(months)); w = 0.55
    ax1.bar(x, mcost, w, color=C_FINAL, alpha=0.85, label='月度总费用')
    ax1.set_xticks(x); ax1.set_xticklabels(['%d月' % m for m in months])
    ax1.set_ylabel('总费用（万元）', color=C_FINAL); ax1.grid(alpha=0.2, axis='y')
    ax2 = ax1.twinx()
    ax2.plot(x, mem, 's-', color=C_EM, lw=2, label='紧急购电量')
    ax2.plot(x, madj, '^--', color='#E1B98F', lw=2, label='调整结算额(绝对值)')
    ax2.set_ylabel('电量/金额（万kWh / 万元）')
    h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=10)
    ax1.set_title('问题3 全年月度费用、紧急购电与调整结算（2025.2–12）')
    fig.tight_layout()
    p = os.path.join(FIGDIR, '问题3_全年月度统计.png')
    fig.savefig(p, dpi=200, bbox_inches='tight'); plt.close(fig)
    print('saved', p)


if __name__ == '__main__':
    fig_focus()
    fig_modes()
    fig_rolling()
    fig_monthly()
    print('全部图表已生成至', FIGDIR)
