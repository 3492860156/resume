# -*- coding: utf-8 -*-
"""
对话交接文档 Markdown → Word 转换脚本（简单版）
=============================================
- A4，页边距 2.5cm；Title 黑体18 / H1 黑体16 / H2 黑体14 / 正文宋体12(1.5倍行距)
- 表格：表头浅灰底纹、宋体10.5、垂直居中、外框1磅内0.5磅、长表重复表头
- 列表：不用 Word 自动编号（Word 对 python-docx 生成的自定义 numbering 会回退），
  直接渲染文本符号：无序 - → •，编号保留原文数字
"""
import re
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

import sys
MD_PATH = sys.argv[1]
DOCX_PATH = sys.argv[2]

BLACK = RGBColor(0, 0, 0)
GRAY = RGBColor(0x59, 0x59, 0x59)

doc = Document()

# ---------------- 页面设置 ----------------
sec = doc.sections[0]
sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
sec.top_margin = sec.bottom_margin = sec.left_margin = sec.right_margin = Cm(2.5)

# ---------------- 字体辅助 ----------------
def set_font(run, east='宋体', west='Arial', size=12, bold=False, color=BLACK, italic=False):
    run.font.name = west
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = OxmlElement('w:rFonts')
        rPr.insert(0, rFonts)
    rFonts.set(qn('w:eastAsia'), east)
    rFonts.set(qn('w:ascii'), west)
    rFonts.set(qn('w:hAnsi'), west)

def parse_inline(text):
    """解析 **加粗** 与 `代码`，返回 [(text, bold, code)]"""
    runs = []
    pattern = re.compile(r'(\*\*.+?\*\*|`[^`]+`)')
    pos = 0
    for m in pattern.finditer(text):
        if m.start() > pos:
            runs.append((text[pos:m.start()], False, False))
        seg = m.group(0)
        if seg.startswith('**'):
            runs.append((seg[2:-2], True, False))
        else:
            runs.append((seg[1:-1], False, True))
        pos = m.end()
    if pos < len(text):
        runs.append((text[pos:], False, False))
    return runs

def add_rich(par, text, east='宋体', size=12, color=BLACK):
    for t, bold, code in parse_inline(text):
        r = par.add_run(t)
        if code:
            set_font(r, east='Consolas', west='Consolas', size=size-0.5, bold=bold, color=color)
        else:
            set_font(r, east=east, west='Arial', size=size, bold=bold, color=color)
    return par

def add_para(text, east='宋体', size=12, align=WD_ALIGN_PARAGRAPH.JUSTIFY,
             bold=False, color=BLACK, space_before=0, space_after=0, line=1.5,
             first_indent=24, left_indent=None):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.alignment = align
    pf.space_before = Pt(space_before)
    pf.space_after = Pt(space_after)
    pf.line_spacing = line
    if first_indent:
        pf.first_line_indent = Pt(first_indent)
    if left_indent is not None:
        pf.left_indent = Cm(left_indent)
    add_rich(p, text, east=east, size=size, color=color)
    for r in p.runs:
        if bold:
            r.font.bold = True
    return p

# ---------------- 标题 ----------------
def add_heading(text, level):
    if level == 0:
        p = doc.add_paragraph(style='Title')
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_after = Pt(18)
        add_rich(p, text, east='黑体', size=18)
        for r in p.runs:
            r.font.bold = True
            r.font.color.rgb = BLACK
        # 去掉 Title 样式自带的蓝色下边框横线
        pPr = p._p.get_or_add_pPr()
        pBdr = OxmlElement('w:pBdr')
        bottom = OxmlElement('w:bottom')
        bottom.set(qn('w:val'), 'none')
        bottom.set(qn('w:sz'), '0')
        bottom.set(qn('w:space'), '0')
        bottom.set(qn('w:color'), 'auto')
        pBdr.append(bottom)
        pPr.append(pBdr)
    elif level == 1:
        p = doc.add_paragraph(style='Heading 1')
        p.paragraph_format.space_before = Pt(14)
        p.paragraph_format.space_after = Pt(6)
        add_rich(p, text, east='黑体', size=16)
        for r in p.runs:
            r.font.bold = True
            r.font.color.rgb = BLACK
    else:
        p = doc.add_paragraph(style='Heading 2')
        p.paragraph_format.space_before = Pt(11)
        p.paragraph_format.space_after = Pt(5)
        add_rich(p, text, east='黑体', size=14)
        for r in p.runs:
            r.font.bold = True
            r.font.color.rgb = BLACK
    return p

# ---------------- 表格 ----------------
def set_cell_bg(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:fill'), hex_color)
    tcPr.append(shd)

def set_cell_valign(cell):
    tcPr = cell._tc.get_or_add_tcPr()
    vAlign = OxmlElement('w:vAlign')
    vAlign.set(qn('w:val'), 'center')
    tcPr.append(vAlign)

def set_table_borders(table):
    tbl = table._tbl
    tblPr = tbl.tblPr
    borders = OxmlElement('w:tblBorders')
    for edge, sz in (('top', 8), ('bottom', 8), ('left', 8), ('right', 8),
                     ('insideH', 4), ('insideV', 4)):
        el = OxmlElement('w:' + edge)
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), str(sz))
        el.set(qn('w:color'), '808080')
        borders.append(el)
    tblPr.append(borders)

def set_repeat_header(row):
    trPr = row._tr.get_or_add_trPr()
    th = OxmlElement('w:tblHeader')
    th.set(qn('w:val'), 'true')
    trPr.append(th)

def is_numeric_like(s):
    s = s.strip()
    if not s:
        return False
    return bool(re.fullmatch(r'[+\-−]?[\d.,%\s→~/]+', s)) and re.search(r'\d', s)

def add_md_table(rows, col_widths_cm):
    n_rows, n_cols = len(rows), len(rows[0])
    table = doc.add_table(rows=n_rows, cols=n_cols)
    table.autofit = False
    set_table_borders(table)
    for ri, row in enumerate(rows):
        for ci, val in enumerate(row):
            cell = table.cell(ri, ci)
            cell.width = Cm(col_widths_cm[ci])
            set_cell_valign(cell)
            p = cell.paragraphs[0]
            pf = p.paragraph_format
            pf.first_line_indent = Pt(0)
            pf.left_indent = Pt(0)
            pf.line_spacing = 1.0
            pf.space_before = Pt(0)
            pf.space_after = Pt(0)
            if ri == 0:                      # 表头
                pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
                add_rich(p, val, east='宋体', size=10.5)
                for r in p.runs:
                    r.font.bold = True
                set_cell_bg(cell, 'D9D9D9')
            else:                            # 数据
                if is_numeric_like(val):
                    pf.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                elif len(val) <= 12:
                    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
                else:
                    pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
                add_rich(p, val, east='宋体', size=10.5)
    set_repeat_header(table.rows[0])
    # 表格后空一行
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return table

# ---------------- 目录 ----------------
def add_toc_section():
    # 目录标题（不占 Heading 样式，避免出现在目录自身中）
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(12)
    r = p.add_run('目  录')
    set_font(r, east='黑体', west='Arial', size=16, bold=True, color=BLACK)
    # 动态 TOC 域（Word 打开后 F9 刷新）
    p2 = doc.add_paragraph()
    run = p2.add_run()
    fldChar = OxmlElement('w:fldChar'); fldChar.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText'); instrText.set(qn('xml:space'), 'preserve')
    instrText.text = r'TOC \o "1-2" \h \z \u'
    separate = OxmlElement('w:fldChar'); separate.set(qn('w:fldCharType'), 'separate')
    t = OxmlElement('w:t'); t.text = '（打开文档后按 F9 或右键“更新域”刷新目录）'
    end = OxmlElement('w:fldChar'); end.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar); run._r.append(instrText)
    run._r.append(separate); run._r.append(t); run._r.append(end)

# ---------------- 主流程 ----------------
with open(MD_PATH, encoding='utf-8') as f:
    lines = f.read().split('\n')

# 第一行主标题
m0 = re.match(r'^#\s+(.*)$', lines[0])
assert m0, '首行应为 # 主标题'
add_heading(m0.group(1), 0)
doc.add_page_break()
add_toc_section()
doc.add_page_break()
start = 2

i = start
while i < len(lines):
    raw = lines[i]
    line = raw.rstrip()

    # 空行 / 分隔线
    if not line.strip() or re.fullmatch(r'-{3,}|\*{3,}', line.strip()):
        i += 1
        continue

    # 标题（md 层级 → Word 层级：1→Title, 2→Heading1, 3→Heading2）
    m = re.match(r'^(#{1,3})\s+(.*)$', line)
    if m:
        level = len(m.group(1))
        add_heading(m.group(2), level - 1)
        i += 1
        continue

    # 引用块
    if line.startswith('>'):
        text = line.lstrip('>').strip()
        if text:
            add_para(text, east='楷体', size=12, align=WD_ALIGN_PARAGRAPH.LEFT,
                     color=GRAY, space_after=4, first_indent=0)
        i += 1
        continue

    # 表格
    if line.startswith('|'):
        tbl_lines = []
        while i < len(lines) and lines[i].strip().startswith('|'):
            tbl_lines.append(lines[i].strip())
            i += 1
        parsed = []
        for tl in tbl_lines:
            cells = [c.strip() for c in tl.strip('|').split('|')]
            parsed.append(cells)
        data_rows = [r for r in parsed if not all(re.fullmatch(r':?-{2,}:?', c) for c in r)]
        if len(data_rows) >= 2:
            n_cols = len(data_rows[0])
            total = sum(max(2, min(7, max(len(data_rows[r][c]) for r in range(len(data_rows))))) for c in range(n_cols))
            widths = [round(16.0 * max(2, min(7, max(len(data_rows[r][c]) for r in range(len(data_rows))))) / total, 1) for c in range(n_cols)]
            for c in range(n_cols):
                if any(':\\' in data_rows[r][c] for r in range(len(data_rows))):
                    widths[c] = 9.0
            widths = [max(w, 1.8) for w in widths]
            s = sum(widths)
            widths = [round(w * 16.0 / s, 1) for w in widths]
            add_md_table(data_rows, widths)
        i += 1
        continue

    # 无序列表：- xxx → • xxx
    m = re.match(r'^\s*[-*]\s+(.*)$', line)
    if m:
        add_para('• ' + m.group(1), align=WD_ALIGN_PARAGRAPH.LEFT,
                 first_indent=0, left_indent=0.75, space_after=2)
        i += 1
        continue

    # 编号列表（md 原文已带编号，直接渲染，保留缩进层级）
    m = re.match(r'^(\s*)(\d+)\.\s+(.*)$', line)
    if m:
        left = 1.2 if len(m.group(1)) >= 2 else 0.6
        add_para(m.group(2) + '. ' + m.group(3), align=WD_ALIGN_PARAGRAPH.LEFT,
                 first_indent=0, left_indent=left, space_after=2)
        i += 1
        continue

    # 普通段落
    add_para(line)  # 首行缩进2字符(12pt*2)
    i += 1

doc.save(DOCX_PATH)
print('已保存:', DOCX_PATH)
