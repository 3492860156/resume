# -*- coding: utf-8 -*-
"""
问题3 四项分析公共模块
=====================================================================
在 solve_q3 基础上做"全参数化"，供误差/交叉/敏感性/稳健性四类分析调用：
  - solve_plan_p / solve_adjust_p / simulate_day_p / run_year_p
  - 可覆盖：充放效率 eta、充放功率 p_max、储能上下界、紧急倍率 emult、
            下调退款率 dn、上调溢价率 up、滚动阶段 stages、
            预报误差强度 err_k（fc' = 实际 + err_k*(预报-实际)，0=完美预报,1=原预报）、
            预报系统偏差 err_b（fc' 再乘 1+err_b）。
  - keep_seg=True 时保留逐段结果（计划/最终购电、充放、紧急、上调下调），供交叉分析。
口径与主模型完全一致：母线 x+u+ηd+e-c=L；储能 S(i+1)=S(i)+ηc-d；10分钟粒度；1月预热。
"""
import os, sys
import numpy as np
from scipy.optimize import linprog

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(_HERE, '..', '求解模型'))
from q3_common import (H, N, S_INIT, load_all, day_vector)  # noqa: E402

ROOT = r'D:\my\数学建模大赛\2026\2026国赛赛题\C题'
Q3DIR = os.path.join(ROOT, '问题三')
ANADIR = os.path.join(Q3DIR, '源代码', '四项分析')
FIGDIR = os.path.join(Q3DIR, '可视化')
CACHE = os.path.join(ANADIR, 'cache_q3_baseline.npz')
os.makedirs(ANADIR, exist_ok=True); os.makedirs(FIGDIR, exist_ok=True)
OUT_SLICE = slice(31, 365)          # 2025.2.1-12.31，共334天


# ----------------------- 参数化 0:00 计划 LP -----------------------
def solve_plan_p(L, PV, price, s_init, eta=0.9, e_max=H * 5000.0,
                 s_min=1200.0, s_max=10800.0, emult=5.0):
    nv = 5 * N + (N + 1)
    off = {'x': 0, 'c': N, 'd': 2 * N, 'u': 3 * N, 'e': 4 * N, 'S': 5 * N}
    vid = lambda i, k: off[k] + i
    obj = np.zeros(nv)
    obj[off['x']:off['x'] + N] = price
    obj[off['e']:off['e'] + N] = emult * price
    A = np.zeros((2 * N, nv)); b = np.zeros(2 * N)
    for i in range(N):
        A[i, vid(i, 'x')] = 1; A[i, vid(i, 'u')] = 1
        A[i, vid(i, 'd')] = eta; A[i, vid(i, 'e')] = 1
        A[i, vid(i, 'c')] = -1; b[i] = L[i]
        A[N + i, vid(i + 1, 'S')] = 1; A[N + i, vid(i, 'S')] = -1
        A[N + i, vid(i, 'c')] = -eta; A[N + i, vid(i, 'd')] = 1
    bounds = [(0.0, None)] * nv
    for i in range(N):
        bounds[vid(i, 'c')] = (0, e_max); bounds[vid(i, 'd')] = (0, e_max)
        bounds[vid(i, 'u')] = (0, PV[i])
    for i in range(N + 1):
        bounds[vid(i, 'S')] = (s_min, s_max)
    bounds[vid(0, 'S')] = (s_init, s_init)
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('计划LP失败: %s' % res.message)
    g = lambda k: res.x[off[k]:off[k] + N]
    return g('x'), g('c'), g('d'), g('u'), g('e'), res.x[off['S']:off['S'] + N + 1]


# --------------------- 参数化窗口滚动调整 LP ---------------------
def solve_adjust_p(L, PV, price, s_start, Qp, i0, eta=0.9, e_max=H * 5000.0,
                   s_min=1200.0, s_max=10800.0, emult=5.0, dn=0.5, up=1.5):
    n = N - i0
    Lw, PVw, Pw, Qw = L[i0:], PV[i0:], price[i0:], Qp[i0:]
    nv = 7 * n + (n + 1)
    off = {'x': 0, 'c': n, 'd': 2 * n, 'u': 3 * n, 'e': 4 * n, 'up': 5 * n, 'dn': 6 * n, 'S': 7 * n}
    vid = lambda i, k: off[k] + i
    obj = np.zeros(nv)
    obj[off['dn']:off['dn'] + n] = -dn * Pw
    obj[off['up']:off['up'] + n] = up * Pw
    obj[off['e']:off['e'] + n] = emult * Pw
    A = np.zeros((3 * n, nv)); b = np.zeros(3 * n)
    for i in range(n):
        A[i, vid(i, 'x')] = 1; A[i, vid(i, 'u')] = 1
        A[i, vid(i, 'd')] = eta; A[i, vid(i, 'e')] = 1
        A[i, vid(i, 'c')] = -1; b[i] = Lw[i]
        A[n + i, vid(i + 1, 'S')] = 1; A[n + i, vid(i, 'S')] = -1
        A[n + i, vid(i, 'c')] = -eta; A[n + i, vid(i, 'd')] = 1
        A[2 * n + i, vid(i, 'x')] = 1
        A[2 * n + i, vid(i, 'up')] = -1
        A[2 * n + i, vid(i, 'dn')] = 1
        b[2 * n + i] = Qw[i]
    bounds = [(0.0, None)] * nv
    for i in range(n):
        bounds[vid(i, 'c')] = (0, e_max); bounds[vid(i, 'd')] = (0, e_max)
        bounds[vid(i, 'u')] = (0, PVw[i])
    for i in range(n + 1):
        bounds[vid(i, 'S')] = (s_min, s_max)
    bounds[vid(0, 'S')] = (s_start, s_start)
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('调整LP(i0=%d)失败: %s' % (i0, res.message))
    g = lambda k: res.x[off[k]:off[k] + n]
    return g('x'), g('c'), g('d'), g('u'), g('e'), g('up'), g('dn')


# ----------------------- 单日参数化滚动模拟 -----------------------
def simulate_day_p(L, PVact, fc_day, price, s_init, stages=(36, 72, 108),
                   eta=0.9, p_max=5000.0, s_min=1200.0, s_max=10800.0,
                   emult=5.0, dn=0.5, up=1.5, err_k=1.0, err_b=0.0, keep=False):
    """fc_day: (4,144) 四次预报能量(kWh)。err_k/err_b 在求解前对预报做变换。"""
    e_max = p_max * H
    # 预报误差变换：fc' = (实际 + err_k*(预报-实际)) * (1+err_b)，且不小于0
    fc_use = np.maximum((PVact[None, :] + err_k * (fc_day - PVact[None, :])) * (1.0 + err_b), 0.0)
    Xp, Cp, Dp, _, _, _ = solve_plan_p(L, fc_use[0], price, s_init, eta, e_max, s_min, s_max, emult)
    Xf, Cf, Df = Xp.copy(), Cp.copy(), Dp.copy()
    adj_log = []
    for j, i0 in zip((1, 2, 3), (36, 72, 108)):
        if i0 not in stages:
            continue
        s_i0 = s_init + float((eta * Cf[:i0] - Df[:i0]).sum())
        xa, ca, da, _, _, upv, dnv = solve_adjust_p(
            L, fc_use[j], price, s_i0, Xp, i0, eta, e_max, s_min, s_max, emult, dn, up)
        adj_log.append({'at': i0,
                        'chg_buy': float(xa.sum() - Xf[i0:].sum()),
                        'up': float(upv.sum()), 'dn': float(dnv.sum())})
        Xf[i0:], Cf[i0:], Df[i0:] = xa, ca, da
    gap = L + Cf - Xf - eta * Df
    Uact = np.minimum(PVact, np.maximum(gap, 0.0))
    Eact = np.maximum(gap - PVact, 0.0)
    Sf = np.empty(N + 1); Sf[0] = s_init
    Sf[1:] = s_init + np.cumsum(eta * Cf - Df)
    dn_f = np.maximum(Xp - Xf, 0.0); up_f = np.maximum(Xf - Xp, 0.0)
    cost_plan = float((price * Xp).sum())
    cost_adj = float((-dn * price * dn_f + up * price * up_f).sum())
    cost_em = float((emult * price * Eact).sum())
    out = dict(plan_buy=float(Xp.sum()), final_buy=float(Xf.sum()),
               up=float(up_f.sum()), dn=float(dn_f.sum()), em_buy=float(Eact.sum()),
               cost_plan=cost_plan, cost_adj=cost_adj, cost_em=cost_em,
               cost_buy=cost_plan + cost_adj, cost_tot=cost_plan + cost_adj + cost_em,
               s24=float(Sf[N]), adj_log=adj_log)
    if keep:
        out.update(Xp=Xp, Xf=Xf, Cf=Cf, Df=Df, Eact=Eact, Uact=Uact, Sf=Sf,
                   upseg=up_f, dnseg=dn_f)
    return out


def run_year_p(data, stages=(36, 72, 108), eta=0.9, p_max=5000.0,
               s_min=1200.0, s_max=10800.0, emult=5.0, dn=0.5, up=1.5,
               err_k=1.0, err_b=0.0, err_k_vec=None, err_b_vec=None,
               keep=False, verbose=False):
    price, load_m, pv_m, fc_m, dates = data
    recs = []; s_init = S_INIT
    seg = None
    if keep:
        seg = dict(Xp=[], Xf=[], Cf=[], Df=[], Eact=[], Uact=[], upseg=[], dnseg=[], Sf=[])
    for d in range(365):
        ek = float(err_k_vec[d]) if err_k_vec is not None else err_k
        eb = float(err_b_vec[d]) if err_b_vec is not None else err_b
        L = day_vector(load_m, d) * H
        PVact = day_vector(pv_m, d) * H
        fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
        r = simulate_day_p(L, PVact, fc_day, price, s_init, stages=stages,
                           eta=eta, p_max=p_max, s_min=s_min, s_max=s_max,
                           emult=emult, dn=dn, up=up, err_k=ek, err_b=eb, keep=keep)
        r['date'] = str(dates[d]); r['d'] = d
        if keep:
            for k in ('Xp', 'Xf', 'Cf', 'Df', 'Eact', 'Uact', 'upseg', 'dnseg', 'Sf'):
                seg[k].append(r.pop(k))
        recs.append(r); s_init = r['s24']
        if verbose and (d + 1) % 100 == 0:
            print('   solved %d/365' % (d + 1), flush=True)
    if keep:
        seg = {k: np.array(v) for k, v in seg.items()}
        return recs, seg
    return recs


def summarize(recs, sl=OUT_SLICE):
    out = recs[sl] if isinstance(sl, slice) else [recs[i] for i in sl]
    agg = lambda key: float(sum(r[key] for r in out))
    return dict(total=agg('cost_tot'), buy=agg('cost_buy'), em_cost=agg('cost_em'),
                plan_buy=agg('plan_buy'), final_buy=agg('final_buy'),
                up=agg('up'), dn=agg('dn'), em_kwh=agg('em_buy'),
                em_days=sum(1 for r in out if r['em_buy'] > 1e-6), ndays=len(out))


def get_baseline_seg(data, force=False):
    """完整模式(M3=36/72/108)全年逐段基线，带 npz 缓存。"""
    if (not force) and os.path.exists(CACHE):
        z = np.load(CACHE, allow_pickle=True)
        return {k: z[k] for k in z.files}
    recs, seg = run_year_p(data, stages=(36, 72, 108), keep=True, verbose=True)
    save = dict(recs=np.array([{k: v for k, v in r.items() if k != 'adj_log'} for r in recs], dtype=object))
    save.update({k: v for k, v in seg.items()})
    np.savez(CACHE, **save)
    return {**save, **{}}


def mc_year(data, seed, stages=(36, 72, 108)):
    """蒙特卡洛单次：逐日抽取误差强度乘子g与系统偏置b(日内相关)，全年滚动，返回汇总。
    模块级函数以便 multiprocessing 在 Windows spawn 下可 pickle。"""
    rng = np.random.default_rng(int(seed))
    g = np.clip(rng.normal(1.0, 0.35, 365), 0.2, 2.0)     # 当日整体预报准度
    b = np.clip(rng.normal(0.0, 0.06, 365), -0.15, 0.15)  # 当日整体高/低估
    recs = run_year_p(data, stages=stages, err_k_vec=g, err_b_vec=b)
    m = summarize(recs)
    return dict(total=m['total'], em=m['em_kwh'], up=m['up'], dn=m['dn'], buy=m['buy'])


if __name__ == '__main__':
    import time
    t0 = time.time(); data = load_all()
    t = time.time(); recs = run_year_p(data, stages=(36, 72, 108), verbose=False)
    print('全年365天×4LP 耗时 %.2fs' % (time.time() - t))
    m = summarize(recs)
    for k, v in m.items():
        print('%-10s %.4g' % (k, v))
    print('总费用(万元) %.2f  紧急(万kWh) %.2f' % (m['total'] / 1e4, m['em_kwh'] / 1e4))
