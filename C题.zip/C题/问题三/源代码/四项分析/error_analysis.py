# -*- coding: utf-8 -*-
"""
问题3 分析①——误差分析（光伏预报误差，本问不确定性的根源）
=====================================================================
对象：附件3 四次光伏预报(0/6/12/18点发布) vs 附件2 实际光伏功率；输出区间 2025.2.1-12.31。
内容：
  A. 四次发布在各自有效覆盖窗口的整体精度：MAE/RMSE/平均偏差bias/高估能量/低估能量；
  B. 误差随"预报提前量(lead hour)"的变化（越临近越准）；
  C. 误差的日内24小时分布与方向（高估->5倍紧急购电，低估->0.5倍下调退款，不对称）；
  D. 逐次更新对同一目标窗口的信息增益（MAE 递减）。
输出：error_metrics.json + 3 张图。
"""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, '..', '求解模型'))
from q3_common import load_all, day_vector, H                       # noqa: E402
from q3a_common import FIGDIR                                       # noqa: E402

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

C_FC, C_ACT, C_HI, C_LO, C_MAIN = '#E1B98F', '#4E79A7', '#E15759', '#59A14F', '#6C8EBF'
PUB = [0, 6, 12, 18]
DS, DE = 31, 365                       # 输出区间天下标

data = load_all()
price, load_m, pv_m, fc_m, dates = data
# 对齐到自然日 144 段（功率 kW）
act = np.stack([day_vector(pv_m, d) for d in range(365)])           # (365,144)
fcs = np.stack([np.stack([fc_m[j, d] for d in range(365)]) for j in range(4)])  # (4,365,144)
act_o, fcs_o = act[DS:DE], fcs[:, DS:DE]
hour_of = np.array([i // 6 if i < 143 else 24 for i in range(144)])  # 段->自然小时
DAYMASK = (act_o > 1.0) | (fcs_o.max(axis=0) > 1.0)                 # 白天有光伏段

# ---------------- A. 四次发布整体精度（仅各自覆盖窗口 + 白天段） ----------------
pub_stat = {}
for j, m in enumerate(PUB):
    cover = (hour_of[None, :] >= m) & DAYMASK                       # 覆盖且白天
    a = act_o[cover]; f = fcs_o[j][cover]
    err = f - a
    pub_stat['%d点' % m] = dict(
        n=int(cover.sum()),
        MAE=float(np.abs(err).mean()),
        RMSE=float(np.sqrt((err ** 2).mean())),
        bias=float(err.mean()),
        over_energy_wan_kwh=float(np.maximum(err, 0).sum() * H / 1e4),    # 高估能量(万kWh)
        under_energy_wan_kwh=float(np.maximum(-err, 0).sum() * H / 1e4),  # 低估能量
        mean_actual=float(a.mean()))
    print('%d点发布: MAE %.1f RMSE %.1f bias %+.1f 高估 %.2f万kWh 低估 %.2f万kWh'
          % (m, pub_stat['%d点' % m]['MAE'], pub_stat['%d点' % m]['RMSE'],
             pub_stat['%d点' % m]['bias'], pub_stat['%d点' % m]['over_energy_wan_kwh'],
             pub_stat['%d点' % m]['under_energy_wan_kwh']))

# ---------------- B. 提前量 lead hour（聚合四次发布） ----------------
lead_mae, lead_bias, lead_n = {}, {}, {}
for j, m in enumerate(PUB):
    cover = (hour_of[None, :] >= m) & DAYMASK
    for i in range(144):
        lead = hour_of[i] - m + 1          # 第 k 小时预报，提前量≈k
        col_mask = cover[:, i]
        if col_mask.sum() == 0:
            continue
        e = (fcs_o[j][:, i] - act_o[:, i])[col_mask]
        lead_mae.setdefault(lead, []).append(np.abs(e).mean())
        lead_bias.setdefault(lead, []).append(e.mean())
leads = sorted(lead_mae)
lead_mae_v = np.array([np.mean(lead_mae[k]) for k in leads])
lead_bias_v = np.array([np.mean(lead_bias[k]) for k in leads])

# ---------------- C. 日内24h分布（0点预报 vs 实际）+ 误差方向分布 ----------------
h_act = np.array([act_o[:, hour_of == h].mean() for h in range(24)])
h_fc0 = np.array([fcs_o[0][:, hour_of == h].mean() for h in range(24)])
h_mae = np.array([np.abs(fcs_o[0][:, hour_of == h] - act_o[:, hour_of == h]).mean() for h in range(24)])
daymask0 = DAYMASK
err_all = (fcs_o[0] - act_o)[daymask0]

# ---------------- D. 逐次更新信息增益（同一目标窗口） ----------------
windows = [('上午6-12时', 36, 72, [0, 1]),
           ('下午12-18时', 72, 108, [0, 1, 2]),
           ('傍晚18-24时', 108, 144, [0, 1, 2, 3])]
gain = {}
for name, i1, i2, js in windows:
    sub = DAYMASK[:, i1:i2]
    gain[name] = {}
    for j in js:
        e = (fcs_o[j][:, i1:i2] - act_o[:, i1:i2])[sub]
        gain[name]['%d点' % PUB[j]] = float(np.abs(e).mean())
    print(name, {k: round(v, 1) for k, v in gain[name].items()})

metrics = dict(pub_stat=pub_stat,
               lead_hour=[int(k) for k in leads], lead_MAE=lead_mae_v.tolist(),
               lead_bias=lead_bias_v.tolist(),
               hour_actual=h_act.tolist(), hour_fc0=h_fc0.tolist(), hour_MAE=h_mae.tolist(),
               update_gain=gain,
               allseg_MAE_0=float(np.abs(fcs_o[0] - act_o).mean()),
               over_total_wan=pub_stat['0点']['over_energy_wan_kwh'],
               under_total_wan=pub_stat['0点']['under_energy_wan_kwh'])
print('0点发布 全144段(含夜间)MAE=%.1f kW（与主模型口径衔接）' % metrics['allseg_MAE_0'])
json.dump(metrics, open(os.path.join(_HERE, '..', '..', '数据', 'error_metrics.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

# ================= 图E1：提前量精度 + 四次发布对比 =================
fig, (a1, a2) = plt.subplots(1, 2, figsize=(14.5, 5.2), dpi=200)
a1.plot(leads, lead_mae_v, '-o', color=C_MAIN, ms=4, lw=2, label='MAE')
a1.plot(leads, lead_bias_v, '--s', color=C_HI, ms=3.5, lw=1.6, label='平均偏差(预报-实际)')
a1.axhline(0, color='#888', lw=0.8)
a1.set_xlabel('预报提前量（小时）', fontsize=11); a1.set_ylabel('光伏功率误差 (kW)', fontsize=11)
a1.set_title('预报提前越久误差越大（信息时效衰减）', fontsize=12.5)
a1.grid(ls='--', alpha=0.4); a1.legend(fontsize=10)
xl = ['0点\n(全天)', '6点\n(6-24时)', '12点\n(12-24时)', '18点\n(18-24时)']; xx = np.arange(4)
over = [pub_stat['%d点' % m]['over_energy_wan_kwh'] for m in PUB]
under = [pub_stat['%d点' % m]['under_energy_wan_kwh'] for m in PUB]
a2.bar(xx - 0.2, over, 0.4, color=C_HI, label='高估能量(→5倍紧急购电风险)')
a2.bar(xx + 0.2, under, 0.4, color=C_LO, label='低估能量(→0.5倍下调退款)')
for i, v in enumerate(over):
    a2.text(i - 0.2, v + 1.5, '%.1f' % v, ha='center', fontsize=9)
for i, v in enumerate(under):
    a2.text(i + 0.2, v + 1.5, '%.1f' % v, ha='center', fontsize=9)
a2.set_xticks(xx); a2.set_xticklabels(xl, fontsize=9.5); a2.set_ylabel('能量（万kWh）', fontsize=11)
a2.set_title('各次预报的高估/低估能量（括号为其覆盖窗口）', fontsize=12)
a2.grid(axis='y', ls='--', alpha=0.4); a2.legend(fontsize=9.5, loc='upper right')
fig.suptitle('问题3 误差分析①：光伏预报误差的时效规律', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题3_误差_时效与发布精度.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ================= 图E2：日内分布 + 误差方向 =================
fig, (a1, a2) = plt.subplots(1, 2, figsize=(14.5, 5.2), dpi=200)
hh = np.arange(24)
a1.plot(hh, h_act, '-o', color=C_ACT, ms=3, lw=2, label='实际光伏(均值)')
a1.plot(hh, h_fc0, '--s', color=C_FC, ms=3, lw=1.8, label='0点预报(均值)')
a1b = a1.twinx()
a1b.bar(hh, h_mae, color='#D9D9D9', alpha=0.7, label='逐时MAE')
a1b.set_ylabel('逐时 MAE (kW)', color='#888')
a1.set_xlabel('时刻(h)', fontsize=11); a1.set_ylabel('光伏功率 (kW)', fontsize=11)
a1.set_xticks(range(0, 24, 2)); a1.set_title('日内：预报/实际曲线与逐时MAE', fontsize=12.5)
a1.grid(ls='--', alpha=0.3)
h1, l1 = a1.get_legend_handles_labels(); h2, l2 = a1b.get_legend_handles_labels()
a1.legend(h1 + h2, l1 + l2, fontsize=9, loc='upper left')
hist_c = np.where(err_all >= 0, C_HI, C_LO)
a2.hist(err_all, bins=60, color=C_MAIN, edgecolor='white', alpha=0.85)
a2.axvline(0, color='#333', lw=1.2)
a2.axvline(err_all.mean(), color=C_HI, ls='--', lw=1.8, label='平均偏差 %+.1f kW' % err_all.mean())
a2.set_xlabel('预报误差 = 预报 − 实际 (kW)', fontsize=11); a2.set_ylabel('段数', fontsize=11)
a2.set_title('误差方向分布：红区高估→紧急购电风险，绿区低估→可下调退款', fontsize=11.5)
a2.legend(fontsize=10); a2.grid(axis='y', ls='--', alpha=0.4)
fig.suptitle('问题3 误差分析②：误差的日内形态与不对称方向（0点预报，白天段）', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题3_误差_日内分布与方向.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ================= 图E3：更新信息增益 =================
fig, ax = plt.subplots(figsize=(12, 5.4), dpi=200)
wnames = [w[0] for w in windows]
pub_lab = ['0点预报', '6点更新', '12点更新', '18点更新']
colors = ['#B7CCE0', '#9BBBF4', '#E1B98F', '#4E79A7']
width = 0.18; xs = np.arange(len(wnames))
for k, lab in enumerate(pub_lab):
    vals, xp = [], []
    for wi, (wn, _, _, js) in enumerate(windows):
        if k in js:
            vals.append(gain[wn]['%d点' % PUB[k]]); xp.append(xs[wi] + (k - 1.5) * width)
    ax.bar(xp, vals, width, color=colors[k], label=lab)
    for x, v in zip(xp, vals):
        ax.text(x, v + 4, '%.0f' % v, ha='center', fontsize=9)
ax.set_xticks(xs); ax.set_xticklabels(wnames, fontsize=11)
ax.set_ylabel('目标窗口内 MAE (kW)', fontsize=11)
ax.set_title('逐次预报更新对同一目标窗口的误差削减（信息增益）', fontsize=12.5)
ax.grid(axis='y', ls='--', alpha=0.4); ax.legend(fontsize=10, ncol=4, loc='upper center')
fig.tight_layout()
p = os.path.join(FIGDIR, '问题3_误差_更新信息增益.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)
print('\n误差分析完成。')
