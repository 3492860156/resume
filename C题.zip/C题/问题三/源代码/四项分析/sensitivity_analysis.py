# -*- coding: utf-8 -*-
"""
问题3 分析③——敏感性分析（问题三特有参数 × 5 水平，逐场景全年滚动重解）
=====================================================================
5 个参数（每场景 365天×4次LP）：
  1) 上调溢价倍率 up   ：1.1/1.3/1.5/1.7/2.0（基线1.5）
  2) 下调退款率   dn   ：0.20/0.35/0.50/0.65/0.80（基线0.50）
  3) 紧急购电倍率 em   ：3/4/5/6/8（基线5）
  4) 预报误差强度 err_k：0/0.5/1.0/1.5/2.0（基线1.0；0=完美预报,越大预报越不准）
  5) 充放效率 η        ：0.85/0.875/0.90/0.925/0.95（基线0.90）
输出：sensitivity_results.json + 龙卷风图 + 参数曲线图（总费用 & 紧急购电量）
"""
import os, sys, json, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
from q3a_common import run_year_p, summarize, FIGDIR, ANADIR             # noqa
from q3_common import load_all                                          # noqa

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

LEVELS = {
    '上调溢价倍率': [1.1, 1.3, 1.5, 1.7, 2.0],
    '下调退款率': [0.20, 0.35, 0.50, 0.65, 0.80],
    '紧急购电倍率': [3, 4, 5, 6, 8],
    '预报误差强度': [0.0, 0.5, 1.0, 1.5, 2.0],
    '充放效率η': [0.85, 0.875, 0.90, 0.925, 0.95],
}
BASE = {'上调溢价倍率': 1.5, '下调退款率': 0.5, '紧急购电倍率': 5,
        '预报误差强度': 1.0, '充放效率η': 0.9}

data = load_all()
results = {}
t0 = time.time()
for pi, (param, levels) in enumerate(LEVELS.items()):
    results[param] = {}
    for lv in levels:
        kw = {}
        if param == '上调溢价倍率':
            kw['up'] = float(lv)
        elif param == '下调退款率':
            kw['dn'] = float(lv)
        elif param == '紧急购电倍率':
            kw['emult'] = float(lv)
        elif param == '预报误差强度':
            kw['err_k'] = float(lv)
        elif param == '充放效率η':
            kw['eta'] = float(lv)
        recs = run_year_p(data, stages=(36, 72, 108), **kw)
        m = summarize(recs)
        results[param][str(lv)] = dict(total_wan=m['total'] / 1e4,
                                       em_wan_kwh=m['em_kwh'] / 1e4,
                                       buy_wan=m['buy'] / 1e4)
        print('[%d/5] %s=%s  总费用%.1f万 紧急%.2f万kWh'
              % (pi + 1, param, lv, m['total'] / 1e4, m['em_kwh'] / 1e4), flush=True)
print('全部25场景耗时 %.1fs' % (time.time() - t0))
json.dump(results, open(os.path.join(ANADIR, '..', '..', '数据', 'sensitivity_results.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

params = list(LEVELS.keys())
base_cost = results['预报误差强度']['1.0']['total_wan']

# ---------- 龙卷风图 ----------
lo_pct, hi_pct, lo_lab, hi_lab = [], [], [], []
for p in params:
    lv = LEVELS[p]; cb = results[p][str(BASE[p])]['total_wan']
    cl, ch = results[p][str(lv[0])]['total_wan'], results[p][str(lv[-1])]['total_wan']
    lo_pct.append(100 * (cl - cb) / cb); hi_pct.append(100 * (ch - cb) / cb)
    lo_lab.append('%g' % lv[0]); hi_lab.append('%g' % lv[-1])
order = np.argsort([max(abs(a), abs(b)) for a, b in zip(lo_pct, hi_pct)])
po = [params[i] for i in order]
lo = [lo_pct[i] for i in order]; hi = [hi_pct[i] for i in order]
ll = [lo_lab[i] for i in order]; hl = [hi_lab[i] for i in order]
y = np.arange(len(po))
fig, ax = plt.subplots(figsize=(12.5, 5.6), dpi=200)
ax.barh(y - 0.2, lo, 0.4, color='#9BBBF4', label='低端水平')
ax.barh(y + 0.2, hi, 0.4, color='#E8A09A', label='高端水平')
for i in range(len(y)):
    ax.text(lo[i], y[i] - 0.2, '%+.1f%% (%s)' % (lo[i], ll[i]),
            ha='right' if lo[i] < 0 else 'left', va='center', fontsize=9.5)
    ax.text(hi[i], y[i] + 0.2, '%+.1f%% (%s)' % (hi[i], hl[i]),
            ha='left' if hi[i] > 0 else 'right', va='center', fontsize=9.5)
ax.axvline(0, color='#333', lw=1)
ax.set_yticks(y); ax.set_yticklabels(po, fontsize=11)
ax.set_xlabel('全年总费用相对基线(1591.05万元)的变化率 (%)', fontsize=12)
ax.set_title('问题3 敏感性①：参数两端扰动对全年总费用的影响（龙卷风图）', fontsize=13)
ax.grid(axis='x', ls='--', alpha=0.4); ax.legend(fontsize=11, loc='lower right')
lim = max(abs(np.array(lo + hi)).max() * 1.28, 1)
ax.set_xlim(-lim, lim); fig.tight_layout()
pth = os.path.join(FIGDIR, '问题3_敏感_龙卷风图.png'); fig.savefig(pth, bbox_inches='tight'); plt.close(fig); print('saved', pth)

# ---------- 参数曲线（总费用 + 紧急量 双轴） ----------
fig, axes = plt.subplots(1, 5, figsize=(19.5, 4.2), dpi=200)
for ax, param in zip(axes, params):
    lv = LEVELS[param]
    cost = [results[param][str(v)]['total_wan'] for v in lv]
    emq = [results[param][str(v)]['em_wan_kwh'] for v in lv]
    ax.plot(lv, cost, '-o', color='#4E79A7', lw=2, label='总费用(万元)')
    cb = results[param][str(BASE[param])]['total_wan']
    ax.axhline(cb, color='#999', ls=':', lw=1)
    axb = ax.twinx()
    axb.plot(lv, emq, '--s', color='#E15759', ms=4, lw=1.6, label='紧急购电量(万kWh)')
    ax.set_title(param, fontsize=11.5); ax.grid(ls='--', alpha=0.4)
    ax.tick_params(labelsize=8.5); axb.tick_params(labelsize=8.5)
    if param == params[0]:
        ax.set_ylabel('总费用(万元)', fontsize=10, color='#4E79A7')
    if param == params[-1]:
        axb.set_ylabel('紧急购电量(万kWh)', fontsize=10, color='#E15759')
fig.suptitle('问题3 敏感性②：五参数逐水平全年重解（实线=总费用，虚线=紧急购电量，点线=基线）', fontsize=13)
fig.tight_layout(rect=[0, 0, 1, 0.93])
pth = os.path.join(FIGDIR, '问题3_敏感_参数曲线.png'); fig.savefig(pth, bbox_inches='tight'); plt.close(fig); print('saved', pth)
print('\n敏感性分析完成。')
