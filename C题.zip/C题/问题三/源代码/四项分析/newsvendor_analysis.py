# -*- coding: utf-8 -*-
"""
问题3 · 多阶段滚动报童模型（Multi-stage Rolling Newsvendor）
================================================================
机理：购电申报面对随机光伏，等价于报童订货。
  临界分位 β* = c_u/(c_u+c_o)，c_u=单位短缺成本，c_o=单位过剩成本。
两层非平稳临界分位（本题三档电价倍率 1.0 / 1.5 / 5.0、下调违约金0.5）：
  · 计划层（之后还有调整机会）：少报可在下一层按1.5p补(c_u=0.5p)、
    多报可在下一层下调付0.5p违约金(c_o=0.5p) → β*=0.5（无偏，把决策推迟到信息更准）。
  · 执行层（本层之后再无调整、缺口只能5倍紧急购电）：
    c_u=5p-p=4p；多购若浪费 c_o=p → β*=0.8（保守多购）；若储能完全吸收 c_o→0 → β*→1。
落地：对每次发布 j，其"最终负责区间"[start,next) 用执行层分位 β，
      其余段（还有后续调整）用 0.5；把预报光伏下调到其(1-β)经验分位作为安全裕度，
      再送入与主模型完全相同的滚动 LP（储能/SOC/结算口径不变），唯一变量是申报保守度。
自检：β=0.5 时安全裕度恒为0，必须精确复现 M2 基线 1591.05 万元 / 紧急76.06万kWh。
"""
import os, sys, json, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from q3a_common import (load_all, day_vector, solve_plan_p, solve_adjust_p,
                        H, N, S_INIT, OUT_SLICE, FIGDIR, summarize)
from q3_common import PUB_HOURS

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
STAGES = (36, 72, 108)           # 完整调整 M3（=M2，18点无动作）
PUB_IDX = [h * 6 for h in PUB_HOURS]


# ============ 1. 逐(发布j, 提前小时lead)光伏预报误差经验分位（功率kW） ============
def build_error_quantiles(data):
    price, load_m, pv_m, fc_m, dates = data
    # samples[j][lead] = list(e=实际-预报, kW)，lead=目标绝对小时-发布小时
    samples = [[[] for _ in range(25)] for _ in range(4)]
    for d in range(*OUT_SLICE.indices(365)):
        pv = day_vector(pv_m, d)                  # 实际光伏功率 144
        for j, m in enumerate(PUB_HOURS):
            fc = fc_m[j, d]
            for i in range(N - 1):                # 排除跨午夜段143
                ah = i // 6; lead = ah - m
                if not (1 <= lead <= 24):
                    continue
                a, f = pv[i], fc[i]
                if a > 50 or f > 50:              # 仅白天段，排除夜间零样本
                    samples[j][lead].append(a - f)
    qtab = [[None] * 25 for _ in range(4)]
    for j in range(4):
        for lead in range(25):
            s = np.array(samples[j][lead])
            if s.size >= 20:
                qtab[j][lead] = dict(n=int(s.size),
                                     q={q: float(np.quantile(s, q)) for q in
                                        (0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50,
                                         0.60, 0.70, 0.80, 0.85, 0.90, 0.95)},
                                     mean=float(s.mean()), std=float(s.std()))
    return qtab


def margin_kw_for_beta(qtab, j, lead, beta):
    """执行层安全裕度(kW)=P50(e)-P_(1-β)(e)：把预报光伏从50分位下压到(1-β)分位。"""
    if beta <= 0.5001:
        return 0.0
    q = qtab[j][lead]
    if q is None:
        return 0.0
    return max(q['q'][0.50] - q['q'][round(1 - beta, 2)], 0.0)


# ============ 2. 注入报童安全裕度的单日滚动模拟（其余口径与主模型一致） ============
def exec_intervals(stages):
    """每次决策(发布j)最终负责、再无后续调整补救的执行层区间[start,next)。"""
    seq = [(0, 0)] + list(zip(range(1, 4), PUB_IDX[1:]))
    use = [t for t in seq if t[1] == 0 or t[1] in stages]
    starts = [t[1] for t in use]; js = [t[0] for t in use]
    iv = []
    for k in range(len(use)):
        nxt = starts[k + 1] if k + 1 < len(use) else N
        iv.append((js[k], starts[k], nxt))
    return iv


def simulate_nv(L, PVact, fc_day, price, s_init, qtab, beta, stages=STAGES,
                eta=0.9, emult=5.0, dn=0.5, up=1.5):
    e_max = H * 5000.0
    # 各发布执行层安全裕度(kWh)，计划层区间裕度=0
    fc_use = fc_day.copy()
    for j, lo, hi in exec_intervals(stages):
        m = PUB_HOURS[j]
        for i in range(lo, hi):
            ah = i // 6 if i < N - 1 else 24
            lead = ah - m
            if 1 <= lead <= 24:
                mk = margin_kw_for_beta(qtab, j, lead, beta) * H
                if mk > 0:
                    fc_use[j, i] = max(fc_day[j, i] - mk, 0.0)
    Xp, Cp, Dp, _, _, _ = solve_plan_p(L, fc_use[0], price, s_init)
    Xf, Cf, Df = Xp.copy(), Cp.copy(), Dp.copy()
    for j, i0 in zip((1, 2, 3), (36, 72, 108)):
        if i0 not in stages:
            continue
        s_i0 = s_init + float((eta * Cf[:i0] - Df[:i0]).sum())
        xa, ca, da, _, _, upv, dnv = solve_adjust_p(
            L, fc_use[j], price, s_i0, Xp, i0, eta=eta, emult=emult, dn=dn, up=up)
        Xf[i0:], Cf[i0:], Df[i0:] = xa, ca, da
    gap = L + Cf - Xf - eta * Df
    Eact = np.maximum(gap - PVact, 0.0)
    Sf = np.empty(N + 1); Sf[0] = s_init
    Sf[1:] = s_init + np.cumsum(eta * Cf - Df)
    dn_f = np.maximum(Xp - Xf, 0.0); up_f = np.maximum(Xf - Xp, 0.0)
    cost_plan = float((price * Xp).sum())
    cost_adj = float((-dn * price * dn_f + up * price * up_f).sum())
    cost_em = float((emult * price * Eact).sum())
    return dict(plan_buy=float(Xp.sum()), final_buy=float(Xf.sum()),
                up=float(up_f.sum()), dn=float(dn_f.sum()), em_buy=float(Eact.sum()),
                cost_buy=cost_plan + cost_adj, cost_em=cost_em,
                cost_tot=cost_plan + cost_adj + cost_em, s24=float(Sf[N]))


def run_year_nv(data, qtab, beta, stages=STAGES):
    price, load_m, pv_m, fc_m, dates = data
    recs = []; s_init = S_INIT
    for d in range(365):
        L = day_vector(load_m, d) * H
        PVact = day_vector(pv_m, d) * H
        fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
        r = simulate_nv(L, PVact, fc_day, price, s_init, qtab, beta, stages=stages)
        recs.append(r); s_init = r['s24']
    return recs


# ============ 3. 主流程 ============
def main():
    t0 = time.time(); data = load_all()
    price = data[0]
    qtab = build_error_quantiles(data)
    # 3.1 误差分位形态速览（0点发布，lead=6/9/12/15 对应6/9/12/15点）
    print('== 0点发布 光伏预报误差(实际-预报,kW) 分位速览 ==')
    for lead in (3, 6, 9, 12, 15):
        q = qtab[0][lead]
        if q:
            print('lead=%2dh n=%d P20=%7.1f P50=%7.1f P80=%7.1f std=%6.1f'
                  % (lead, q['n'], q['q'][0.2], q['q'][0.5], q['q'][0.8], q['std']))

    # 3.2 β 扫描（β=0.5 必须复现基线）
    betas = [0.50, 0.60, 0.70, 0.80, 0.85, 0.90, 0.95]
    scan = []
    for b in betas:
        t = time.time()
        m = summarize(run_year_nv(data, qtab, b))
        scan.append(dict(beta=b, total_wan=m['total'] / 1e4, buy_wan=m['buy'] / 1e4,
                         em_wan=m['em_kwh'] / 1e4, final_buy_wan=m['final_buy'] / 1e4,
                         up_wan=m['up'] / 1e4, dn_wan=m['dn'] / 1e4))
        print('β=%.2f 总费用%.2f万 购电侧%.2f万 紧急%.2f万kWh (%.1fs)'
              % (b, scan[-1]['total_wan'], scan[-1]['buy_wan'], scan[-1]['em_wan'], time.time() - t))
    base = scan[0]
    assert abs(base['total_wan'] - 1591.05) < 0.5, 'β=0.5未复现基线!'
    best = min(scan[1:], key=lambda z: z['total_wan'])
    print('经验最优 β=%.2f 总费用%.2f万，较点预报(β=0.5) %.2f万元'
          % (best['beta'], best['total_wan'], base['total_wan'] - best['total_wan']))

    # 3.3 闭式临界分位
    theory = {
        'plan_layer': {'cu': 0.5, 'co': 0.5, 'beta_star': 0.5,
                       'note': '少报下层1.5倍补(cu=0.5p)、多报下层下调0.5违约金(co=0.5p)，对称→无偏'},
        'exec_layer_waste': {'cu': 4.0, 'co': 1.0, 'beta_star': 4 / 5,
                             'note': '缺口5倍紧急(cu=4p)、多购浪费(co=p)→β*=0.80'},
        'exec_layer_storage': {'cu': 4.0, 'co': 0.0, 'beta_star': 1.0,
                               'note': '多购全部被储能吸收(co→0)→β*→1，理论上界'}}

    # 3.4 逐时安全裕度（β=0.8，各发布在其执行层）
    hourly = {}
    for j, m in enumerate(PUB_HOURS):
        xs, mar = [], []
        for ah in range(24):
            lead = ah - m
            if 1 <= lead <= 24:
                xs.append(ah); mar.append(margin_kw_for_beta(qtab, j, lead, 0.80))
        hourly[str(m)] = dict(hours=xs, margin_kw=mar)

    results = dict(theory=theory, scan=scan,
                   beta05=base, best=best,
                   saving_wan=base['total_wan'] - best['total_wan'],
                   hourly_margin=hourly)
    with open(os.path.join(_HERE, '..', '..', '数据', 'newsvendor_results.json'), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # ============ 图N1 临界分位阶梯 ============
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 4.8), dpi=200)
    layers = ['计划层\n(之后还能调整)', '执行层\n(多购浪费)', '执行层\n(多购入储能)']
    bv = [0.5, 0.8, 1.0]; cols = ['#4E79A7', '#E1812C', '#8C8C8C']
    bars = a1.bar(layers, bv, color=cols, width=0.55)
    for r, v in zip(bars, bv):
        a1.text(r.get_x() + r.get_width() / 2, v + 0.02, 'β*=%.2f' % v, ha='center', fontsize=11, fontweight='bold')
    a1.set_ylim(0, 1.12); a1.set_ylabel('临界分位 β*=c_u/(c_u+c_o)')
    a1.set_title('两层非平稳临界分位：越临近执行越应保守多购')
    a1.axhline(0.5, color='#4E79A7', ls=':', lw=1)
    # 剩余调整次数→β
    kk = ['k=2\n(0点,后有2次)', 'k=1\n(6/12点,后有1次)', 'k=0\n(执行层,无补救)']
    a2.step([0, 1, 2], [0.5, 0.5, 0.8], where='post', marker='o', color='#E1812C', lw=2.2)
    for x, y, t in zip([0, 1, 2], [0.5, 0.5, 0.8], ['0.50', '0.50', '0.80']):
        a2.text(x, y + 0.04, t, ha='center', fontsize=11, fontweight='bold')
    a2.set_xticks([0, 1, 2]); a2.set_xticklabels(kk); a2.set_ylim(0, 1.05)
    a2.set_ylabel('该决策临界分位 β*'); a2.grid(ls='--', alpha=0.4, axis='y')
    a2.set_title('剩余调整机会越少，临界分位越高（滚动报童）')
    fig.suptitle('问题3 报童①：临界分位的两层结构与多阶段演化', fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    p1 = os.path.join(FIGDIR, '问题3_报童_临界分位阶梯.png'); fig.savefig(p1, bbox_inches='tight'); plt.close(fig)

    # ============ 图N2 逐时误差分位带与安全裕度 ============
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.5, 4.8), dpi=200)
    hrs = np.arange(24)
    for j, m, c in [(0, 0, '#B7CCE0'), (1, 6, '#9BBBF4'), (2, 12, '#E1812C')]:
        p20 = [qtab[j][ah - m]['q'][0.2] if (1 <= ah - m <= 24 and qtab[j][ah - m]) else np.nan for ah in hrs]
        p80 = [qtab[j][ah - m]['q'][0.8] if (1 <= ah - m <= 24 and qtab[j][ah - m]) else np.nan for ah in hrs]
        a1.plot(hrs, p20, color=c, lw=1.4); a1.plot(hrs, p80, color=c, lw=1.4, label='%d点发布 P20/P80' % m)
        a1.fill_between(hrs, p20, p80, color=c, alpha=0.25)
    a1.axhline(0, color='#555', lw=1); a1.set_xticks(range(0, 24, 2)); a1.set_xlabel('目标小时'); a1.set_ylabel('光伏预报误差 实际−预报 (kW)')
    a1.set_title('各发布预报误差 P20–P80 带（午间最宽）'); a1.legend(fontsize=9); a1.grid(ls='--', alpha=0.4)
    for m, c in [(0, '#B7CCE0'), (6, '#9BBBF4'), (12, '#E1812C')]:
        h = hourly[str(m)]
        a2.plot(h['hours'], h['margin_kw'], marker='o', ms=3, color=c, label='%d点发布执行层裕度' % m)
    a2.set_xticks(range(0, 24, 2)); a2.set_xlabel('目标小时'); a2.set_ylabel('β=0.8 安全裕度 (kW)')
    a2.set_title('保守多购裕度集中在光伏波动段，夜间为0'); a2.legend(fontsize=9); a2.grid(ls='--', alpha=0.4)
    fig.suptitle('问题3 报童②：误差分位带与逐时安全裕度（β=0.8）', fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    p2 = os.path.join(FIGDIR, '问题3_报童_误差分位与安全裕度.png'); fig.savefig(p2, bbox_inches='tight'); plt.close(fig)

    # ============ 图N3 β扫描微笑曲线 ============
    bx = [s['beta'] for s in scan]; ty = [s['total_wan'] for s in scan]; ey = [s['em_wan'] for s in scan]
    fig, ax1 = plt.subplots(figsize=(9.5, 5.2), dpi=200)
    ax1.plot(bx, ty, 'o-', color='#4E79A7', lw=2.2, label='全年总费用(万元)')
    ax1.set_xlabel('执行层申报分位 β（计划层恒为0.5）'); ax1.set_ylabel('全年总费用（万元）', color='#4E79A7')
    ax1.tick_params(axis='y', labelcolor='#4E79A7')
    ax1.axvline(0.8, color='#E1812C', ls='--', lw=1.8, label='闭式理论 β*=0.80')
    ax1.plot(best['beta'], best['total_wan'], '*', ms=18, color='#D62728')
    ax1.annotate('经验最优 β=%.2f\n%.1f万元' % (best['beta'], best['total_wan']),
                 (best['beta'], best['total_wan']), xytext=(best['beta'] - 0.28, best['total_wan'] + 25),
                 fontsize=10, color='#D62728', arrowprops=dict(arrowstyle='->', color='#D62728'))
    ax2 = ax1.twinx()
    ax2.plot(bx, ey, 's--', color='#8C8C8C', lw=1.8, label='紧急购电量(万kWh)')
    ax2.set_ylabel('紧急购电量（万kWh）', color='#8C8C8C'); ax2.tick_params(axis='y', labelcolor='#8C8C8C')
    l1, la1 = ax1.get_legend_handles_labels(); l2, la2 = ax2.get_legend_handles_labels()
    ax1.legend(l1 + l2, la1 + la2, loc='upper center', fontsize=9.5)
    ax1.grid(ls='--', alpha=0.4); ax1.set_title('问题3 报童③：申报分位β扫描——理论分位与经验最优点互证')
    fig.tight_layout()
    p3 = os.path.join(FIGDIR, '问题3_报童_分位扫描微笑曲线.png'); fig.savefig(p3, bbox_inches='tight'); plt.close(fig)

    # ============ 图N4 策略对比 ============
    m0 = summarize(run_year_nv(data, qtab, 0.5, stages=()))     # 不调整
    groups = ['总费用', '购电侧费用', '紧急购电费']
    v_base = [base['total_wan'], base['buy_wan'], base['total_wan'] - base['buy_wan']]
    v_nv = [best['total_wan'], best['buy_wan'], best['total_wan'] - best['buy_wan']]
    v_m0 = [m0['total'] / 1e4, m0['buy'] / 1e4, m0['em_cost'] / 1e4]
    x = np.arange(3); w = 0.26
    fig, ax = plt.subplots(figsize=(9, 5.2), dpi=200)
    b1 = ax.bar(x - w, v_m0, w, label='M0 不调整', color='#B7CCE0')
    b2 = ax.bar(x, v_base, w, label='点预报滚动 β=0.5（现状M2）', color='#4E79A7')
    b3 = ax.bar(x + w, v_nv, w, label='滚动报童 β=%.2f' % best['beta'], color='#E1812C')
    for bs in (b1, b2, b3):
        for r in bs:
            ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 8, '%.1f' % r.get_height(),
                    ha='center', fontsize=8.5)
    ax.set_xticks(x); ax.set_xticklabels(groups); ax.set_ylabel('万元')
    ax.set_title('问题3 报童④：报童安全裕度策略 vs 现状滚动 vs 不调整')
    ax.legend(); ax.grid(ls='--', alpha=0.4, axis='y')
    fig.tight_layout()
    p4 = os.path.join(FIGDIR, '问题3_报童_策略对比.png'); fig.savefig(p4, bbox_inches='tight'); plt.close(fig)

    print('全部完成，耗时 %.1fs' % (time.time() - t0))
    for p in (p1, p2, p3, p4):
        print('saved', p)


if __name__ == '__main__':
    main()
