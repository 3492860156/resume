# -*- coding: utf-8 -*-
"""
问题3 紧急购电判据对照实验
=====================================================================
回答"紧急购电的判断方式是否过于单一"：
  判据A（主模型/现口径，策略冻结）：
        逐10分钟段按最终计划 Xf,Cf,Df 执行，储能计划锁死，实际光伏填不满的
        缺口只能 5 倍紧急购电： gap = L+Cf-Xf-ηDf; E=max(gap-PVact,0)
  判据B（允许储能实时再调度，购电合同Xf固定，oracle已知当日实际光伏）：
        执行时允许临时减充/增放（受SOC[1200,10800]、功率5000kW约束），
        只有储能也无能为力时才紧急购电——解一个"购电固定、储能可实时最优"
        的全天LP，得到物理上可被储能临机挽回之后的【最小必要紧急购电】。
  判据C（全信息，连购电都可按实际重排=问题二口径）：理论下界，紧急≈0。
A-B = 冻结策略的保守量（允许实时调储能可挽回）；B-C = 购电合同已定、只能靠
日内1.5倍上调才能挽回的量；C 才是物理硬缺口。三档夹逼，检验主判据稳健性。
"""
import os, sys, json
import numpy as np
from scipy.optimize import linprog

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, '..', '求解模型'))
from q3_common import H, N, load_all, day_vector, ETA, E_MAX, S_MIN, S_MAX, EMULT  # noqa
from q3a_common import get_baseline_seg, ANADIR                                       # noqa

data = load_all()
price, load_m, pv_m, fc_m, dates = data
base = get_baseline_seg(data)
Xf, Cf, Df = base['Xf'], base['Cf'], base['Df']
DS = 31


def crit_A_frozen(d):
    """判据A：策略冻结，逐段功率平衡（现主模型口径）。"""
    L = day_vector(load_m, d) * H
    PV = day_vector(pv_m, d) * H
    gap = L + Cf[d] - Xf[d] - ETA * Df[d]
    E = np.maximum(gap - PV, 0.0)
    return float(E.sum()), float((EMULT * price * E).sum())


def crit_B_resched(d):
    """判据B：购电Xf固定，储能可实时再调度(全天oracle实际光伏)，最小化紧急购电。
    变量 c|d|u|e|w 各144, S(145)；w=购电过剩弃电量(合同多买、储能装不下)。"""
    L = day_vector(load_m, d) * H
    PV = day_vector(pv_m, d) * H
    X = Xf[d]; s0 = float(base['Sf'][d][0])
    nv = 5 * N + (N + 1)
    o = {'c': 0, 'd': N, 'u': 2 * N, 'e': 3 * N, 'w': 4 * N, 'S': 5 * N}
    vid = lambda i, k: o[k] + i
    obj = np.zeros(nv); obj[o['e']:o['e'] + N] = EMULT * price      # 只最小化5倍紧急购电
    A = np.zeros((2 * N, nv)); b = np.zeros(2 * N)
    for i in range(N):       # 母线: -c+ηd+u+e-w = L-X
        A[i, vid(i, 'c')] = -1; A[i, vid(i, 'd')] = ETA
        A[i, vid(i, 'u')] = 1; A[i, vid(i, 'e')] = 1; A[i, vid(i, 'w')] = -1
        b[i] = L[i] - X[i]
        A[N + i, vid(i + 1, 'S')] = 1; A[N + i, vid(i, 'S')] = -1
        A[N + i, vid(i, 'c')] = -ETA; A[N + i, vid(i, 'd')] = 1
    bounds = [(0.0, None)] * nv
    for i in range(N):
        bounds[vid(i, 'c')] = (0, E_MAX); bounds[vid(i, 'd')] = (0, E_MAX)
        bounds[vid(i, 'u')] = (0, PV[i])
    for i in range(N + 1):
        bounds[vid(i, 'S')] = (S_MIN, S_MAX)
    bounds[vid(0, 'S')] = (s0, s0)
    res = linprog(obj, A_eq=A, b_eq=b, bounds=bounds, method='highs')
    if not res.success:
        raise RuntimeError('判据B LP失败 d=%d %s' % (d, res.message))
    E = res.x[o['e']:o['e'] + N]
    return float(E.sum()), float((EMULT * price * E).sum())


A_q, A_c, B_q, B_c = 0.0, 0.0, 0.0, 0.0
for d in range(DS, 365):
    aq, ac = crit_A_frozen(d); bq, bc = crit_B_resched(d)
    A_q += aq; A_c += ac; B_q += bq; B_c += bc
    if (d - DS + 1) % 80 == 0:
        print('  判据对照进度 %d/334' % (d - DS + 1), flush=True)

# 判据C：问题二全信息口径（报告值）
C_q, C_c = 0.0, 0.0
out = dict(
    A_frozen=dict(em_kwh_wan=A_q / 1e4, em_cost_wan=A_c / 1e4,
                  desc='策略冻结：储能按计划锁死，缺口全由5倍紧急购电兜底（主模型口径）'),
    B_resched=dict(em_kwh_wan=B_q / 1e4, em_cost_wan=B_c / 1e4,
                   desc='购电合同固定、储能允许实时减充增放后的最小必要紧急购电'),
    C_fullinfo=dict(em_kwh_wan=C_q / 1e4, em_cost_wan=C_c / 1e4,
                    desc='全信息(连购电都按实际重排=问题二)：理论下界，紧急≈0'),
    recover_by_storage_wan_kwh=(A_q - B_q) / 1e4,
    note='A-B 为允许储能临机调节可挽回的紧急购电；主口径A是偏保守的上界')
json.dump(out, open(os.path.join(ANADIR, '..', '..', '数据', 'emergency_criteria_compare.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)
print('\n===== 紧急购电判据全年对照（334天）=====')
print('判据A 策略冻结   : 紧急 %.2f 万kWh / %.2f 万元' % (A_q / 1e4, A_c / 1e4))
print('判据B 储能再调度 : 紧急 %.2f 万kWh / %.2f 万元' % (B_q / 1e4, B_c / 1e4))
print('A-B 储能临机可挽回: %.2f 万kWh (%.1f%%)' % ((A_q - B_q) / 1e4, 100 * (A_q - B_q) / A_q))
