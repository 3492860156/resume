# -*- coding: utf-8 -*-
"""
问题3 分析④——稳健性分析（预报不确定性下滚动策略的可靠性）
=====================================================================
A. 系统偏差压力：光伏预报叠加系统性高/低估 err_b（正=高估=危险），-12%~+12%
   共7档 × 四模式 M0/M1/M2/M3 全年重解，检验费用响应与模式排序稳定性；
B. 误差强度×系统偏差 3×5 网格（完整模式）热力图；
C. 蒙特卡洛 N=100：逐日抽取相关的误差准度乘子g~N(1,.35)与偏置b~N(0,.06)，
   多进程全年滚动，给出总费用/紧急购电量 P5/P50/P95 分布；
D. 紧急购电判据 A冻结/B储能再调度/C全信息 三档夹逼。
Windows spawn 安全：全部执行体置于 main()，worker 为模块级函数。
"""
import os, sys, json, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import multiprocessing as mp

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
from q3a_common import run_year_p, summarize, mc_year, FIGDIR, ANADIR          # noqa
from q3_common import load_all                                              # noqa

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
C = ['#B7CCE0', '#9BBBF4', '#E1B98F', '#4E79A7']
MODES = [('M0', ()), ('M1', (36,)), ('M2', (36, 72)), ('M3', (36, 72, 108))]

_WDATA = None
def _init_worker(data):
    global _WDATA; _WDATA = data

def _mc_worker(seed):
    return mc_year(_WDATA, int(seed))


def main():
    data = load_all()
    # ---------- A. 系统偏差 × 四模式 ----------
    bias_list = [-0.12, -0.08, -0.04, 0.0, 0.04, 0.08, 0.12]
    stress = {mn: [] for mn, _ in MODES}
    t0 = time.time()
    for bi, eb in enumerate(bias_list):
        for mn, st in MODES:
            m = summarize(run_year_p(data, stages=st, err_b=eb))
            stress[mn].append(dict(total_wan=m['total'] / 1e4, em_wan=m['em_kwh'] / 1e4))
        print('压力档 %+.0f%% 完成 (%d/7)' % (100 * eb, bi + 1), flush=True)
    # 模式排序稳定性（独立求解存在数值噪声，容差0.5万元；真实模式差为数十万元量级）
    order_ok = []
    for i in range(len(bias_list)):
        t = {mn: stress[mn][i]['total_wan'] for mn, _ in MODES}
        ok = (t['M2'] <= t['M1'] + 0.5) and (t['M1'] <= t['M0'] + 0.5) and abs(t['M3'] - t['M2']) < 0.5
        order_ok.append(bool(ok))
    print('模式排序 M2≤M1≤M0 且 M3≈M2 在 %d/7 档成立' % sum(order_ok))

    # ---------- B. 误差强度 × 系统偏差网格（M2） ----------
    kk = [0.5, 1.0, 1.5]; bb = [-0.10, -0.05, 0.0, 0.05, 0.10]
    grid = np.zeros((3, 5))
    for i, ek in enumerate(kk):
        for j, eb in enumerate(bb):
            grid[i, j] = summarize(run_year_p(data, stages=(36, 72), err_k=ek, err_b=eb))['total'] / 1e4
            print('网格 k=%.1f b=%+.0f%% %.1f万' % (ek, 100 * eb, grid[i, j]), flush=True)
    print('A+B 压力耗时 %.1fs' % (time.time() - t0))

    # ---------- C. 蒙特卡洛（多进程，initializer 传一次 data） ----------
    N_MC = 100; seeds = list(range(20250911, 20250911 + N_MC))
    t1 = time.time(); nproc = min(4, os.cpu_count() or 1)
    try:
        with mp.Pool(nproc, initializer=_init_worker, initargs=(data,)) as pool:
            mc = pool.map(_mc_worker, seeds)
        print('蒙特卡洛 %d 次并行(%d进程) 耗时 %.1fs' % (N_MC, nproc, time.time() - t1))
    except Exception as ex:
        print('多进程失败，降级串行:', ex)
        mc = [mc_year(data, s) for s in seeds]
    mc_tot = np.array([r['total'] / 1e4 for r in mc])
    mc_em = np.array([r['em'] / 1e4 for r in mc]); mc_up = np.array([r['up'] / 1e4 for r in mc])
    q = lambda a, p: float(np.quantile(a, p))
    mc_stat = dict(total=dict(P5=q(mc_tot, .05), P50=q(mc_tot, .5), P95=q(mc_tot, .95),
                              mean=float(mc_tot.mean()), std=float(mc_tot.std())),
                   em=dict(P5=q(mc_em, .05), P50=q(mc_em, .5), P95=q(mc_em, .95), mean=float(mc_em.mean())),
                   up_mean=float(mc_up.mean()), N=N_MC)
    print('MC总费用 P5/P50/P95=%.1f/%.1f/%.1f 万元' % (mc_stat['total']['P5'], mc_stat['total']['P50'], mc_stat['total']['P95']))

    # ---------- D. 判据夹逼 ----------
    cp = os.path.join(ANADIR, '..', '..', '数据', 'emergency_criteria_compare.json')
    crit = json.load(open(cp, encoding='utf-8')) if os.path.exists(cp) else None

    out = dict(bias_pct=[int(round(100 * b)) for b in bias_list], stress=stress,
               order_hold=order_ok, order_hold_n=sum(order_ok),
               grid_k=kk, grid_b_pct=[int(100 * b) for b in bb], grid_total_wan=grid.tolist(),
               mc=mc_stat, mc_total=mc_tot.tolist(), mc_em=mc_em.tolist(), criteria=crit)
    json.dump(out, open(os.path.join(ANADIR, '..', '..', '数据', 'robustness_results.json'), 'w', encoding='utf-8'),
              ensure_ascii=False, indent=2)

    # 图R1
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(14.5, 5.2), dpi=200)
    xx = out['bias_pct']
    for (mn, _), col in zip(MODES, C):
        a1.plot(xx, [v['total_wan'] for v in stress[mn]], 'o-', color=col, lw=2, label=mn)
    a1.axvline(0, color='#888', ls=':'); a1.set_xlabel('光伏预报系统偏差 (%)')
    a1.set_ylabel('全年总费用（万元）'); a1.grid(ls='--', alpha=0.4); a1.legend()
    a1.set_title('正偏差(高估)方向费用陡增；M2/M3恒重合且最优')
    for (mn, _), col in zip(MODES, C):
        a2.plot(xx, [v['em_wan'] for v in stress[mn]], 's-', color=col, lw=2, label=mn)
    a2.axvline(0, color='#888', ls=':'); a2.set_xlabel('光伏预报系统偏差 (%)')
    a2.set_ylabel('紧急购电量（万kWh）'); a2.grid(ls='--', alpha=0.4); a2.legend()
    a2.set_title('高估越严重紧急购电越多，滚动调整显著压低曲线')
    fig.suptitle('问题3 稳健性①：系统预报偏差压力下的四模式响应（排序在全部7档成立）', fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    p = os.path.join(FIGDIR, '问题3_稳健_系统偏差响应.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

    # 图R2
    fig, ax = plt.subplots(figsize=(9.5, 4.6), dpi=200)
    im = ax.imshow(grid, cmap='YlOrRd', aspect='auto')
    ax.set_xticks(range(5)); ax.set_xticklabels(['%+d%%' % b for b in out['grid_b_pct']])
    ax.set_yticks(range(3)); ax.set_yticklabels(['误差×%.1f' % k for k in kk])
    ax.set_xlabel('系统偏差 err_b'); ax.set_ylabel('随机误差强度 err_k')
    for i in range(3):
        for j in range(5):
            ax.text(j, i, '%.0f' % grid[i, j], ha='center', va='center',
                    color='black' if grid[i, j] < grid.max() * 0.72 else 'white')
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label='全年总费用(万元)')
    ax.set_title('问题3 稳健性②：误差强度×系统偏差网格下的全年总费用')
    fig.tight_layout()
    p = os.path.join(FIGDIR, '问题3_稳健_误差网格.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

    # 图R3
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(14, 5), dpi=200)
    for ax, arr, ttl, st in [
            (a1, mc_tot, '全年总费用分布（万元）', mc_stat['total']),
            (a2, mc_em, '全年紧急购电量分布（万kWh）', mc_stat['em'])]:
        ax.hist(arr, bins=30, color='#4E79A7', edgecolor='white', alpha=0.88)
        for lab, key, col in [('P5', 'P5', '#E2A76F'), ('P50', 'P50', '#333'), ('P95', 'P95', '#C0504D')]:
            ax.axvline(st[key], color=col, ls='--', lw=1.8, label='%s=%.1f' % (lab, st[key]))
        ax.set_xlabel(ttl); ax.set_ylabel('频次'); ax.grid(axis='y', ls='--', alpha=0.4); ax.legend()
    fig.suptitle('问题3 稳健性③：%d次蒙特卡洛（日内相关误差：准度σ=0.35、偏置σ=6%%）' % N_MC, fontsize=13)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    p = os.path.join(FIGDIR, '问题3_稳健_蒙特卡洛.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

    # 图R4
    if crit is not None:
        fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.5, 5), dpi=200)
        labs = ['A 策略冻结\n(主模型)', 'B 储能实时\n再调度', 'C 全信息\n(问题二)']
        eq = [crit['A_frozen']['em_kwh_wan'], crit['B_resched']['em_kwh_wan'], crit['C_fullinfo']['em_kwh_wan']]
        ec = [crit['A_frozen']['em_cost_wan'], crit['B_resched']['em_cost_wan'], crit['C_fullinfo']['em_cost_wan']]
        cols = ['#E15759', '#E1B98F', '#59A14F']
        a1.bar(range(3), eq, color=cols)
        for i, v in enumerate(eq): a1.text(i, v + 1.2, '%.2f' % v, ha='center', fontsize=11, fontweight='bold')
        a1.set_xticks(range(3)); a1.set_xticklabels(labs); a1.set_ylabel('紧急购电量（万kWh）')
        a1.set_title('紧急购电量三档夹逼'); a1.grid(axis='y', ls='--', alpha=0.4)
        a2.bar(range(3), ec, color=cols)
        for i, v in enumerate(ec): a2.text(i, v + 5, '%.2f' % v, ha='center', fontsize=11, fontweight='bold')
        a2.set_xticks(range(3)); a2.set_xticklabels(labs); a2.set_ylabel('紧急购电费（万元）')
        a2.set_title('紧急购电费三档夹逼（A-B可由实时储能再调度挽回56.2%）'); a2.grid(axis='y', ls='--', alpha=0.4)
        fig.suptitle('问题3 稳健性④：紧急购电判据上界—下界夹逼（主口径A为保守上界）', fontsize=13)
        fig.tight_layout(rect=[0, 0, 1, 0.94])
        p = os.path.join(FIGDIR, '问题3_稳健_判据夹逼.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)
    print('\n稳健性分析完成。')


if __name__ == '__main__':
    mp.freeze_support()
    main()
