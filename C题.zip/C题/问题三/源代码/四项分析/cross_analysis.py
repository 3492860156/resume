# -*- coding: utf-8 -*-
"""
问题3 分析②——交叉分析（时间 × 时段 × 调整模式 × 预报误差 多维交叉）
=====================================================================
全部基于主模型既有输出做"只读后处理"，不改变任何最优结果：
  A. 四调整模式 M0/M1/M2/M3 全年费用构成与逐级边际节约；
  B. 三次调整(6/12/18点)的上调/下调修正量、边际价值；
  C. 24小时时段 × 紧急购电/上调/下调（紧急集中白天光伏段）；
  D. 月份 × 滚动调整净收益、紧急购电量；
  E. 日尺度：0点预报高估能量 → 实际紧急购电量 的传导散点(Pearson r)，
     散点落在 y=x 下方的部分即被储能/调整缓冲的高估量。
输出：cross_metrics.json + 4 张图。
"""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.join(_HERE, '..', '求解模型'))
from q3_common import load_all, day_vector, H                                  # noqa
from q3a_common import run_year_p, get_baseline_seg, FIGDIR, ANADIR           # noqa

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
C_EM, C_UP, C_DN, C_MAIN, C_SAVE = '#E15759', '#E1B98F', '#9BBBF4', '#4E79A7', '#59A14F'
DS = 31

print('加载数据并求解四模式（每个约12s）...')
data = load_all()
price, load_m, pv_m, fc_m, dates = data
MODES = [('M0_不调整', ()), ('M1_仅6点', (36,)), ('M2_6+12点', (36, 72)),
         ('M3_完整', (36, 72, 108))]
mode_recs = {}
for name, st in MODES:
    mode_recs[name] = run_year_p(data, stages=st, verbose=False)
    print('  solved', name, flush=True)
base = get_baseline_seg(data)                 # 完整模式逐段(已缓存)


def agg(recs, key):
    return float(sum(r[key] for r in recs[DS:]))


mode_tab = {}
for name, _ in MODES:
    recs = mode_recs[name]
    mode_tab[name] = dict(total=agg(recs, 'cost_tot'), buy=agg(recs, 'cost_buy'),
                          em_cost=agg(recs, 'cost_em'), em_kwh=agg(recs, 'em_buy'),
                          up=agg(recs, 'up'), dn=agg(recs, 'dn'))
m0 = mode_tab['M0_不调整']['total']
for name in mode_tab:
    mode_tab[name]['save_vs_M0'] = m0 - mode_tab[name]['total']
margin = {
    '6点边际节约(万元)': (mode_tab['M0_不调整']['total'] - mode_tab['M1_仅6点']['total']) / 1e4,
    '12点边际节约(万元)': (mode_tab['M1_仅6点']['total'] - mode_tab['M2_6+12点']['total']) / 1e4,
    '18点边际节约(万元)': (mode_tab['M2_6+12点']['total'] - mode_tab['M3_完整']['total']) / 1e4}
print('逐级边际节约(万元):', {k: round(v, 3) for k, v in margin.items()})

# B. 三次调整的上调/下调量（完整模式 adj_log）
adj_sum = {36: dict(up=0.0, dn=0.0), 72: dict(up=0.0, dn=0.0), 108: dict(up=0.0, dn=0.0)}
for r in mode_recs['M3_完整'][DS:]:
    for a in r['adj_log']:
        adj_sum[a['at']]['up'] += a['up']; adj_sum[a['at']]['dn'] += a['dn']

# C. 24小时时段分布（完整模式逐段）
hour = np.array([i // 6 if i < 143 else 24 for i in range(144)])
Eseg, Upseg, Dnseg = base['Eact'][DS:], base['upseg'][DS:], base['dnseg'][DS:]
h_em = np.array([Eseg[:, hour == h].sum() for h in range(24)]) / 1e4
h_up = np.array([Upseg[:, hour == h].sum() for h in range(24)]) / 1e4
h_dn = np.array([Dnseg[:, hour == h].sum() for h in range(24)]) / 1e4

# D. 月度：M2总费用、调整净收益(M0-M2)、M2紧急量
months = list(range(2, 13))
mon_tot, mon_save, mon_em = [], [], []
for m in months:
    idx = [i for i in range(DS, 365) if int(str(dates[i])[5:7]) == m]
    t2 = sum(mode_recs['M2_6+12点'][i]['cost_tot'] for i in idx)
    t0 = sum(mode_recs['M0_不调整'][i]['cost_tot'] for i in idx)
    mon_tot.append(t2 / 1e4); mon_save.append((t0 - t2) / 1e4)
    mon_em.append(sum(mode_recs['M2_6+12点'][i]['em_buy'] for i in idx) / 1e4)

# E. 日"执行时最新预报"高估能量 vs 实际紧急购电量
#    段[0,36)依0点报、[36,72)依6点报、[72,108)依12点报、[108,144)依18点报
j_of_i = np.array([0] * 36 + [1] * 36 + [2] * 36 + [3] * 36)
fc_exec = np.zeros((365, 144))
for i in range(144):
    fc_exec[:, i] = fc_m[j_of_i[i], :, i]
day_over, day_em = [], []
for d in range(DS, 365):
    pv_act = day_vector(pv_m, d)
    over = np.maximum(fc_exec[d] - pv_act, 0).sum() * H   # 最新有效预报高估能量 kWh
    day_over.append(over); day_em.append(base['Eact'][d].sum())
day_over, day_em = np.array(day_over), np.array(day_em)
r_pearson = float(np.corrcoef(day_over, day_em)[0, 1])
print('日高估能量 vs 日紧急购电量 Pearson r = %.3f' % r_pearson)

out = dict(mode_tab=mode_tab, margin=margin,
           adj_sum={str(k): v for k, v in adj_sum.items()},
           hour_em=h_em.tolist(), hour_up=h_up.tolist(), hour_dn=h_dn.tolist(),
           months=months, mon_tot=mon_tot, mon_save=mon_save, mon_em=mon_em,
           pearson_over_em=r_pearson,
           day_over=day_over.tolist(), day_em=day_em.tolist())
json.dump(out, open(os.path.join(ANADIR, '..', '..', '数据', 'cross_metrics.json'), 'w', encoding='utf-8'),
          ensure_ascii=False, indent=2)

# ============ 图C1：时段×紧急/上调/下调 ============
fig, ax = plt.subplots(figsize=(13.5, 5.2), dpi=200)
hh = np.arange(24); w = 0.27
ax.bar(hh - w, h_em, w, color=C_EM, label='紧急购电量')
ax.bar(hh, h_up, w, color=C_UP, label='上调量(1.5倍)')
ax.bar(hh + w, h_dn, w, color=C_DN, label='下调量(0.5倍退款)')
ax.set_xticks(hh); ax.set_xlabel('时刻(h)', fontsize=11)
ax.set_ylabel('电量（万kWh）', fontsize=11)
ax.set_title('24小时时段交叉：紧急购电与调整全部集中在5-18时光伏段，夜间为0', fontsize=12.5)
ax.grid(axis='y', ls='--', alpha=0.4); ax.legend(fontsize=10, ncol=3)
fig.tight_layout()
p = os.path.join(FIGDIR, '问题3_交叉_时段紧急与调整.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ============ 图C2：调整时刻价值 ============
fig, (a1, a2) = plt.subplots(1, 2, figsize=(14.5, 5.2), dpi=200)
labs = ['6:00调整', '12:00调整', '18:00调整']; ats = [36, 72, 108]; xx = np.arange(3)
ups = [adj_sum[a]['up'] / 1e4 for a in ats]; dns = [adj_sum[a]['dn'] / 1e4 for a in ats]
a1.bar(xx - 0.2, ups, 0.4, color=C_UP, label='累计上调量')
a1.bar(xx + 0.2, dns, 0.4, color=C_DN, label='累计下调量')
for i in range(3):
    a1.text(i - 0.2, ups[i] + 0.6, '%.1f' % ups[i], ha='center', fontsize=9)
    a1.text(i + 0.2, dns[i] + 0.6, '%.1f' % dns[i], ha='center', fontsize=9)
a1.set_xticks(xx); a1.set_xticklabels(labs); a1.set_ylabel('万kWh', fontsize=11)
a1.set_title('各次调整的上/下调修正量（18点修正≈0）', fontsize=12)
a1.grid(axis='y', ls='--', alpha=0.4); a1.legend(fontsize=10)
names = ['M0', 'M1', 'M2', 'M3']; tot = [mode_tab[n]['total'] / 1e4 for n in
        ['M0_不调整', 'M1_仅6点', 'M2_6+12点', 'M3_完整']]
a2.plot(range(4), tot, 'o-', color=C_MAIN, lw=2, ms=8)
for i, v in enumerate(tot):
    a2.text(i, v + 3, '%.1f' % v, ha='center', fontsize=10, fontweight='bold')
mv = [None, margin['6点边际节约(万元)'], margin['12点边际节约(万元)'], margin['18点边际节约(万元)']]
for i in range(1, 4):
    a2.annotate('边际省%.2f万' % mv[i], (i, tot[i]), textcoords='offset points',
                xytext=(0, -18), ha='center', fontsize=9, color=C_SAVE)
a2.set_xticks(range(4)); a2.set_xticklabels(['不调整', '+6点', '+12点', '+18点'])
a2.set_ylabel('全年总费用（万元）', fontsize=11); a2.set_ylim(min(tot) - 20, max(tot) + 15)
a2.set_title('逐级引入调整的总费用阶梯', fontsize=12); a2.grid(ls='--', alpha=0.4)
fig.suptitle('问题3 交叉分析①：各预报时刻的调整量与边际经济价值', fontsize=13.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题3_交叉_调整时刻价值.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ============ 图C3：月度调整收益 ============
fig, ax = plt.subplots(figsize=(13.5, 5.2), dpi=200)
x = np.arange(len(months)); w = 0.5
ax.bar(x, mon_tot, w, color=C_MAIN, alpha=0.85, label='M2总费用(万元)')
ax.set_xticks(x); ax.set_xticklabels(['%d月' % m for m in months])
ax.set_ylabel('总费用（万元）', color=C_MAIN); ax.grid(axis='y', ls='--', alpha=0.3)
axb = ax.twinx()
axb.plot(x, mon_save, 's-', color=C_SAVE, lw=2, label='滚动调整净收益(万元)')
axb.plot(x, mon_em, '^--', color=C_EM, lw=2, label='紧急购电量(万kWh)')
axb.set_ylabel('万元 / 万kWh')
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = axb.get_legend_handles_labels()
ax.legend(h1 + h2, l1 + l2, loc='upper left', fontsize=10, ncol=3)
ax.set_title('月份交叉：光伏波动越大的月份，滚动调整净收益越高', fontsize=12.5)
fig.tight_layout()
p = os.path.join(FIGDIR, '问题3_交叉_月度调整收益.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)

# ============ 图C4：误差→后果传导散点 ============
fig, ax = plt.subplots(figsize=(8.6, 6.4), dpi=200)
ax.scatter(day_over / 1e3, day_em / 1e3, s=14, alpha=0.55, color=C_MAIN, edgecolor='white', lw=0.3)
lim = max(day_over.max(), day_em.max()) / 1e3
ax.plot([0, lim], [0, lim], '--', color='#999', lw=1.4, label='y=x（高估量=紧急量，无缓冲）')
# 线性拟合
k1, b1 = np.polyfit(day_over, day_em, 1)
xs = np.linspace(0, day_over.max(), 50)
ax.plot(xs / 1e3, (k1 * xs + b1) / 1e3, color=C_EM, lw=2,
        label='线性拟合（斜率%.2f，<1表示存在储能/调整缓冲）' % k1)
ax.set_xlabel('当日"执行所依据的最新预报"光伏高估能量（MWh）', fontsize=11)
ax.set_ylabel('当日实际紧急购电量（MWh）', fontsize=11)
ax.set_title('预报高估→紧急购电的日尺度传导（Pearson r=%.3f）' % r_pearson, fontsize=12.5)
ax.grid(ls='--', alpha=0.4); ax.legend(fontsize=9.5, loc='upper left')
fig.tight_layout()
p = os.path.join(FIGDIR, '问题3_交叉_误差后果传导.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig); print('saved', p)
print('\n交叉分析完成。')
