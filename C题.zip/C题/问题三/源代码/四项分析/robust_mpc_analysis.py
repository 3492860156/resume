# -*- coding: utf-8 -*-
"""
问题3 · 鲁棒优化(Robust Optimization) + MPC 滚动时域控制 分析
================================================================
A. MPC：现有"0点计划+6/12/18点重优化+实测SOC反馈+窗口前移"即模型预测控制。
   - 预测时域 H_p: 24h→18h→12h→6h；控制时域=到下一发布点(6h)；反馈校正=用实际SOC重置初值。
   - 反馈频率价值：开环(0次)/仅6点/6+12点/完整 四档对比。
B. 鲁棒优化：不依赖误差分布，只用盒式不确定集
      PV ∈ [max(0, PV_fc-Γ·σ_lead), PV_fc+Γ·σ_lead]
   约束关于光伏单调(光伏越小越易缺电)，min-max 鲁棒对等 = 以光伏下界做确定性LP(仍是LP)。
   Γ=鲁棒预算(保守度旋钮)：Γ=0 复现点预报基线1591.05万(自检)。
   双口径：①标称费用=真实光伏下实际费用；②保证力=真实光伏落入盒式集的经验覆盖率、
          破防段残余紧急购电；鲁棒代价 PoR(Γ)=标称费用(Γ)-标称费用(0)。
C. 三范式风险-费用前沿：确定性MPC / 报童β=0.8 / 鲁棒各Γ。
"""
import os, sys, json, time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from q3a_common import (load_all, day_vector, solve_plan_p, solve_adjust_p,
                        H, N, S_INIT, OUT_SLICE, FIGDIR, summarize, run_year_p)
from q3_common import PUB_HOURS
from newsvendor_analysis import build_error_quantiles

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
PUB_IDX = [h * 6 for h in PUB_HOURS]
STAGES = (36, 72, 108)


# ===================== 鲁棒对等：以光伏下界做滚动决策 =====================
def simulate_robust(L, PVact, fc_day, price, s_init, sigma_tab, gamma,
                    stages=STAGES, eta=0.9, emult=5.0, dn=0.5, up=1.5):
    """每次发布对其整个剩余预测时域施加 Γσ 鲁棒带，取光伏下界做鲁棒对等。"""
    e_max = H * 5000.0
    fc_use = fc_day.copy()
    for j, m in enumerate(PUB_HOURS):
        start = PUB_IDX[j]
        for i in range(start, N):
            ah = i // 6 if i < N - 1 else 24
            lead = ah - m
            if 1 <= lead <= 24:
                sig = sigma_tab[j][lead]
                if sig > 0:
                    fc_use[j, i] = max(fc_day[j, i] - gamma * sig * H, 0.0)
    Xp, Cp, Dp, _, _, _ = solve_plan_p(L, fc_use[0], price, s_init)
    Xf, Cf, Df = Xp.copy(), Cp.copy(), Dp.copy()
    for j, i0 in zip((1, 2, 3), (36, 72, 108)):
        if i0 not in stages:
            continue
        s_i0 = s_init + float((eta * Cf[:i0] - Df[:i0]).sum())
        xa, ca, da, _, _, _, _ = solve_adjust_p(
            L, fc_use[j], price, s_i0, Xp, i0, eta=eta, emult=emult, dn=dn, up=up)
        Xf[i0:], Cf[i0:], Df[i0:] = xa, ca, da
    gap = L + Cf - Xf - eta * Df
    Eact = np.maximum(gap - PVact, 0.0)
    Sf = np.empty(N + 1); Sf[0] = s_init
    Sf[1:] = s_init + np.cumsum(eta * Cf - Df)
    dn_f = np.maximum(Xp - Xf, 0.0); up_f = np.maximum(Xf - Xp, 0.0)
    cplan = float((price * Xp).sum())
    cadj = float((-dn * price * dn_f + up * price *up_f).sum())
    cem = float((emult * price * Eact).sum())
    return dict(cost_tot=cplan + cadj + cem, cost_buy=cplan + cadj, cost_em=cem,
                plan_buy=float(Xp.sum()), final_buy=float(Xf.sum()),
                up=float(up_f.sum()), dn=float(dn_f.sum()),
                em_buy=float(Eact.sum()), s24=float(Sf[N]))


def run_year_robust(data, sigma_tab, gamma, stages=STAGES):
    price, load_m, pv_m, fc_m, dates = data
    recs = []; s_init = S_INIT
    for d in range(365):
        L = day_vector(load_m, d) * H
        PVact = day_vector(pv_m, d) * H
        fc_day = np.stack([fc_m[j, d] * H for j in range(4)])
        r = simulate_robust(L, PVact, fc_day, price, s_init, sigma_tab, gamma, stages=stages)
        recs.append(r); s_init = r['s24']
    return recs


def sigma_table(qtab):
    sig = [[0.0] * 25 for _ in range(4)]
    for j in range(4):
        for lead in range(25):
            if qtab[j][lead] is not None:
                sig[j][lead] = qtab[j][lead]['std']
    return sig


def coverage_rate(data, sigma_tab, gamma):
    """真实光伏落入鲁棒下界之上(即集合内、保证不缺)的白天段比例；破防=PVact<fc-Γσ。"""
    _, load_m, pv_m, fc_m, _ = data
    inside = tot = 0
    for d in range(*OUT_SLICE.indices(365)):
        pv = day_vector(pv_m, d)
        for j, m in enumerate(PUB_HOURS):
            fc = fc_m[j, d]
            for i in range(PUB_IDX[j], N - 1):
                ah = i // 6; lead = ah - m
                if not (1 <= lead <= 24):
                    continue
                if pv[i] > 50 or fc[i] > 50:
                    tot += 1
                    lower = fc[i] - gamma * sigma_tab[j][lead]
                    if pv[i] >= lower:
                        inside += 1
    return inside / max(tot, 1)


# ===================== MPC 示意图 =====================
def fig_mpc_scheme():
    fig, ax = plt.subplots(figsize=(12.5, 5.2), dpi=200)
    steps = [(0, 24, 6, '#4E79A7'), (6, 18, 6, '#5B8FC0'),
             (12, 12, 6, '#E1812C'), (18, 6, 6, '#8C8C8C')]
    for row, (m, hp, hc, col) in enumerate(steps):
        y = 3 - row
        # 预测时域
        ax.barh(y, hp, left=m, height=0.5, color=col, alpha=0.25, edgecolor=col)
        if hp > hc:   # 预测文字只放在执行块右侧的剩余预测区，避免与执行块重叠
            ax.text(m + hc + (hp - hc) / 2, y, '预测时域 Hp=%dh' % hp,
                    ha='center', va='center', fontsize=9.5)
        # 控制(执行)时域=6h
        ax.barh(y, hc, left=m, height=0.5, color=col, alpha=0.95)
        exec_txt = '执行=预测6h' if hp <= hc else '执行%dh' % hc
        ax.text(m + hc / 2, y, exec_txt, ha='center', va='center', fontsize=9, color='white')
        ax.text(m - 0.4, y, '%d:00 决策' % m, ha='right', va='center', fontsize=9.5, fontweight='bold')
    for m in (0, 6, 12, 18, 24):
        ax.axvline(m, color='#CCC', lw=0.8, zorder=0)
        ax.text(m, 3.75, '%d:00' % m, ha='center', fontsize=9)
    # 前移箭头
    for y0, y1 in [(3, 2), (2, 1), (1, 0)]:
        ax.add_patch(FancyArrowPatch((6.3, y0 - 0.32), (6.3, y1 + 0.32),
                     arrowstyle='-|>', mutation_scale=14, color='#D62728', lw=1.6))
    ax.text(6.6, 1.5, '窗口前移 + 实测SOC反馈校正', color='#D62728', fontsize=10, rotation=90, va='center')
    ax.set_xlim(-3.2, 25); ax.set_ylim(-0.6, 4.1); ax.axis('off')
    ax.set_title('问题3 MPC①：滚动时域控制框架（预测窗 24→18→12→6h，每步只执行下一6h并前移）', fontsize=12.5)
    fig.tight_layout()
    p = os.path.join(FIGDIR, '问题3_MPC_滚动时域框架.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig)
    return p


def main():
    t0 = time.time(); data = load_all()
    qtab = build_error_quantiles(data); sig = sigma_table(qtab)

    # ---------- A. MPC 反馈频率价值（四档现算，保证数值自洽） ----------
    mpc = []
    for name, st in [('开环(0次更新)', ()), ('仅6点(1次)', (36,)),
                     ('6+12点(2次)', (36, 72)), ('完整(3次)', STAGES)]:
        m = summarize(run_year_p(data, stages=st))
        mpc.append(dict(name=name, n_update=len(st), total_wan=m['total'] / 1e4,
                        em_wan=m['em_kwh'] / 1e4))
        print('MPC %-14s 总费用%.2f万 紧急%.2f万kWh' % (name, mpc[-1]['total_wan'], mpc[-1]['em_wan']))
    assert abs(mpc[-1]['total_wan'] - 1591.05) < 0.5
    p_mpc1 = fig_mpc_scheme()

    # ---------- B. 鲁棒预算 Γ 扫描 ----------
    gammas = [0.0, 0.5, 1.0, 1.28, 1.65, 2.0, 2.5, 3.0, 3.5, 4.0]
    robust = []
    for g in gammas:
        t = time.time()
        m = summarize(run_year_robust(data, sig, g))
        cov = coverage_rate(data, sig, g)
        robust.append(dict(gamma=g, total_wan=m['total'] / 1e4, buy_wan=m['buy'] / 1e4,
                           em_wan=m['em_kwh'] / 1e4, coverage=cov,
                           por_wan=m['total'] / 1e4 - robust[0]['total_wan'] if robust else 0.0))
        print('Γ=%.2f 总费用%.2f万 残余紧急%.2f万kWh 覆盖率%.1f%% PoR%.2f万 (%.1fs)'
              % (g, robust[-1]['total_wan'], robust[-1]['em_wan'], 100 * cov,
                 robust[-1]['por_wan'], time.time() - t))
    assert abs(robust[0]['total_wan'] - 1591.05) < 0.5, 'Γ=0未复现基线!'
    # 首个残余紧急≈0的Γ=完全鲁棒可行的最小预算
    g_feas = next((r['gamma'] for r in robust if r['em_wan'] < 0.5), None)

    # ---------- C. 三范式前沿（报童数从newsvendor_results读） ----------
    nv_path = os.path.join(_HERE, '..', '..', '数据', 'newsvendor_results.json')
    nv = json.load(open(nv_path, encoding='utf-8')) if os.path.exists(nv_path) else None
    paradigms = dict(deterministic=dict(total=1591.05, em=76.06),
                     robust=[dict(gamma=r['gamma'], total=r['total_wan'], em=r['em_wan']) for r in robust])
    if nv:
        paradigms['newsvendor'] = dict(beta=nv['best']['beta'], total=nv['best']['total_wan'], em=nv['best']['em_wan'])

    results = dict(mpc=mpc, robust=robust, gamma_full_feasible=g_feas, paradigms=paradigms)
    with open(os.path.join(_HERE, '..', '..', '数据', 'robust_mpc_results.json'), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # ===== 图 MPC② 反馈频率价值 =====
    fig, a1 = plt.subplots(figsize=(9.5, 5.2), dpi=200)
    xs = np.arange(len(mpc)); w = 0.38
    a1.bar(xs - w / 2, [r['total_wan'] for r in mpc], w, color='#4E79A7', label='全年总费用(万元)')
    a1.set_xticks(xs); a1.set_xticklabels([r['name'] for r in mpc]); a1.set_ylabel('全年总费用（万元）', color='#4E79A7')
    a1.tick_params(axis='y', labelcolor='#4E79A7'); a1.set_ylim(1500, 1680)
    for x, r in zip(xs, mpc):
        a1.text(x - w / 2, r['total_wan'] + 4, '%.1f' % r['total_wan'], ha='center', fontsize=9)
    a2 = a1.twinx()
    a2.bar(xs + w / 2, [r['em_wan'] for r in mpc], w, color='#E1812C', label='紧急购电量(万kWh)')
    a2.set_ylabel('紧急购电量（万kWh）', color='#E1812C'); a2.tick_params(axis='y', labelcolor='#E1812C')
    for x, r in zip(xs, mpc):
        a2.text(x + w / 2, r['em_wan'] + 1, '%.1f' % r['em_wan'], ha='center', fontsize=9)
    a1.set_title('问题3 MPC②：反馈更新频率越高，费用与紧急购电单调下降（18点更新无增量）')
    a1.grid(ls='--', alpha=0.35, axis='y')
    fig.tight_layout(); p_mpc2 = os.path.join(FIGDIR, '问题3_MPC_反馈频率价值.png')
    fig.savefig(p_mpc2, bbox_inches='tight'); plt.close(fig)

    # ===== 图 RO① Γ扫描：费用/残余紧急/覆盖率 =====
    gx = [r['gamma'] for r in robust]
    fig, a1 = plt.subplots(figsize=(9.8, 5.3), dpi=200)
    a1.plot(gx, [r['total_wan'] for r in robust], 'o-', color='#4E79A7', lw=2.2, label='标称总费用(万元)')
    a1.set_xlabel('鲁棒预算 Γ（盒式集半宽 = Γ·σ_提前量）'); a1.set_ylabel('全年总费用（万元）', color='#4E79A7')
    a1.tick_params(axis='y', labelcolor='#4E79A7')
    a2 = a1.twinx()
    a2.plot(gx, [r['em_wan'] for r in robust], 's-', color='#D62728', lw=2, label='残余紧急购电(万kWh)')
    a2.plot(gx, [100 * r['coverage'] for r in robust], '^--', color='#2CA02C', lw=1.8, label='集合经验覆盖率(%)')
    a2.set_ylabel('残余紧急量(万kWh) / 覆盖率(%)', color='#D62728')
    if g_feas is not None:
        a1.axvline(g_feas, color='#888', ls=':'); a1.text(g_feas + 0.02, 1560, 'Γ=%.2f\n集合内零紧急' % g_feas, fontsize=9)
    l1, la1 = a1.get_legend_handles_labels(); l2, la2 = a2.get_legend_handles_labels()
    a1.legend(l1 + l2, la1 + la2, loc='center right', fontsize=9)
    a1.grid(ls='--', alpha=0.35); a1.set_title('问题3 鲁棒①：鲁棒预算Γ扫描——保证力↑的代价(PoR)↑')
    fig.tight_layout(); p_ro1 = os.path.join(FIGDIR, '问题3_鲁棒_预算扫描.png')
    fig.savefig(p_ro1, bbox_inches='tight'); plt.close(fig)

    # ===== 图 RO② 三范式风险-费用有效前沿 =====
    fig, ax = plt.subplots(figsize=(9.8, 5.6), dpi=200)
    rt = [r['total_wan'] for r in robust]; re_ = [r['em_wan'] for r in robust]
    ax.plot(re_, rt, 'o-', color='#8C8C8C', lw=1.8, label='鲁棒优化 Γ 序列')
    for r in robust:
        ax.annotate('Γ=%.2f' % r['gamma'], (r['em_wan'], r['total_wan']),
                    textcoords='offset points', xytext=(4, 6), fontsize=8)
    ax.scatter([76.06], [1591.05], s=110, color='#4E79A7', zorder=5, label='确定性MPC(点预报)')
    ax.annotate('确定性MPC\n1591.0/76.1', (76.06, 1591.05), textcoords='offset points', xytext=(-10, -22),
                fontsize=9, color='#4E79A7')
    if nv:
        ax.scatter([nv['best']['em_wan']], [nv['best']['total_wan']], s=130, marker='*',
                   color='#E1812C', zorder=6, label='报童 β=%.2f' % nv['best']['beta'])
        ax.annotate('报童β=0.8\n1525.8/34.3', (nv['best']['em_wan'], nv['best']['total_wan']),
                    textcoords='offset points', xytext=(8, 6), fontsize=9, color='#E1812C')
    ax.set_xlabel('残余风险：全年紧急购电量（万kWh）'); ax.set_ylabel('全年总费用（万元）')
    ax.grid(ls='--', alpha=0.4); ax.legend(loc='upper right', fontsize=9.5)
    ax.set_title('问题3 鲁棒②：三种不确定性决策范式的风险—费用前沿（左下更优）')
    fig.tight_layout(); p_ro2 = os.path.join(FIGDIR, '问题3_三范式风险费用前沿.png')
    fig.savefig(p_ro2, bbox_inches='tight'); plt.close(fig)

    print('完成，耗时 %.1fs；完全鲁棒可行 Γ=%s' % (time.time() - t0, g_feas))
    for p in (p_mpc1, p_mpc2, p_ro1, p_ro2):
        print('saved', p)


if __name__ == '__main__':
    main()
