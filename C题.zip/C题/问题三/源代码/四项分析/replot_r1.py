# -*- coding: utf-8 -*-
"""从 robustness_results.json 重绘 R1 系统偏差响应（修正标题表述）。"""
import os, sys, json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from q3a_common import FIGDIR
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
d = json.load(open(os.path.join(_HERE, '..', '..', '数据', 'robustness_results.json'), encoding='utf-8'))
xx = d['bias_pct']; s = d['stress']; C = ['#B7CCE0', '#9BBBF4', '#E1B98F', '#4E79A7']
MODES = ['M0', 'M1', 'M2', 'M3']
fig, (a1, a2) = plt.subplots(1, 2, figsize=(14.5, 5.2), dpi=200)
for mn, col in zip(MODES, C):
    a1.plot(xx, [v['total_wan'] for v in s[mn]], 'o-', color=col, lw=2, label=mn)
a1.axvline(0, color='#888', ls=':'); a1.set_xlabel('光伏预报系统偏差 (%)')
a1.set_ylabel('全年总费用（万元）'); a1.grid(ls='--', alpha=0.4); a1.legend()
a1.set_title('M2/M3始终最低且重合；现实偏差区间内滚动调整稳定占优')
for mn, col in zip(MODES, C):
    a2.plot(xx, [v['em_wan'] for v in s[mn]], 's-', color=col, lw=2, label=mn)
a2.axvline(0, color='#888', ls=':'); a2.set_xlabel('光伏预报系统偏差 (%)')
a2.set_ylabel('紧急购电量（万kWh）'); a2.grid(ls='--', alpha=0.4); a2.legend()
a2.set_title('高估越严重紧急购电越多，滚动调整显著压低曲线')
fig.suptitle('问题3 稳健性①：系统预报偏差压力下的四模式响应（M3≡M2 在全部7档成立；−8%~+8%内M2最优）', fontsize=12.5)
fig.tight_layout(rect=[0, 0, 1, 0.94])
p = os.path.join(FIGDIR, '问题3_稳健_系统偏差响应.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig)
print('重绘完成', p)
