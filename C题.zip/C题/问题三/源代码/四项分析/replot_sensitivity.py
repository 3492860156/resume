# -*- coding: utf-8 -*-
"""从 sensitivity_results.json 重绘参数曲线图（右轴紧急量统一量程，避免科学计数）。"""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
_HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, _HERE)
from q3a_common import FIGDIR
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False

LEVELS = {
    '上调溢价倍率': [1.1, 1.3, 1.5, 1.7, 2.0],
    '下调退款率': [0.20, 0.35, 0.50, 0.65, 0.80],
    '紧急购电倍率': [3, 4, 5, 6, 8],
    '预报误差强度': [0.0, 0.5, 1.0, 1.5, 2.0],
    '充放效率η': [0.85, 0.875, 0.90, 0.925, 0.95]}
BASE = {'上调溢价倍率': 1.5, '下调退款率': 0.5, '紧急购电倍率': 5, '预报误差强度': 1.0, '充放效率η': 0.9}
res = json.load(open(os.path.join(_HERE, '..', '..', '数据', 'sensitivity_results.json'), encoding='utf-8'))

fig, axes = plt.subplots(1, 5, figsize=(19.5, 4.2), dpi=200)
for ax, param in zip(axes, list(LEVELS)):
    lv = LEVELS[param]
    cost = [res[param][str(v)]['total_wan'] for v in lv]
    emq = [res[param][str(v)]['em_wan_kwh'] for v in lv]
    ax.plot(lv, cost, '-o', color='#4E79A7', lw=2, label='总费用(万元)')
    ax.axhline(res[param][str(BASE[param])]['total_wan'], color='#999', ls=':', lw=1)
    axb = ax.twinx()
    axb.plot(lv, emq, '--s', color='#E15759', ms=4, lw=1.6, label='紧急购电量(万kWh)')
    axb.set_ylim(0, 150)                              # 统一量程，五图可比
    ax.set_title(param, fontsize=11.5); ax.grid(ls='--', alpha=0.4)
    ax.tick_params(labelsize=8.5); axb.tick_params(labelsize=8.5)
    if param == list(LEVELS)[0]:
        ax.set_ylabel('总费用(万元)', fontsize=10, color='#4E79A7')
    if param == list(LEVELS)[-1]:
        axb.set_ylabel('紧急购电量(万kWh)', fontsize=10, color='#E15759')
fig.suptitle('问题3 敏感性②：五参数逐水平全年重解（实线=总费用，虚线=紧急购电量，点线=基线）', fontsize=13)
fig.tight_layout(rect=[0, 0, 1, 0.93])
p = os.path.join(FIGDIR, '问题3_敏感_参数曲线.png'); fig.savefig(p, bbox_inches='tight'); plt.close(fig)
print('重绘完成', p)
